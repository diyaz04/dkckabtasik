import LaporanPdfTemplate from './LaporanPdfTemplate';
import { showAlert as alert, showConfirm } from '../utils/dialog';
import { ensureCoreFields } from '../utils/coreFields';
import SuratAdminPanel from './SuratAdminPanel';
import FooterKontakEditor from './FooterKontakEditor';
import SejarahDkcEditor from './SejarahDkcEditor';
import PengumumanEditor from './PengumumanEditor';
import VisibilityToggleCard from './VisibilityToggleCard';
import { cacheKlasemenVisible } from '../utils/useKlasemenVisible';
import { useSuratDkr } from '../utils/suratDkr';
import { Mail as MailIcon, Key, Megaphone } from 'lucide-react';
import PersonaliaExtraFields, { PersonaliaExtra, emptyPersonaliaExtra, extraFromPersonalia, serializeExtra } from './PersonaliaExtraFields';
import React, { useState, useEffect, lazy, Suspense } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  BarChart2, Users, Building, FileText, Calendar, Plus, Trash, Check, X,
  Save, Edit, Lock, Eye, AlertCircle, ToggleLeft, ToggleRight, LayoutDashboard, Search, Bell, Menu, Settings,
  RefreshCw, Palette, Upload, Award, ClipboardList, Printer, Clock, ChevronRight, Download, PanelLeft
, Edit2, ChevronDown, ChevronUp } from 'lucide-react';
import { 
  Kecamatan, Personalia, Berita, AgendaKegiatan, 
  Informasi, SiteContent, FormKegiatanConfig, DataPotensial, Profile, Saka, LaporanKegiatan 
} from '../types';
import { compressAndUploadFile, compressAndUploadToUploadcare } from '../utils/imageUpload';
import * as XLSX from 'xlsx';
import { BarChart, Bar, XAxis, YAxis, Tooltip, PieChart, Pie, Cell, ResponsiveContainer, Legend } from 'recharts';
const CheckinScanner = lazy(() => import('./CheckinScanner'));
import { ScanLine, CheckCircle } from 'lucide-react';
import GreetingBanner from './GreetingBanner';

export default function PortalAdmin() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'dashboard' | 'potensial_dkr' | 'potensial_saka' | 'pangkalan' | 'berita' | 'agenda' | 'personalia' | 'users_dkr' | 'users_saka' | 'konten' | 'pengumuman' | 'laporan' | 'informasi' | 'surat'>('dashboard');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const { list: suratList, reload: reloadSurat } = useSuratDkr('admin');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const [isChangePasswordModalOpen, setIsChangePasswordModalOpen] = useState(false);

  const [isNotifMenuOpen, setIsNotifMenuOpen] = useState(false);

  const [user, setUser] = useState<any>(null);

  // DB States
  const [kecamatanList, setKecamatanList] = useState<Kecamatan[]>([]);
  const [sakaList, setSakaList] = useState<Saka[]>([]);
  const [dataPotensial, setDataPotensial] = useState<DataPotensial[]>([]);
  const [beritaList, setBeritaList] = useState<Berita[]>([]);
  const [agendaList, setAgendaList] = useState<AgendaKegiatan[]>([]);
  const [userList, setUserList] = useState<any[]>([]);
  const [siteContent, setSiteContent] = useState<SiteContent[]>([]);
  const [pangkalanList, setPangkalanList] = useState<any[]>([]);
  const [togglingAgendaId, setTogglingAgendaId] = useState<string | null>(null);
  const HAPUS_KEGIATAN_PHRASE = 'hapus kegiatan ini sekarang';
  const [agendaToDelete, setAgendaToDelete] = useState<AgendaKegiatan | null>(null);
  const [deleteConfirmText, setDeleteConfirmText] = useState('');
  const [isDeletingAgenda, setIsDeletingAgenda] = useState(false);

  // Daftar Pangkalan/Gudep (admin) — tabel bertingkat per kwaran
  const [expandedKwarranPk, setExpandedKwarranPk] = useState<string[]>([]);
  const [pangkalanSearch, setPangkalanSearch] = useState('');
  const [editingPangkalan, setEditingPangkalan] = useState<{ id: string; nama_pangkalan: string; jenis: string; status_aktif: boolean } | null>(null);
  const [addPangkalanKwarran, setAddPangkalanKwarran] = useState<string | null>(null);
  const [addPangkalanNama, setAddPangkalanNama] = useState('');
  const [addPangkalanJenis, setAddPangkalanJenis] = useState('SMA');
  const [pangkalanSaving, setPangkalanSaving] = useState(false);

  const reloadPangkalan = async () => {
    try {
      const data = await fetch('/api/pangkalan').then(r => r.json());
      setPangkalanList(Array.isArray(data) ? data : []);
    } catch (e) {
      console.error(e);
    }
  };

  const toggleKwarranPk = (id: string) => {
    setExpandedKwarranPk(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  const postPangkalan = async (payload: any) => {
    setPangkalanSaving(true);
    try {
      const res = await fetch('/api/pangkalan/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (!res.ok) throw new Error('Gagal menyimpan pangkalan');
      await reloadPangkalan();
      return true;
    } catch (e: any) {
      alert(e.message || 'Gagal menyimpan pangkalan');
      return false;
    } finally {
      setPangkalanSaving(false);
    }
  };

  const handleSaveEditPangkalan = async () => {
    if (!editingPangkalan || !editingPangkalan.nama_pangkalan.trim()) return;
    const ok = await postPangkalan({
      id: editingPangkalan.id,
      nama_pangkalan: editingPangkalan.nama_pangkalan.trim(),
      jenis: editingPangkalan.jenis,
      status_aktif: editingPangkalan.status_aktif
    });
    if (ok) setEditingPangkalan(null);
  };

  const handleAddPangkalanAdmin = async (kecamatanId: string) => {
    if (!addPangkalanNama.trim()) return;
    const ok = await postPangkalan({
      kecamatan_id: kecamatanId,
      nama_pangkalan: addPangkalanNama.trim(),
      jenis: addPangkalanJenis,
      status_aktif: true
    });
    if (ok) {
      setAddPangkalanNama('');
      setAddPangkalanJenis('SMA');
      setAddPangkalanKwarran(null);
    }
  };

  const handleDeletePangkalanAdmin = async (pk: any) => {
    if (!await showConfirm(`Hapus pangkalan "${pk.nama_pangkalan}"?`)) return;
    try {
      const res = await fetch('/api/pangkalan/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: pk.id })
      });
      if (!res.ok) throw new Error('Gagal menghapus pangkalan');
      await reloadPangkalan();
    } catch (e: any) {
      alert(e.message || 'Gagal menghapus pangkalan');
    }
  };
  const [personaliaList, setPersonaliaList] = useState<Personalia[]>([]);
  const [informasiList, setInformasiList] = useState<Informasi[]>([]);

  // Form Inputs (Pusat Unduhan Berkas / Informasi CRUD)
  const [infoJudul, setInfoJudul] = useState('');
  const [infoDeskripsi, setInfoDeskripsi] = useState('');
  const [infoTipe, setInfoTipe] = useState<'gambar' | 'dokumen'>('dokumen');
  const [infoFileUrl, setInfoFileUrl] = useState('');
  const [infoUploading, setInfoUploading] = useState(false);
  const [infoSaving, setInfoSaving] = useState(false);

  // Form Inputs (Personalia DKC CRUD)
  const [newPersonNama, setNewPersonNama] = useState('');
  const [newPersonJabatan, setNewPersonJabatan] = useState('');
  const [newPersonGolongan, setNewPersonGolongan] = useState<'penegak' | 'pandega' | 'pembina' | 'lainnya'>('pandega');
  const [newPersonFoto, setNewPersonFoto] = useState('');
  const [personaliaSaving, setPersonaliaSaving] = useState(false);
  const [newPersonExtra, setNewPersonExtra] = useState<PersonaliaExtra>(emptyPersonaliaExtra());
  const [editingPersonaliaId, setEditingPersonaliaId] = useState<string | null>(null);

  // Laporan States
  const [laporanList, setLaporanList] = useState<LaporanKegiatan[]>([]);
  const [laporanLoading, setLaporanLoading] = useState(false);
  const [showProcessModal, setShowProcessModal] = useState(false);
  const [processingLaporan, setProcessingLaporan] = useState<LaporanKegiatan | null>(null);
  const [processStatus, setProcessStatus] = useState<'diterima' | 'ditolak' | 'revisi'>('diterima');
  const [processCatatan, setProcessCatatan] = useState('');
  const [processPointBobot, setProcessPointBobot] = useState(10);
  const [processSaving, setProcessSaving] = useState(false);
  
  // New sub-tab state, expanded detail state, and standings toggle
  const [laporanSubTab, setLaporanSubTab] = useState<'pending' | 'verified'>('pending');
  const [expandedLaporanId, setExpandedLaporanId] = useState<string | null>(null);
  const [showKlasemen, setShowKlasemen] = useState<boolean>(true);
  const [savingKlasemen, setSavingKlasemen] = useState<boolean>(false);
  const [showLaporanMenu, setShowLaporanMenu] = useState<boolean>(true);

  // Medsos states
  const [dkcMedsosIg, setDkcMedsosIg] = useState('');
  const [dkcMedsosYt, setDkcMedsosYt] = useState('');
  const [dkcMedsosTk, setDkcMedsosTk] = useState('');

  // Editor states (News)
  const [newsTitle, setNewsTitle] = useState('');
  const [newsContent, setNewsContent] = useState('');
  const [editingNewsId, setEditingNewsId] = useState<string | null>(null);
  const [editingNewsAuthor, setEditingNewsAuthor] = useState<any>(null);
  const [newsImage, setNewsImage] = useState('');
  const [newsSaving, setNewsSaving] = useState(false);

  // Editor states (Agenda)
  const [agendaName, setAgendaName] = useState('');
  const [agendaPlace, setAgendaPlace] = useState('');
  const [agendaStart, setAgendaStart] = useState('');
  const [agendaEnd, setAgendaEnd] = useState('');
  const [agendaEst, setAgendaEst] = useState(100);
  const [agendaType, setAgendaType] = useState<'mandiri' | 'partisipasi'>('mandiri');
  const [agendaLevel, setAgendaLevel] = useState<'kabupaten' | 'provinsi' | 'nasional' | 'internasional'>('kabupaten');
  const [agendaIsDateDecided, setAgendaIsDateDecided] = useState(true);
  const [agendaBulanRencana, setAgendaBulanRencana] = useState('2026-08');
  const [agendaLogoUrl, setAgendaLogoUrl] = useState('');
  const [agendaLogoUploading, setAgendaLogoUploading] = useState(false);
  const [agendaJuknisUrl, setAgendaJuknisUrl] = useState('');
  const [agendaJuknisName, setAgendaJuknisName] = useState('');
  const [agendaSuratEdaranUrl, setAgendaSuratEdaranUrl] = useState('');
  const [agendaSuratEdaranName, setAgendaSuratEdaranName] = useState('');
  const [agendaDocUploading, setAgendaDocUploading] = useState<null | 'juknis' | 'surat_edaran'>(null);
  const [agendaIsCampFee, setAgendaIsCampFee] = useState(false);
  const [agendaCampFee, setAgendaCampFee] = useState(0);
  const [agendaSaving, setAgendaSaving] = useState(false);

  // Form Builder & Dashboard state
  const [isAddAgendaModalOpen, setIsAddAgendaModalOpen] = useState(false);
  const [selectedBuilderAgenda, setSelectedBuilderAgenda] = useState<AgendaKegiatan | null>(null);
  const [selectedDashboardAgenda, setSelectedDashboardAgenda] = useState<AgendaKegiatan | null>(null);
  const [formFields, setFormFields] = useState<any[]>([]);
  const [pendaftaranTipe, setPendaftaranTipe] = useState<'mandiri' | 'kolektif' | 'keduanya'>('keduanya');
  const [isQrValidasi, setIsQrValidasi] = useState(true);
  const [isQrCheckin, setIsQrCheckin] = useState(false);
  const [registrants, setRegistrants] = useState<any[]>([]);
  const [showScanner, setShowScanner] = useState(false);
  const [agendaDashboardTab, setAgendaDashboardTab] = useState<'semua' | 'menunggu' | 'lunas' | 'checkin' | 'tagihan_kwarran'>('semua');
  const [viewRegistrant, setViewRegistrant] = useState<any | null>(null);
  const [tagihanKwarranList, setTagihanKwarranList] = useState<any[]>([]);
  
  // Tagihan Kolektif Action States
  const [isRejectTagihanModalOpen, setIsRejectTagihanModalOpen] = useState(false);
  const [rejectTagihanId, setRejectTagihanId] = useState('');
  const [rejectTagihanCatatan, setRejectTagihanCatatan] = useState('');

  // Dashboard Analytics & Wilayah Config States
  const [filterStatus, setFilterStatus] = useState<string>('semua');
  const [filterWilayah, setFilterWilayah] = useState<string>('semua');
  const [filterKwarran, setFilterKwarran] = useState<string>('semua');
  const [filterGender, setFilterGender] = useState<string>('semua');
  
  const [isDashboardConfigModalOpen, setIsDashboardConfigModalOpen] = useState(false);
  const [tempDashboardConfig, setTempDashboardConfig] = useState<any>(null);

  const [isWilayahConfigModalOpen, setIsWilayahConfigModalOpen] = useState(false);
  const [tempWilayahData, setTempWilayahData] = useState<any[]>([]);
  const [wilayahSaving, setWilayahSaving] = useState(false);

  // User management states
  const [newEmail, setNewEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');

  const [newKecaId, setNewKecaId] = useState('');
  const [newSakaId, setNewSakaId] = useState('');
  const [newNama, setNewNama] = useState('');
  const [newRole, setNewRole] = useState<'user' | 'saka'>('user');

  // Landing page editable states
  const [heroTitle, setHeroTitle] = useState('');
  const [heroSubtitle, setHeroSubtitle] = useState('');
  const [heroLead, setHeroLead] = useState('');
  const [heroCta, setHeroCta] = useState('');
  const [heroBadge, setHeroBadge] = useState('');
  const [heroBgImageUrl, setHeroBgImageUrl] = useState('');
  const [heroBgOpacity, setHeroBgOpacity] = useState(0.4);

  // Theme customizer states
  const [brandOrange, setBrandOrange] = useState('#F5A623');
  const [brandGreen, setBrandGreen] = useState('#4CAF50');
  const [brandBrownDark, setBrandBrownDark] = useState('#5C4033');
  const [brandBrownMid, setBrandBrownMid] = useState('#8B7355');
  const [extractedColors, setExtractedColors] = useState<string[]>([]);
  const [isExtracting, setIsExtracting] = useState(false);

  const checkAuth = () => {
    const token = localStorage.getItem('dkc_token');
    const userString = localStorage.getItem('dkc_user');
    if (!token || !userString) {
      navigate('/portal/login');
      return;
    }
    const userObj = JSON.parse(userString);
    if (userObj.role !== 'admin') {
      navigate('/portal/dkr');
    }
    setUser(userObj);
  };

  const loadData = async () => {
    const cached = localStorage.getItem('admin_data_cache');
    if (cached) {
      try {
        const c = JSON.parse(cached);
        if (c.keca) setKecamatanList(c.keca);
        if (c.saka) setSakaList(c.saka);
        if (c.pot) setDataPotensial(c.pot);
        if (c.news) setBeritaList(c.news);
        if (c.age) setAgendaList(c.age);
        if (c.users) setUserList(c.users);
        if (c.info) setInformasiList(c.info);
        if (c.sc) {
          setSiteContent(c.sc);
          const hero = c.sc.find((item: any) => item.section_key === 'hero');
          if (hero && hero.content) {
            setHeroTitle(hero.content.title);
            setHeroSubtitle(hero.content.subtitle);
            setHeroLead(hero.content.lead);
            setHeroCta(hero.content.cta_text);
            setHeroBadge(hero.content.badge_text);
            setHeroBgImageUrl(hero.content.bg_image_url || 'https://media.suara.com/pictures/970x544/2023/08/14/79829-hari-pramuka-raimuna-nasional-xii.jpg');
            setHeroBgOpacity(hero.content.bg_opacity !== undefined ? Number(hero.content.bg_opacity) : 0.4);
          }
          const medsos = c.sc.find((item: any) => item.section_key === 'medsos_dkc');
          if (medsos && medsos.content) {
            setDkcMedsosIg(medsos.content.ig || '');
            setDkcMedsosYt(medsos.content.yt || '');
            setDkcMedsosTk(medsos.content.tk || '');
          }
        }
      } catch (e) {}
    }

    try {
      const [keca, saka, pot, news, age, users, info, sc] = await Promise.all([
        fetch('/api/kecamatan').then(r => r.json()),
        fetch('/api/saka').then(r => r.json()),
        fetch('/api/data_potensial').then(r => r.json()),
        fetch('/api/berita').then(r => r.json()),
        fetch('/api/agenda').then(r => r.json()),
        fetch('/api/users').then(r => r.json()),
        fetch('/api/informasi').then(r => r.json()),
        fetch('/api/site_content').then(r => r.json())
      ]);

      setKecamatanList(keca);
      setSakaList(saka);
      setDataPotensial(pot);
      setBeritaList(news);
      setAgendaList(age);
      setUserList(users);
      setInformasiList(info);
      setSiteContent(sc);
      
      localStorage.setItem('admin_data_cache', JSON.stringify({ keca, saka, pot, news, age, users, info, sc }));

      const hero = sc.find((item: any) => item.section_key === 'hero');
      if (hero) {
        setHeroTitle(hero.content.title);
        setHeroSubtitle(hero.content.subtitle);
        setHeroLead(hero.content.lead);
        setHeroCta(hero.content.cta_text);
        setHeroBadge(hero.content.badge_text);
        setHeroBgImageUrl(hero.content.bg_image_url || 'https://media.suara.com/pictures/970x544/2023/08/14/79829-hari-pramuka-raimuna-nasional-xii.jpg');
        setHeroBgOpacity(hero.content.bg_opacity !== undefined ? Number(hero.content.bg_opacity) : 0.4);
      }

      const medsos = sc.find((item: any) => item.section_key === 'medsos_dkc');
      if (medsos && medsos.content) {
        setDkcMedsosIg(medsos.content.ig || '');
        setDkcMedsosYt(medsos.content.yt || '');
        setDkcMedsosTk(medsos.content.tk || '');
      }

      const theme = sc.find((item: any) => item.section_key === 'theme');
      if (theme && theme.content) {
        setBrandOrange(theme.content.brandOrange || '#F5A623');
        setBrandGreen(theme.content.brandGreen || '#4CAF50');
        setBrandBrownDark(theme.content.brandBrownDark || '#5C4033');
        setBrandBrownMid(theme.content.brandBrownMid || '#8B7355');
      }

      const klasemen = sc.find((item: any) => item.section_key === 'klasemen');
      if (klasemen && klasemen.content) {
        setShowKlasemen(klasemen.content.show_klasemen !== false);
      } else {
        setShowKlasemen(true);
      }

      const laporanMenu = sc.find((item: any) => item.section_key === 'laporan_menu_visibility');
      if (laporanMenu && laporanMenu.content) {
        setShowLaporanMenu(laporanMenu.content.show_menu !== false);
      } else {
        setShowLaporanMenu(true);
      }

      const pangkalan = await fetch('/api/pangkalan').then(r => r.json());
      setPangkalanList(pangkalan);

      const personel = await fetch('/api/personalia?owner_type=dkc').then(r => r.json());
      setPersonaliaList(personel || []);

      // Fetch Laporan Kegiatan
      setLaporanLoading(true);
      const lap = await fetch('/api/laporan_kegiatan').then(r => r.json());
      setLaporanList(lap || []);
      setLaporanLoading(false);
    } catch (e) {
      console.error(e);
      setLaporanLoading(false);
    }
  };

  // Download PDF Laporan (Admin view)
  const handleDownloadPdf = async (laporan: LaporanKegiatan) => {
    try {
      const html2pdf = (await import('html2pdf.js')).default;
      const element = document.getElementById(`pdf-laporan-${laporan.id}`);
      if (!element) {
        alert("Template PDF belum dimuat.");
        return;
      }
      element.style.display = 'block';
      const opt = {
        margin:       10,
        filename:     `Laporan_${laporan.jenis_dokumen}_${laporan.nama_kegiatan.replace(/\s+/g, '_')}.pdf`,
        image:        { type: 'jpeg' as const, quality: 0.98 },
        html2canvas:  { scale: 2, useCORS: true },
        jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' }
      };
      html2pdf().set(opt).from(element).save().then(() => {
        element.style.display = 'none';
      });
    } catch (e) {
      console.error(e);
      alert("Gagal mengunduh PDF");
    }
  };

  // Save Wilayah
  const handleSaveWilayah = async (e: React.FormEvent) => {
    e.preventDefault();
    setWilayahSaving(true);
    try {
      const res = await fetch('/api/wilayah/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ wilayahData: tempWilayahData })
      });
      if(res.ok) {
        alert('Wilayah Kwarran berhasil disimpan!');
        setIsWilayahConfigModalOpen(false);
        loadData();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setWilayahSaving(false);
    }
  };

  // Process / Approve / Reject Laporan Kegiatan
  const handleProcessLaporan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!processingLaporan) return;
    setProcessSaving(true);
    try {
      const res = await fetch('/api/laporan_kegiatan/process', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: processingLaporan.id,
          status: processStatus,
          catatan_admin: processCatatan,
          point_bobot: processStatus === 'diterima' ? Number(processPointBobot) : 0
        })
      });
      if (res.ok) {
        alert('Status pelaporan kegiatan berhasil diperbarui!');
        setShowProcessModal(false);
        setProcessingLaporan(null);
        setProcessCatatan('');
        loadData();
      } else {
        alert('Gagal memproses pelaporan kegiatan.');
      }
    } catch (err) {
      console.error(err);
    } finally {
      setProcessSaving(false);
    }
  };

  // Toggle Klasemen Landingpage (section di landingpage + menu di navbar)
  const handleToggleKlasemen = async (val: boolean) => {
    if (savingKlasemen) return;
    setSavingKlasemen(true);
    try {
      const res = await fetch('/api/site_content/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          section_key: 'klasemen',
          content: { show_klasemen: val }
        })
      });
      if (res.ok) {
        setShowKlasemen(val);
        cacheKlasemenVisible(val);
        const updatedSc = await fetch('/api/site_content').then(r => r.json());
        setSiteContent(updatedSc);
      } else {
        alert('Gagal memperbarui pengaturan klasemen.');
      }
    } catch (err) {
      console.error(err);
      alert('Gagal memperbarui pengaturan klasemen. Periksa koneksi lalu coba lagi.');
    } finally {
      setSavingKlasemen(false);
    }
  };

  // Toggle Menu Laporan DKR
  const handleToggleLaporanMenu = async (val: boolean) => {
    try {
      const res = await fetch('/api/site_content/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          section_key: 'laporan_menu_visibility',
          content: { show_menu: val }
        })
      });
      if (res.ok) {
        setShowLaporanMenu(val);
        const updatedSc = await fetch('/api/site_content').then(r => r.json());
        setSiteContent(updatedSc);
      } else {
        alert('Gagal memperbarui pengaturan visibilitas menu laporan.');
      }
    } catch (err) {
      console.error(err);
    }
  };

  
  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPassword || newPassword.length < 6) return alert('Password minimal 6 karakter');
    if (!user?.user_id) return alert('Gagal mengidentifikasi user. Silakan relogin.');
    try {
      const res = await fetch('/api/auth/change-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${localStorage.getItem('dkc_token') || ''}` },
        body: JSON.stringify({ newPassword })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      alert('Password berhasil diubah!');
      setIsChangePasswordModalOpen(false);
      setNewPassword('');
    } catch (err: any) {
      alert('Gagal merubah password: ' + err.message);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('dkc_token');
    localStorage.removeItem('dkc_user');
    localStorage.removeItem('dkc_keca');
    navigate('/');
  };

  useEffect(() => {
    checkAuth();
    loadData();
  }, []);

  // News Approval
  const handleApproveNews = async (id: string, status: 'approved' | 'rejected') => {
    try {
      const res = await fetch('/api/berita/status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, status })
      });
      if (res.ok) {
        loadData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleDeleteBerita = async (id: string) => {
    if (!await showConfirm('Apakah Anda yakin ingin menghapus berita ini?')) return;
    try {
      const res = await fetch('/api/berita/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id })
      });
      if (res.ok) {
        loadData();
      } else {
        const data = await res.json();
        alert('Gagal menghapus berita: ' + (data.error || 'Terjadi kesalahan'));
      }
    } catch (e: any) {
      console.error(e);
      alert('Gagal menghapus berita: ' + e.message);
    }
  };

  // Create News DKC
  const handleSaveNews = async (e: React.FormEvent) => {
    e.preventDefault();
    setNewsSaving(true);
    const userString = localStorage.getItem('dkc_user');
    const user = userString ? JSON.parse(userString) : null;

    try {
      const res = await fetch('/api/berita/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          judul: newsTitle,
          konten: newsContent,
          gambar_url: newsImage || 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&q=80&w=800',
          author_id: user?.user_id || null,
          author_name: user?.nama || 'Admin DKC',
          status: 'approved',
          published_at: new Date().toISOString()
        })
      });

      if (res.ok) {
        setNewsTitle('');
        setNewsContent('');
        setNewsImage('');
        setEditingNewsId(null);
        setEditingNewsAuthor(null);
        alert(editingNewsId ? 'Berita berhasil diperbarui!' : 'Berita resmi DKC berhasil diterbitkan!');
        loadData();
      } else {
        const errData = await res.json().catch(() => ({}));
        alert(`Gagal menerbitkan berita: ${errData.error || 'Terjadi kesalahan'}`);
      }
    } catch (e) {
      console.error(e);
      alert('Gagal menerbitkan berita: koneksi bermasalah.');
    } finally {
      setNewsSaving(false);
    }
  };

  // Kompres gambar di browser lalu upload ke Cloudinary (tidak ada lagi paste link manual)
  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>, target: 'news' | 'informasi' | 'hero' | 'personalia' | 'agendaLogo') => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (target === 'agendaLogo') {
      setAgendaLogoUploading(true);
    }

    try {
      const url = await compressAndUploadFile(file, 'gambar');
      if (target === 'news') {
        setNewsImage(url);
      } else if (target === 'hero') {
        setHeroBgImageUrl(url);
      } else if (target === 'personalia') {
        setNewPersonFoto(url);
      } else if (target === 'agendaLogo') {
        setAgendaLogoUrl(url);
      }
    } catch (err) {
      console.error(err);
      alert('Gagal mengunggah/kompres gambar. Coba lagi ya bro.');
    } finally {
      if (target === 'agendaLogo') {
        setAgendaLogoUploading(false);
      }
    }
  };

  // Upload berkas Pusat Unduhan Berkas ke Uploadcare (bukan Cloudinary), link disimpan lewat /api/informasi/save ke Supabase
  const handleInformasiFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setInfoUploading(true);
    try {
      const url = await compressAndUploadToUploadcare(file);
      setInfoFileUrl(url);
    } catch (err) {
      console.error(err);
      alert('Gagal mengunggah berkas ke Uploadcare. Coba lagi ya bro.');
    } finally {
      setInfoUploading(false);
    }
  };

  const handleSaveInformasi = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!infoJudul || !infoFileUrl) {
      alert('Judul dan berkas wajib diisi.');
      return;
    }
    setInfoSaving(true);
    try {
      const res = await fetch('/api/informasi/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          judul: infoJudul,
          deskripsi: infoDeskripsi,
          tipe: infoTipe,
          file_url: infoFileUrl
        })
      });
      if (res.ok) {
        setInfoJudul('');
        setInfoDeskripsi('');
        setInfoTipe('dokumen');
        setInfoFileUrl('');
        alert('Berkas berhasil ditambahkan ke Pusat Unduhan Berkas!');
        loadData();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setInfoSaving(false);
    }
  };

  const handleDeleteInformasi = async (id: string) => {
    if (!await showConfirm('Hapus berkas ini dari Pusat Unduhan Berkas?')) return;
    try {
      const res = await fetch('/api/informasi/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id })
      });
      if (res.ok) loadData();
    } catch (err) {
      console.error(err);
    }
  };

  const resetPersonaliaForm = () => {
    setNewPersonNama('');
    setNewPersonJabatan('');
    setNewPersonGolongan('pandega');
    setNewPersonFoto('');
    setNewPersonExtra(emptyPersonaliaExtra());
    setEditingPersonaliaId(null);
  };

  const handleAddPersonalia = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPersonNama || !newPersonJabatan) return;
    setPersonaliaSaving(true);
    try {
      const res = await fetch('/api/personalia/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: editingPersonaliaId || undefined,
          owner_type: 'dkc',
          nama: newPersonNama,
          jabatan: newPersonJabatan,
          golongan: newPersonGolongan,
          foto_url: newPersonFoto || 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=400',
          ...serializeExtra(newPersonExtra)
        })
      });
      if (res.ok) {
        resetPersonaliaForm();
        alert('Struktur Pengurus DKC berhasil diperbarui!');
        loadData();
      } else {
        const errData = await res.json().catch(() => ({}));
        alert('Gagal menyimpan data personalia.' + (errData.error ? '\n' + errData.error : ''));
      }
    } catch (e) {
      console.error(e);
      alert('Gagal menyimpan data personalia: koneksi bermasalah.');
    } finally {
      setPersonaliaSaving(false);
    }
  };

  // Delete Personalia DKC
  const handleDeletePersonalia = async (id: string) => {
    if (!await showConfirm('Hapus pengurus ini dari struktur DKC?')) return;
    try {
      const res = await fetch('/api/personalia/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id })
      });
      if (res.ok) {
        loadData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Upload Juknis / Surat Edaran kegiatan ke Uploadcare (opsional)
  const handleAgendaDocUpload = async (e: React.ChangeEvent<HTMLInputElement>, target: 'juknis' | 'surat_edaran') => {
    const file = e.target.files?.[0];
    if (!file) return;
    setAgendaDocUploading(target);
    try {
      const url = await compressAndUploadToUploadcare(file);
      if (target === 'juknis') {
        setAgendaJuknisUrl(url);
        setAgendaJuknisName(file.name);
      } else {
        setAgendaSuratEdaranUrl(url);
        setAgendaSuratEdaranName(file.name);
      }
    } catch (err) {
      console.error(err);
      alert('Gagal mengunggah berkas ke Uploadcare. Coba lagi ya bro.');
    } finally {
      setAgendaDocUploading(null);
      e.target.value = '';
    }
  };

  const clearAgendaDoc = (target: 'juknis' | 'surat_edaran') => {
    if (target === 'juknis') { setAgendaJuknisUrl(''); setAgendaJuknisName(''); }
    else { setAgendaSuratEdaranUrl(''); setAgendaSuratEdaranName(''); }
  };

  // Create Agenda
  const handleSaveAgenda = async (e: React.FormEvent) => {
    e.preventDefault();
    setAgendaSaving(true);

    try {
      const startVal = agendaIsDateDecided ? agendaStart : `${agendaBulanRencana}-01`;
      const endVal = agendaIsDateDecided ? agendaEnd : `${agendaBulanRencana}-01`;

      const res = await fetch('/api/agenda/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          nama_kegiatan: agendaName,
          tempat: agendaPlace,
          tanggal_mulai: startVal,
          tanggal_selesai: endVal,
          estimasi_peserta: agendaEst,
          jenis: agendaType,
          tingkat: agendaLevel,
          status_publikasi: true,
          is_aktif_pendaftaran: false,
          is_tanggal_diputuskan: agendaIsDateDecided,
          bulan_rencana: agendaBulanRencana,
          logo_url: agendaLogoUrl,
          juknis_url: agendaJuknisUrl || null,
          surat_edaran_url: agendaSuratEdaranUrl || null,
          camp_fee: agendaIsCampFee ? agendaCampFee : 0,
          is_camp_fee_required: agendaIsCampFee
        })
      });

      if (res.ok) {
        setAgendaName('');
        setAgendaPlace('');
        setAgendaStart('');
        setAgendaEnd('');
        setAgendaEst(100);
        setAgendaIsDateDecided(true);
        setAgendaLogoUrl('');
        setAgendaJuknisUrl('');
        setAgendaJuknisName('');
        setAgendaSuratEdaranUrl('');
        setAgendaSuratEdaranName('');
        setAgendaIsCampFee(false);
        setAgendaCampFee(0);
        alert('Agenda kegiatan berhasil ditambahkan!');
        loadData();
      }
    } catch (e) {
      console.error(e);
    } finally {
      setAgendaSaving(false);
    }
  };

  // Delete Agenda (butuh ketik frasa konfirmasi persis lewat popup)
  const openDeleteAgendaModal = (agenda: AgendaKegiatan) => {
    setDeleteConfirmText('');
    setAgendaToDelete(agenda);
  };

  const closeDeleteAgendaModal = () => {
    if (isDeletingAgenda) return;
    setAgendaToDelete(null);
    setDeleteConfirmText('');
  };

  const handleDeleteAgenda = async () => {
    if (!agendaToDelete || deleteConfirmText !== HAPUS_KEGIATAN_PHRASE || isDeletingAgenda) return;
    setIsDeletingAgenda(true);
    try {
      const res = await fetch('/api/agenda/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: agendaToDelete.id })
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || 'Terjadi kesalahan');
      }
      setAgendaToDelete(null);
      setDeleteConfirmText('');
      loadData();
      alert('Kegiatan berhasil dihapus.');
    } catch (e: any) {
      console.error(e);
      alert('Gagal menghapus kegiatan: ' + (e.message || 'Terjadi kesalahan'));
    } finally {
      setIsDeletingAgenda(false);
    }
  };

  const handleOpenDashboard = async (agenda: AgendaKegiatan) => {
    setSelectedDashboardAgenda(agenda);
    try {
      const configRes = await fetch(`/api/agenda/${agenda.id}/config`);
      const config = await configRes.json();
      if (config) {
        setFormFields(ensureCoreFields(config.form_schema));
        setPendaftaranTipe(config.tipe_pendaftaran || 'keduanya');
      } else {
        setFormFields([]);
      }

      // Load registered participants
      const registrantsRes = await fetch(`/api/agenda/${agenda.id}/registrants`);
      const regs = await registrantsRes.json();
      setRegistrants(regs);

      // Load tagihan kolektif
      const tagihanRes = await fetch(`/api/tagihan_kolektif?agenda_id=${agenda.id}`);
      const tagihanList = await tagihanRes.json();
      setTagihanKwarranList(tagihanList);
    } catch (e) {
      console.error(e);
    }
  };

  // Form Config Open Builder
  const handleOpenFormBuilder = async (agenda: AgendaKegiatan) => {
    setSelectedBuilderAgenda(agenda);
    try {
      const configRes = await fetch(`/api/agenda/${agenda.id}/config`);
      const config = await configRes.json();
      if (config) {
        setFormFields(ensureCoreFields(config.form_schema));
        setPendaftaranTipe(config.tipe_pendaftaran || 'keduanya');
        setIsQrValidasi(config.is_qr_validasi ?? true);
        setIsQrCheckin(config.is_qr_checkin ?? false);
      } else {
        setFormFields(ensureCoreFields([]));
        setPendaftaranTipe('keduanya');
        setIsQrValidasi(true);
        setIsQrCheckin(false);
      }

      // Load registered participants
      const registrantsRes = await fetch(`/api/agenda/${agenda.id}/registrants`);
      const regs = await registrantsRes.json();
      setRegistrants(regs);
    } catch (e) {
      console.error(e);
    }
  };

  // Save Form Schema
  const handleSaveFormSchema = async () => {
    if (!selectedBuilderAgenda) return;
    try {
      const res = await fetch(`/api/agenda/${selectedBuilderAgenda.id}/config`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          form_schema: ensureCoreFields(formFields),
          tipe_pendaftaran: pendaftaranTipe,
          is_qr_validasi: isQrValidasi,
          is_qr_checkin: isQrCheckin
        })
      });
      if (res.ok) {
        alert('Konfigurasi formulir pendaftaran dinamis berhasil disimpan!');
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleExportExcel = () => {
    if (!selectedDashboardAgenda || registrants.length === 0) {
      alert("Tidak ada data pendaftar untuk diexport.");
      return;
    }

    const headerCols = ['No', 'Waktu Daftar', 'Status Kehadiran', 'Waktu Hadir', 'Tipe Pendaftaran', 'Asal Kwarran'];
    formFields.filter(f => !f.auto).forEach(f => headerCols.push(f.label));
    
    const rows: any[][] = [];
    rows.push(headerCols);

    registrants.forEach((reg, index) => {
      const kwarran = reg.kecamatan_id 
        ? (kecamatanList.find((k: any) => k.id === reg.kecamatan_id)?.nama_kecamatan || reg.kecamatan_id)
        : '-';

      const isHadir = reg.data_peserta._is_hadir ? 'HADIR' : 'BELUM HADIR';
      const waktuHadir = reg.data_peserta._waktu_hadir ? new Date(reg.data_peserta._waktu_hadir).toLocaleString('id-ID') : '-';

      const rowData = [
        (index + 1).toString(),
        new Date(reg.created_at).toLocaleString('id-ID'),
        isHadir,
        waktuHadir,
        reg.tipe,
        kwarran
      ];

      formFields.filter(f => !f.auto).forEach(f => {
        rowData.push(reg.data_peserta[f.id] || '-');
      });

      rows.push(rowData);
    });

    const worksheet = XLSX.utils.aoa_to_sheet(rows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Pendaftar');
    const filename = `Data_Pendaftar_${selectedDashboardAgenda.nama_kegiatan.replace(/\s+/g, '_')}.xlsx`;
    
    XLSX.writeFile(workbook, filename);
  };

  const handleScanSuccess = async (decodedText: string) => {
    // decodedText is the ID of the pendaftaran
    try {
      const res = await fetch(`/api/pendaftaran/checkin/${decodedText}`, {
        method: 'POST'
      });
      if (res.ok) {
        alert('Check-in Berhasil!');
        // Reload data registrants if dashboard is open
        if (selectedDashboardAgenda) {
          handleOpenDashboard(selectedDashboardAgenda);
        }
      } else {
        alert('Gagal check-in atau ID pendaftar tidak valid.');
      }
    } catch (e) {
      console.error(e);
      alert('Terjadi kesalahan saat check-in.');
    }
  };

  const handleMarkLunas = async (id: string) => {
    if (!await showConfirm('Yakin ingin menandai peserta ini sudah lunas?')) return;
    try {
      const res = await fetch(`/api/pendaftaran/lunas/${id}`, { method: 'POST' });
      if (res.ok) {
        alert('Berhasil ditandai Lunas!');
        if (selectedDashboardAgenda) {
          handleOpenDashboard(selectedDashboardAgenda);
        }
        if (viewRegistrant && viewRegistrant.id === id) {
          setViewRegistrant((prev: any) => ({
            ...prev,
            data_peserta: { ...prev.data_peserta, _is_lunas: true, _waktu_lunas: new Date().toISOString() }
          }));
        }
      } else {
        alert('Gagal menandai lunas.');
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Toggle Pendaftaran Aktif (optimistic: switch langsung bergeser, rollback jika gagal)
  const handleTogglePendaftaran = async (agenda: AgendaKegiatan) => {
    if (togglingAgendaId === agenda.id) return;
    const next = !agenda.is_aktif_pendaftaran;
    setTogglingAgendaId(agenda.id);
    setAgendaList(prev => prev.map(a => a.id === agenda.id ? { ...a, is_aktif_pendaftaran: next } : a));
    try {
      const res = await fetch('/api/agenda/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...agenda,
          is_aktif_pendaftaran: next
        })
      });
      if (!res.ok) throw new Error('Gagal menyimpan status pendaftaran');
    } catch (e) {
      console.error(e);
      setAgendaList(prev => prev.map(a => a.id === agenda.id ? { ...a, is_aktif_pendaftaran: !next } : a));
      alert('Gagal mengubah status pendaftaran. Coba lagi.');
    } finally {
      setTogglingAgendaId(null);
    }
  };

  // Create User DKR / SAKA

  const handleResetPassword = async (userId: string, userName: string) => {
    if (!confirm(`Anda yakin ingin mereset kata sandi untuk akun ${userName}?`)) return;
    
    try {
      const res = await fetch('/api/users/reset_password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_id: userId }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        alert(`Kata sandi untuk ${userName} berhasil direset!\n\nKata Sandi Baru: ${data.newPassword}\n\nHarap salin kata sandi ini dan berikan kepada pengguna yang bersangkutan.`);
      } else {
        alert(`Gagal mereset kata sandi: ${data.error}`);
      }
    } catch (error) {
      alert('Terjadi kesalahan saat mereset kata sandi.');
    }
  };

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newRole === 'user' && (!newEmail || !newPassword || !newKecaId || !newNama)) {
      alert('Mohon isi seluruh bidang pendaftaran user DKR');
      return;
    }
    if (newRole === 'saka' && (!newEmail || !newPassword || !newSakaId || !newNama)) {
      alert('Mohon isi seluruh bidang pendaftaran user SAKA');
      return;
    }

    try {
      const res = await fetch('/api/users/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: newEmail,
          password: newPassword,
          role: newRole,
          kecamatan_id: newRole === 'user' ? newKecaId : undefined,
          saka_id: newRole === 'saka' ? newSakaId : undefined,
          nama: newNama
        })
      });
      if (res.ok) {
        alert(newRole === 'saka' ? 'Akun SAKA Tingkat Kabupaten berhasil dibuat!' : 'Akun DKR Kecamatan berhasil dibuat!');
        setNewEmail('');
        setNewPassword('');
        setNewNama('');
        setNewKecaId('');
        setNewSakaId('');
        setNewRole('user');
        loadData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Toggle Active Kecamatan status
  const handleToggleKecamatanActive = async (id: string) => {
    try {
      const res = await fetch('/api/kecamatan/toggle-active', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id })
      });
      if (res.ok) {
        loadData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Toggle Active SAKA status
  const handleToggleSakaActive = async (id: string) => {
    try {
      const res = await fetch('/api/saka/toggle-active', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id })
      });
      if (res.ok) {
        loadData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const rgbToHex = (r: number, g: number, b: number): string => {
    const toHex = (c: number) => {
      const hex = Math.max(0, Math.min(255, c)).toString(16);
      return hex.length === 1 ? '0' + hex : hex;
    };
    return `#${toHex(r)}${toHex(g)}${toHex(b)}`.toUpperCase();
  };

  const hexToRgb = (hex: string) => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : null;
  };

  const autoAssignColors = (colors: string[]) => {
    if (colors.length === 0) return;
    
    const colorDetails = colors.map(hex => {
      const rgb = hexToRgb(hex);
      if (!rgb) return { hex, r: 128, g: 128, b: 128, lum: 128, sat: 0, isGreen: false, isOrange: false };
      
      const max = Math.max(rgb.r, rgb.g, rgb.b);
      const min = Math.min(rgb.r, rgb.g, rgb.b);
      const l = (max + min) / 2;
      let s = 0;
      if (max !== min) {
        s = l > 0.5 ? (max - min) / (2.0 - max - min) : (max - min) / (max + min);
      }
      
      const lum = (rgb.r * 299 + rgb.g * 587 + rgb.b * 114) / 1000;
      const isGreen = rgb.g > rgb.r * 1.1 && rgb.g > rgb.b * 1.1;
      const isOrange = rgb.r > rgb.b * 1.5 && rgb.g > rgb.b;
      
      return { hex, r: rgb.r, g: rgb.g, b: rgb.b, lum, sat: s, isGreen, isOrange };
    });
    
    const darks = [...colorDetails].sort((a, b) => a.lum - b.lum);
    const darkest = darks[0]?.hex || '#5C4033';
    const midColor = darks[1]?.hex || '#8B7355';
    
    const orangeCandidate = colorDetails.find(c => c.isOrange) || 
                            [...colorDetails].sort((a, b) => (b.r - b.b) - (a.r - a.b))[0];
    const orangeColor = orangeCandidate?.hex || '#F5A623';
    
    const greenCandidate = colorDetails.find(c => c.isGreen) || 
                           [...colorDetails].sort((a, b) => (b.g - b.r) - (a.g - a.r))[0];
    const greenColor = greenCandidate?.hex || '#4CAF50';
    
    setBrandBrownDark(darkest);
    setBrandBrownMid(midColor);
    setBrandOrange(orangeColor);
    setBrandGreen(greenColor);
  };

  const handleImageColorUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsExtracting(true);
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          setIsExtracting(false);
          return;
        }
        
        canvas.width = 50;
        canvas.height = 50;
        ctx.drawImage(img, 0, 0, 50, 50);
        
        const imgData = ctx.getImageData(0, 0, 50, 50).data;
        const colorCounts: Record<string, number> = {};
        
        for (let i = 0; i < imgData.length; i += 4) {
          const r = imgData[i];
          const g = imgData[i+1];
          const b = imgData[i+2];
          const a = imgData[i+3];
          
          if (a < 200) continue;
          
          const rRound = Math.round(r / 32) * 32;
          const gRound = Math.round(g / 32) * 32;
          const bRound = Math.round(b / 32) * 32;
          
          const hex = rgbToHex(rRound, gRound, bRound);
          colorCounts[hex] = (colorCounts[hex] || 0) + 1;
        }
        
        let colors = Object.keys(colorCounts).map(hex => ({
          hex,
          count: colorCounts[hex]
        }));
        
        colors.sort((a, b) => b.count - a.count);
        
        const uniqueColors: string[] = [];
        for (const item of colors) {
          const rgb = hexToRgb(item.hex);
          if (!rgb) continue;
          
          const brightness = (rgb.r * 299 + rgb.g * 587 + rgb.b * 114) / 1000;
          if (brightness > 245 || brightness < 10) continue;
          
          const isTooSimilar = uniqueColors.some(existingHex => {
            const extRgb = hexToRgb(existingHex);
            if (!extRgb) return false;
            const dist = Math.sqrt(
              Math.pow(rgb.r - extRgb.r, 2) +
              Math.pow(rgb.g - extRgb.g, 2) +
              Math.pow(rgb.b - extRgb.b, 2)
            );
            return dist < 65;
          });
          
          if (!isTooSimilar) {
            uniqueColors.push(item.hex);
          }
          
          if (uniqueColors.length >= 8) break;
        }
        
        if (uniqueColors.length < 4) {
          for (const item of colors) {
            if (!uniqueColors.includes(item.hex)) {
              uniqueColors.push(item.hex);
            }
            if (uniqueColors.length >= 8) break;
          }
        }
        
        setExtractedColors(uniqueColors);
        setIsExtracting(false);
        autoAssignColors(uniqueColors);
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleResetTheme = async () => {
    if (await showConfirm('Apakah Anda yakin ingin mengembalikan warna landing page ke setelan awal (oranye, hijau, & cokelat)?')) {
      setBrandOrange('#F5A623');
      setBrandGreen('#4CAF50');
      setBrandBrownDark('#5C4033');
      setBrandBrownMid('#8B7355');
    }
  };

  // Save Site Content
  const handleSaveSiteContent = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const resHero = await fetch('/api/site_content/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          section_key: 'hero',
          content: {
            title: heroTitle,
            subtitle: heroSubtitle,
            lead: heroLead,
            cta_text: heroCta,
            badge_text: heroBadge,
            bg_image_url: heroBgImageUrl,
            bg_opacity: Number(heroBgOpacity)
          }
        })
      });

      await fetch('/api/site_content/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          section_key: 'medsos_dkc',
          content: { ig: dkcMedsosIg, yt: dkcMedsosYt, tk: dkcMedsosTk }
        })
      });

      const resTheme = await fetch('/api/site_content/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          section_key: 'theme',
          content: {
            brandOrange,
            brandGreen,
            brandBrownDark,
            brandBrownMid
          }
        })
      });

      if (resHero.ok && resTheme.ok) {
        alert('Konten dan tema warna landing page berhasil diperbarui!');
        loadData();
      } else {
        alert('Gagal menyimpan pembaruan.');
      }
    } catch (e) {
      console.error(e);
    }
  };

  
  const pendingLaporanCount = laporanList.filter(l => l.status === 'pending').length;
  const pendingBeritaCount = beritaList.filter(b => b.status === 'pending').length;
  const suratBaruCount = suratList.filter(sr => sr.status === 'terkirim').length;
  const totalNotifs = pendingLaporanCount + pendingBeritaCount + suratBaruCount;

  const totalPenegak = dataPotensial.reduce((acc, curr) => acc + curr.jumlah_penegak_l + curr.jumlah_penegak_p, 0);
  const totalPandega = dataPotensial.reduce((acc, curr) => acc + curr.jumlah_pandega_l + curr.jumlah_pandega_p, 0);

  return (
    <div className="min-h-screen bg-dash-canvas flex flex-col md:flex-row">
      
      {/* 1. TOP APP BAR (Mobile Only) */}
      <div className="md:hidden bg-white flex items-center justify-between px-4 py-3 shrink-0 sticky top-0 z-40 shadow-sm border-b border-gray-100">
        <div className="flex items-center gap-3">
          <button onClick={() => setIsMobileMenuOpen(true)} className="text-gray-800 p-1">
            <Menu className="w-6 h-6" />
          </button>
          <div className="flex items-center gap-2">
            <img src="/logo.png" alt="Logo" className="w-6 h-6 object-contain" />
            <h2 className="font-extrabold text-[10px] sm:text-xs tracking-wider font-display text-gray-800 uppercase leading-tight mt-0.5">Ambacana Tatar Sukapura</h2>
          </div>
        </div>
        <div className="flex items-center gap-4 relative">
          <button onClick={() => { setIsNotifMenuOpen(!isNotifMenuOpen); setIsProfileMenuOpen(false); }} className="relative text-gray-500 p-1">
            <Bell className="w-5 h-5" />
            {totalNotifs > 0 && <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full border border-white"></span>}
          </button>
          
          {isNotifMenuOpen && (
            <div className="absolute top-10 right-10 w-64 bg-white rounded-2xl shadow-xl border border-gray-100 p-3 z-50">
              <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest border-b pb-2 mb-2">Notifikasi</h4>
              {totalNotifs === 0 ? (
                <p className="text-xs text-gray-500 text-center py-4">Belum ada notifikasi baru</p>
              ) : (
                <div className="space-y-2">
                  {pendingLaporanCount > 0 && (
                    <button onClick={() => { setActiveTab('laporan'); setIsNotifMenuOpen(false); }} className="w-full text-left p-2 rounded-xl hover:bg-gray-50 text-xs text-brand-brown-dark flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-brand-orange"></div>
                      <span><strong>{pendingLaporanCount} Laporan</strong> menunggu verifikasi</span>
                    </button>
                  )}
                  {pendingBeritaCount > 0 && (
                    <button onClick={() => { setActiveTab('berita'); setIsNotifMenuOpen(false); }} className="w-full text-left p-2 rounded-xl hover:bg-gray-50 text-xs text-brand-brown-dark flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-brand-green"></div>
                      <span><strong>{pendingBeritaCount} Warta</strong> menunggu persetujuan</span>
                    </button>
                  )}
                  {suratBaruCount > 0 && (
                    <button onClick={() => { setActiveTab('surat'); setIsNotifMenuOpen(false); }} className="w-full text-left p-2 rounded-xl hover:bg-gray-50 text-xs text-brand-brown-dark flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-red-500"></div>
                      <span><strong>{suratBaruCount} Surat baru</strong> dari DKR</span>
                    </button>
                  )}
                </div>
              )}
            </div>
          )}

          <button onClick={() => { setIsProfileMenuOpen(!isProfileMenuOpen); setIsNotifMenuOpen(false); }} className="w-8 h-8 rounded-full bg-brand-green flex items-center justify-center text-white text-xs font-bold shadow-md cursor-pointer">
            AD
          </button>

          {isProfileMenuOpen && (
            <div className="absolute top-10 right-0 w-48 bg-white rounded-2xl shadow-xl border border-gray-100 p-2 z-50">
              <button onClick={() => { setIsChangePasswordModalOpen(true); setIsProfileMenuOpen(false); }} className="w-full text-left px-4 py-2.5 rounded-xl hover:bg-gray-50 text-xs font-bold text-gray-700">
                Pengaturan Akun
              </button>
              <button onClick={handleLogout} className="w-full text-left px-4 py-2.5 rounded-xl hover:bg-red-50 text-xs font-bold text-brand-red">
                Keluar Sesi
              </button>
            </div>
          )}
        </div>
      </div>

      {/* 2. SIDEBAR BACKDROP (Mobile Only) */}
      {isMobileMenuOpen && (
        <div 
          className="md:hidden fixed inset-0 bg-black/60 z-[45] backdrop-blur-sm transition-opacity"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Desktop Sidebar (Desktop Only) with Gradient Green matching the uploaded reference */}
      <aside className={`fixed md:relative inset-y-0 left-0 z-50 transform ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 flex ${isSidebarCollapsed ? 'w-20' : 'w-64'} transition-all duration-300 bg-gradient-to-b from-[#0E9F6E] via-[#10B981] to-[#065F46] text-white flex-col shrink-0 border-r border-[#064E3B] shadow-2xl md:shadow-none`}>
        <div className="p-5 border-b border-white/10 flex flex-col items-center">
          <div className={`flex items-center gap-3 w-full ${isSidebarCollapsed ? 'justify-center' : 'justify-between'}`}>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center border-2 border-emerald-400 p-1 shrink-0 shadow-sm overflow-hidden">
                <img src="/logo.png" alt="Logo DKC" className="w-full h-full object-contain" />
              </div>
              {!isSidebarCollapsed && (
                <div className="text-left">
                  <h2 className="font-display font-black text-xs tracking-tight text-white uppercase leading-tight">DKC TASIKMALAYA</h2>
                  <p className="text-[9px] text-[#A7F3D0] font-mono mt-0.5 tracking-wider uppercase leading-none">AMBACANA TATAR SUKAPURA</p>
                </div>
              )}
            </div>
            {!isSidebarCollapsed && (
              <button onClick={() => setIsSidebarCollapsed(true)} className="p-1 hover:bg-white/10 rounded-lg text-white">
                <PanelLeft className="w-5 h-5" />
              </button>
            )}
          </div>
          
          {isSidebarCollapsed && (
            <button onClick={() => setIsSidebarCollapsed(false)} className="mt-4 p-2 hover:bg-white/10 rounded-lg text-white">
              <PanelLeft className="w-5 h-5" />
            </button>
          )}
          
          {/* ACCESS BADGE AS SHOWN IN THE USER REFERENCE IMAGE */}
          {!isSidebarCollapsed && (
            <div className="w-full bg-black/15 border border-emerald-500/20 rounded-2xl p-3 text-center mt-4">
              
            <p className="text-[9px] font-bold tracking-widest text-[#A7F3D0] uppercase font-mono">AKSES MASUK:</p>
            <h3 className="text-xs font-black tracking-widest text-white uppercase mt-0.5">ADMINISTRATOR</h3>
          
            </div>
          )}
        </div>

        <nav className="p-4 space-y-1.5 flex-1 font-sans overflow-y-auto">
          {/* Kategori: RINGKASAN */}
          <p className={`px-4 pt-1 pb-1 text-[9px] font-bold text-emerald-200/70 uppercase tracking-widest font-mono ${isSidebarCollapsed ? 'text-center opacity-50' : ''}`}>
            {isSidebarCollapsed ? '•' : 'Ringkasan'}
          </p>
          <button 
            title={isSidebarCollapsed ? 'Dashboard Rekap' : ''} 
            onClick={() => { setActiveTab('dashboard'); setIsMobileMenuOpen(false); }}
            className={`w-full text-left px-4 py-3.5 rounded-2xl text-xs font-bold transition-all flex items-center gap-2.5 cursor-pointer ${isSidebarCollapsed ? 'justify-center px-0' : ''} ${
              activeTab === 'dashboard' ? 'bg-white text-[#065F46] shadow-md' : 'text-emerald-50 hover:bg-white/10'
            }`}
          >
            <LayoutDashboard className="w-4 h-4 shrink-0" />
            {!isSidebarCollapsed && <span>Dashboard Rekap</span>}</button>

          {/* Kategori: DATA POTENSIAL */}
          <p className={`px-4 pt-3 pb-1 text-[9px] font-bold text-emerald-200/70 uppercase tracking-widest font-mono ${isSidebarCollapsed ? 'text-center opacity-50' : ''}`}>
            {isSidebarCollapsed ? '•' : 'Data Potensial'}
          </p>
          <button 
            title={isSidebarCollapsed ? 'Potensial DKR (Ranting)' : ''} 
            onClick={() => { setActiveTab('potensial_dkr'); setIsMobileMenuOpen(false); }}
            className={`w-full text-left px-4 py-3.5 rounded-2xl text-xs font-bold transition-all flex items-center gap-2.5 cursor-pointer ${isSidebarCollapsed ? 'justify-center px-0' : ''} ${
              activeTab === 'potensial_dkr' ? 'bg-white text-[#065F46] shadow-md' : 'text-emerald-50 hover:bg-white/10'
            }`}
          >
            <BarChart2 className="w-4 h-4 shrink-0" />
            {!isSidebarCollapsed && <span>Potensial DKR (Ranting)</span>}</button>

          <button 
            title={isSidebarCollapsed ? 'Potensial SAKA (Karya)' : ''} 
            onClick={() => { setActiveTab('potensial_saka'); setIsMobileMenuOpen(false); }}
            className={`w-full text-left px-4 py-3.5 rounded-2xl text-xs font-bold transition-all flex items-center gap-2.5 cursor-pointer ${isSidebarCollapsed ? 'justify-center px-0' : ''} ${
              activeTab === 'potensial_saka' ? 'bg-white text-[#065F46] shadow-md' : 'text-emerald-50 hover:bg-white/10'
            }`}
          >
            <BarChart2 className="w-4 h-4 shrink-0" />
            {!isSidebarCollapsed && <span>Potensial SAKA (Karya)</span>}</button>

          <button 
            title={isSidebarCollapsed ? 'Daftar Pangkalan/Gudep' : ''} 
            onClick={() => { setActiveTab('pangkalan'); setIsMobileMenuOpen(false); }}
            className={`w-full text-left px-4 py-3.5 rounded-2xl text-xs font-bold transition-all flex items-center gap-2.5 cursor-pointer ${isSidebarCollapsed ? 'justify-center px-0' : ''} ${
              activeTab === 'pangkalan' ? 'bg-white text-[#065F46] shadow-md' : 'text-emerald-50 hover:bg-white/10'
            }`}
          >
            <Building className="w-4 h-4 shrink-0" />
            {!isSidebarCollapsed && <span>Daftar Pangkalan/Gudep</span>}</button>

          {/* Kategori: KONTEN & PUBLIKASI */}
          <p className={`px-4 pt-3 pb-1 text-[9px] font-bold text-emerald-200/70 uppercase tracking-widest font-mono ${isSidebarCollapsed ? 'text-center opacity-50' : ''}`}>
            {isSidebarCollapsed ? '•' : 'Konten & Publikasi'}
          </p>
          <button 
            title={isSidebarCollapsed ? 'Persetujuan Warta' : ''} 
            onClick={() => { setActiveTab('berita'); setIsMobileMenuOpen(false); }}
            className={`w-full text-left px-4 py-3.5 rounded-2xl text-xs font-bold transition-all flex items-center gap-2.5 cursor-pointer ${isSidebarCollapsed ? 'justify-center px-0' : ''} ${
              activeTab === 'berita' ? 'bg-white text-[#065F46] shadow-md' : 'text-emerald-50 hover:bg-white/10'
            }`}
          >
            <FileText className="w-4 h-4 shrink-0" />
            {!isSidebarCollapsed && <span>Persetujuan Warta</span>}</button>

          <button 
            title={isSidebarCollapsed ? 'Kegiatan & Form Builder' : ''} 
            onClick={() => { setActiveTab('agenda'); setIsMobileMenuOpen(false); }}
            className={`w-full text-left px-4 py-3.5 rounded-2xl text-xs font-bold transition-all flex items-center gap-2.5 cursor-pointer ${isSidebarCollapsed ? 'justify-center px-0' : ''} ${
              activeTab === 'agenda' ? 'bg-white text-[#065F46] shadow-md' : 'text-emerald-50 hover:bg-white/10'
            }`}
          >
            <Calendar className="w-4 h-4 shrink-0" />
            {!isSidebarCollapsed && <span>Kegiatan & Form Builder</span>}</button>

          <button 
            title={isSidebarCollapsed ? 'Surat Masuk DKR' : ''} 
            onClick={() => { setActiveTab('surat'); setIsMobileMenuOpen(false); }}
            className={`w-full text-left px-4 py-3.5 rounded-2xl text-xs font-bold transition-all flex items-center gap-2.5 cursor-pointer ${isSidebarCollapsed ? 'justify-center px-0' : ''} ${
              activeTab === 'surat' ? 'bg-white text-[#065F46] shadow-md' : 'text-emerald-50 hover:bg-white/10'
            }`}
          >
            <span className="relative shrink-0">
              <MailIcon className="w-4 h-4" />
              {isSidebarCollapsed && suratBaruCount > 0 && <span className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full border border-white"></span>}
            </span>
            {!isSidebarCollapsed && <span className="flex-1">Surat Masuk DKR</span>}
            {!isSidebarCollapsed && suratBaruCount > 0 && (
              <span className="bg-red-500 text-white text-[9px] font-extrabold px-1.5 py-0.5 rounded-full">{suratBaruCount}</span>
            )}
          </button>

          <button 
            title={isSidebarCollapsed ? 'Personalia DKC' : ''} 
            onClick={() => { setActiveTab('personalia'); setIsMobileMenuOpen(false); }}
            className={`w-full text-left px-4 py-3.5 rounded-2xl text-xs font-bold transition-all flex items-center gap-2.5 cursor-pointer ${isSidebarCollapsed ? 'justify-center px-0' : ''} ${
              activeTab === 'personalia' ? 'bg-white text-[#065F46] shadow-md' : 'text-emerald-50 hover:bg-white/10'
            }`}
          >
            <Award className="w-4 h-4 shrink-0" />
            {!isSidebarCollapsed && <span>Personalia DKC</span>}</button>

          <button 
            title={isSidebarCollapsed ? 'Kelola Landingpage' : ''} 
            onClick={() => { setActiveTab('konten'); setIsMobileMenuOpen(false); }}
            className={`w-full text-left px-4 py-3.5 rounded-2xl text-xs font-bold transition-all flex items-center gap-2.5 cursor-pointer ${isSidebarCollapsed ? 'justify-center px-0' : ''} ${
              activeTab === 'konten' ? 'bg-white text-[#065F46] shadow-md' : 'text-emerald-50 hover:bg-white/10'
            }`}
          >
            <Settings className="w-4 h-4 shrink-0" />
            {!isSidebarCollapsed && <span>Kelola Landingpage</span>}</button>

          <button 
            title={isSidebarCollapsed ? 'Pengumuman Landingpage' : ''} 
            onClick={() => { setActiveTab('pengumuman'); setIsMobileMenuOpen(false); }}
            className={`w-full text-left px-4 py-3.5 rounded-2xl text-xs font-bold transition-all flex items-center gap-2.5 cursor-pointer ${isSidebarCollapsed ? 'justify-center px-0' : ''} ${
              activeTab === 'pengumuman' ? 'bg-white text-[#065F46] shadow-md' : 'text-emerald-50 hover:bg-white/10'
            }`}
          >
            <Megaphone className="w-4 h-4 shrink-0" />
            {!isSidebarCollapsed && <span>Pengumuman Landingpage</span>}</button>

          <button 
            title={isSidebarCollapsed ? 'Pusat Unduhan Berkas' : ''} 
            onClick={() => { setActiveTab('informasi'); setIsMobileMenuOpen(false); }}
            className={`w-full text-left px-4 py-3.5 rounded-2xl text-xs font-bold transition-all flex items-center gap-2.5 cursor-pointer ${isSidebarCollapsed ? 'justify-center px-0' : ''} ${
              activeTab === 'informasi' ? 'bg-white text-[#065F46] shadow-md' : 'text-emerald-50 hover:bg-white/10'
            }`}
          >
            <Download className="w-4 h-4 shrink-0" />
            {!isSidebarCollapsed && <span>Pusat Unduhan Berkas</span>}</button>

          {/* Kategori: MANAJEMEN AKUN */}
          <p className={`px-4 pt-3 pb-1 text-[9px] font-bold text-emerald-200/70 uppercase tracking-widest font-mono ${isSidebarCollapsed ? 'text-center opacity-50' : ''}`}>
            {isSidebarCollapsed ? '•' : 'Manajemen Akun'}
          </p>
          <button 
            title={isSidebarCollapsed ? 'User DKR Kecamatan' : ''}
            onClick={() => { setActiveTab('users_dkr'); setNewRole('user'); setIsMobileMenuOpen(false); }}
            className={`w-full text-left px-4 py-3.5 rounded-2xl text-xs font-bold transition-all flex items-center gap-2.5 cursor-pointer ${isSidebarCollapsed ? 'justify-center px-0' : ''} ${
              activeTab === 'users_dkr' ? 'bg-white text-[#065F46] shadow-md' : 'text-emerald-50 hover:bg-white/10'
            }`}
          >
            <Users className="w-4 h-4 shrink-0" />
            {!isSidebarCollapsed && <span>User DKR Kecamatan</span>}
          </button>

          <button 
            title={isSidebarCollapsed ? 'User SAKA Kabupaten' : ''}
            onClick={() => { setActiveTab('users_saka'); setNewRole('saka'); setIsMobileMenuOpen(false); }}
            className={`w-full text-left px-4 py-3.5 rounded-2xl text-xs font-bold transition-all flex items-center gap-2.5 cursor-pointer ${isSidebarCollapsed ? 'justify-center px-0' : ''} ${
              activeTab === 'users_saka' ? 'bg-white text-[#065F46] shadow-md' : 'text-emerald-50 hover:bg-white/10'
            }`}
          >
            <Users className="w-4 h-4 shrink-0" />
            {!isSidebarCollapsed && <span>User SAKA Kabupaten</span>}
          </button>

          {/* Kategori: VERIFIKASI LAPORAN */}
          <p className={`px-4 pt-3 pb-1 text-[9px] font-bold text-emerald-200/70 uppercase tracking-widest font-mono ${isSidebarCollapsed ? 'text-center opacity-50' : ''}`}>
            {isSidebarCollapsed ? '•' : 'Verifikasi Laporan'}
          </p>
          <button 
            title={isSidebarCollapsed ? 'Verifikasi Laporan 02GP & 01' : ''} 
            onClick={() => { setActiveTab('laporan'); setIsMobileMenuOpen(false); }}
            className={`w-full text-left px-4 py-3.5 rounded-2xl text-xs font-bold transition-all flex items-center gap-2.5 cursor-pointer ${isSidebarCollapsed ? 'justify-center px-0' : ''} ${
              activeTab === 'laporan' ? 'bg-white text-[#065F46] shadow-md' : 'text-emerald-50 hover:bg-white/10'
            }`}
          >
            <Award className="w-4 h-4 shrink-0" />
            {!isSidebarCollapsed && <span>Verifikasi Laporan 02GP & 01</span>}</button>
        </nav>

        {/* Desktop Logout Block */}
        <div className="p-4 border-t border-white/10 space-y-2">
          
          <button 
            title="Kembali ke Beranda"
            onClick={() => navigate('/')}
            className={`w-full bg-white/5 hover:bg-white/10 text-white font-bold text-[11px] py-2.5 rounded-xl uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer ${isSidebarCollapsed ? 'px-0' : ''}`}
          >
            {isSidebarCollapsed ? <LayoutDashboard className="w-4 h-4" /> : 'Kembali ke Beranda'}
          </button>
          <button 
            title="Keluar Sesi"
            onClick={handleLogout}
            className={`w-full bg-brand-red/10 hover:bg-brand-red/20 text-red-200 border border-brand-red/20 font-bold text-[11px] py-2.5 rounded-xl uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer ${isSidebarCollapsed ? 'px-0' : ''}`}
          >
            {isSidebarCollapsed ? <Check className="w-4 h-4" /> : 'Keluar Sesi'}
          </button>
        
        </div>
      </aside>

      {/* Main Content Pane */}
      <main className="flex-1 p-4 sm:p-10 pb-28 md:pb-10 overflow-y-auto">
        
        
          {/* Desktop Top Header (Notification & Profile) */}
          <div className="hidden md:flex justify-end items-center gap-4 mb-6 relative">
            <button onClick={() => { setIsNotifMenuOpen(!isNotifMenuOpen); setIsProfileMenuOpen(false); }} className="relative text-gray-500 hover:bg-gray-100 p-2 rounded-full transition-colors cursor-pointer">
              <Bell className="w-5 h-5" />
              {totalNotifs > 0 && <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border border-white"></span>}
            </button>
            
            {isNotifMenuOpen && (
              <div className="absolute top-12 right-12 w-64 bg-white rounded-2xl shadow-xl border border-gray-100 p-3 z-50">
                <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest border-b pb-2 mb-2">Notifikasi</h4>
                {totalNotifs === 0 ? (
                  <p className="text-xs text-gray-500 text-center py-4">Belum ada notifikasi baru</p>
                ) : (
                  <div className="space-y-2">
                    {pendingLaporanCount > 0 && (
                      <button onClick={() => { setActiveTab('laporan'); setIsNotifMenuOpen(false); }} className="w-full text-left p-2 rounded-xl hover:bg-gray-50 text-xs text-brand-brown-dark flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-brand-orange"></div>
                        <span><strong>{pendingLaporanCount} Laporan</strong> menunggu verifikasi</span>
                      </button>
                    )}
                    {pendingBeritaCount > 0 && (
                      <button onClick={() => { setActiveTab('berita'); setIsNotifMenuOpen(false); }} className="w-full text-left p-2 rounded-xl hover:bg-gray-50 text-xs text-brand-brown-dark flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-brand-green"></div>
                        <span><strong>{pendingBeritaCount} Warta</strong> menunggu persetujuan</span>
                      </button>
                    )}
                    {suratBaruCount > 0 && (
                      <button onClick={() => { setActiveTab('surat'); setIsNotifMenuOpen(false); }} className="w-full text-left p-2 rounded-xl hover:bg-gray-50 text-xs text-brand-brown-dark flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-red-500"></div>
                        <span><strong>{suratBaruCount} Surat baru</strong> dari DKR</span>
                      </button>
                    )}
                  </div>
                )}
              </div>
            )}

            <button onClick={() => { setIsProfileMenuOpen(!isProfileMenuOpen); setIsNotifMenuOpen(false); }} className="w-9 h-9 rounded-full bg-brand-green flex items-center justify-center text-white text-xs font-bold shadow-md cursor-pointer hover:scale-105 transition-transform">
              AD
            </button>

            {isProfileMenuOpen && (
              <div className="absolute top-12 right-0 w-48 bg-white rounded-2xl shadow-xl border border-gray-100 p-2 z-50">
                <button onClick={() => { setIsChangePasswordModalOpen(true); setIsProfileMenuOpen(false); }} className="w-full text-left px-4 py-2.5 rounded-xl hover:bg-gray-50 text-xs font-bold text-gray-700">
                  Pengaturan Akun
                </button>
                <button onClick={handleLogout} className="w-full text-left px-4 py-2.5 rounded-xl hover:bg-red-50 text-xs font-bold text-brand-red">
                  Keluar Sesi
                </button>
              </div>
            )}
          </div>

          {activeTab === 'dashboard' && <GreetingBanner name={user?.nama || 'Administrator'} role={user?.role} />}

          {/* Search Bar (Mobile Style) */}
          {activeTab === 'dashboard' && (
            <div className="mt-6 mb-8 relative">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <Search className="w-5 h-5 text-gray-400" />
              </div>
              <input 
                type="text" 
                placeholder="Cari menu atau layanan di sini..." 
                className="w-full bg-white border border-gray-200/60 rounded-2xl py-4 pl-12 pr-4 text-sm font-medium text-gray-700 shadow-sm focus:outline-none focus:border-brand-green focus:ring-2 focus:ring-brand-green/20"
              />
            </div>
          )}

        {/* TAB 1: DASHBOARD REKAP */}
        {activeTab === 'dashboard' && (
          <div className="space-y-8">
            <div className="border-b border-gray-200 pb-4">
              <h1 className="text-2xl font-display font-extrabold text-brand-brown-dark tracking-tight">Kinerja Cabang & Ranting</h1>
              <p className="text-xs text-gray-500 font-mono mt-1">Ikhtisar data real-time Penegak, Pandega, DKR, dan Pangkalan Aktif.</p>
            </div>

            {/* Bento Grid Metrics */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              
              {/* Metric 1 */}
              <div className="bg-white border border-gray-200 rounded-3xl p-6 shadow-sm flex items-center gap-4">
                <div className="w-12 h-12 bg-brand-orange/10 rounded-2xl flex items-center justify-center text-brand-orange shrink-0">
                  <Users className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-[10px] text-gray-400 font-mono uppercase font-semibold">Total Penegak</span>
                  <h3 className="text-2xl font-display font-black text-brand-brown-dark">{totalPenegak} <span className="text-xs font-normal text-gray-500">Jiwa</span></h3>
                </div>
              </div>

              {/* Metric 2 */}
              <div className="bg-white border border-gray-200 rounded-3xl p-6 shadow-sm flex items-center gap-4">
                <div className="w-12 h-12 bg-brand-green/10 rounded-2xl flex items-center justify-center text-brand-green shrink-0">
                  <Users className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-[10px] text-gray-400 font-mono uppercase font-semibold">Total Pandega</span>
                  <h3 className="text-2xl font-display font-black text-brand-brown-dark">{totalPandega} <span className="text-xs font-normal text-gray-500">Jiwa</span></h3>
                </div>
              </div>

              {/* Metric 3 */}
              <div className="bg-white border border-gray-200 rounded-3xl p-6 shadow-sm flex items-center gap-4">
                <div className="w-12 h-12 bg-brand-teal/10 rounded-2xl flex items-center justify-center text-brand-teal shrink-0">
                  <Building className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-[10px] text-gray-400 font-mono uppercase font-semibold">DKR Aktif (Sudah Punya Akun)</span>
                  <h3 className="text-2xl font-display font-black text-brand-brown-dark">
                    {kecamatanList.filter(k => userList.some(u => u.role === 'user' && u.kecamatan_id === k.id)).length} <span className="text-xs font-normal text-gray-500">Kec.</span>
                  </h3>
                </div>
              </div>

              {/* Metric 4 */}
              <div className="bg-white border border-gray-200 rounded-3xl p-6 shadow-sm flex items-center gap-4">
                <div className="w-12 h-12 bg-brand-blue/10 rounded-2xl flex items-center justify-center text-brand-blue shrink-0">
                  <Building className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-[10px] text-gray-400 font-mono uppercase font-semibold">Pangkalan Aktif</span>
                  <h3 className="text-2xl font-display font-black text-brand-brown-dark">
                    {pangkalanList.filter(p => p.status_aktif).length} <span className="text-xs font-normal text-gray-500">Gudep</span>
                  </h3>
                </div>
              </div>

            </div>

            {/* Quick Summary list */}
            <div className="bg-white border border-gray-200 rounded-3xl p-6 sm:p-8 shadow-sm">
              <h3 className="font-extrabold text-base text-brand-brown-dark mb-4 tracking-tight border-b border-gray-100 pb-2">
                Kontribusi Ranting (Kecamatan)
              </h3>
              <div className="space-y-3">
                {kecamatanList.map((keca) => {
                  const pot = dataPotensial.find(p => p.kecamatan_id === keca.id);
                  const total = pot ? (pot.jumlah_penegak_l + pot.jumlah_penegak_p + pot.jumlah_pandega_l + pot.jumlah_pandega_p) : 0;
                  const punyaAkun = userList.some(u => u.role === 'user' && u.kecamatan_id === keca.id);
                  return (
                    <div key={keca.id} className="flex items-center justify-between text-xs p-3 bg-gray-50 rounded-xl border border-gray-100 font-mono">
                      <span className="font-bold text-brand-brown-dark text-xs">{keca.nama_kecamatan}</span>
                      <div className="flex gap-4 items-center">
                        <span className={`px-2.5 py-0.5 rounded text-[10px] font-bold ${punyaAkun ? 'bg-brand-green/10 text-brand-green' : 'bg-brand-orange/10 text-brand-orange'}`}>
                          {punyaAkun ? 'DKR AKTIF' : 'BELUM ADA AKUN'}
                        </span>
                        <span className="font-bold text-gray-600 bg-white border px-2.5 py-0.5 rounded">{total} Anggota</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

          </div>
        )}

        {/* TAB 2A: DATA POTENSIAL DKR */}
        {activeTab === 'potensial_dkr' && (
          <div className="space-y-8">
            <div className="border-b border-gray-200 pb-4">
              <h1 className="text-2xl font-display font-extrabold text-brand-brown-dark tracking-tight">Data Potensial Anggota DKR Kecamatan</h1>
              <p className="text-xs text-gray-500 font-mono mt-1">Rekapitulasi berkas keanggotaan Penegak & Pandega se-Kabupaten Tasikmalaya tingkat Kecamatan (Ranting).</p>
            </div>

            <div className="bg-white border border-gray-200 rounded-3xl overflow-hidden shadow-sm">
              <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
                <span className="font-extrabold text-xs text-brand-brown-dark font-mono uppercase">Tabel Rekapitulasi Ranting</span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-mono">
                  <thead className="bg-brand-brown-dark text-white uppercase text-[10px] tracking-wider">
                    <tr>
                      <th className="p-4 font-bold">Kecamatan</th>
                      <th className="p-4 font-bold text-center">Penegak (L)</th>
                      <th className="p-4 font-bold text-center">Penegak (P)</th>
                      <th className="p-4 font-bold text-center">Pandega (L)</th>
                      <th className="p-4 font-bold text-center">Pandega (P)</th>
                      <th className="p-4 font-bold text-center">Total</th>
                      <th className="p-4 font-bold">Terakhir Diperbarui</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 text-gray-700">
                    {kecamatanList.map((keca) => {
                      const pot = dataPotensial.find(p => p.kecamatan_id === keca.id);
                      const total = pot ? (pot.jumlah_penegak_l + pot.jumlah_penegak_p + pot.jumlah_pandega_l + pot.jumlah_pandega_p) : 0;
                      return (
                        <tr key={keca.id} className="hover:bg-gray-50 transition-colors">
                          <td className="p-4 font-bold text-brand-brown-dark">{keca.nama_kecamatan}</td>
                          <td className="p-4 text-center font-bold">{pot?.jumlah_penegak_l || 0}</td>
                          <td className="p-4 text-center font-bold">{pot?.jumlah_penegak_p || 0}</td>
                          <td className="p-4 text-center font-bold">{pot?.jumlah_pandega_l || 0}</td>
                          <td className="p-4 text-center font-bold">{pot?.jumlah_pandega_p || 0}</td>
                          <td className="p-4 text-center font-black text-brand-orange bg-brand-orange/5">{total}</td>
                          <td className="p-4 text-gray-500 text-[10px]">{pot ? new Date(pot.updated_at).toLocaleString('id-ID') : 'Belum ada data'}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2B: DATA POTENSIAL SAKA */}
        {activeTab === 'pangkalan' && (() => {
          const q = pangkalanSearch.trim().toLowerCase();
          const kwarranRows = [...kecamatanList]
            .sort((a, b) => a.nama_kecamatan.localeCompare(b.nama_kecamatan))
            .map(k => {
              const all = pangkalanList.filter(p => p.kecamatan_id === k.id);
              const shown = q ? all.filter(p => (p.nama_pangkalan || '').toLowerCase().includes(q)) : all;
              return { k, all, shown };
            })
            .filter(r => !q || r.k.nama_kecamatan.toLowerCase().includes(q) || r.shown.length > 0);
          const totalPangkalan = pangkalanList.filter(p => p.kecamatan_id).length;
          const totalAktif = pangkalanList.filter(p => p.kecamatan_id && p.status_aktif).length;
          return (
          <div className="space-y-8 animate-fade-in">
            <div className="border-b border-gray-200 pb-4">
              <h1 className="text-2xl font-display font-extrabold text-brand-brown-dark tracking-tight">Daftar Pangkalan / Gudep</h1>
              <p className="text-xs text-gray-500 font-mono mt-1">Data hasil input DKR tiap Kwaran. Klik baris Kwaran untuk melihat nama-nama pangkalan, lalu edit, nonaktifkan, atau hapus bila perlu.</p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              <div className="bg-white border border-gray-200 rounded-2xl p-4 shadow-sm">
                <span className="text-[10px] text-gray-400 font-mono uppercase font-semibold">Total Kwaran</span>
                <p className="text-2xl font-extrabold text-brand-brown-dark">{kecamatanList.length}</p>
              </div>
              <div className="bg-white border border-gray-200 rounded-2xl p-4 shadow-sm">
                <span className="text-[10px] text-gray-400 font-mono uppercase font-semibold">Total Pangkalan</span>
                <p className="text-2xl font-extrabold text-brand-brown-dark">{totalPangkalan}</p>
              </div>
              <div className="bg-white border border-gray-200 rounded-2xl p-4 shadow-sm col-span-2 sm:col-span-1">
                <span className="text-[10px] text-gray-400 font-mono uppercase font-semibold">Pangkalan Aktif</span>
                <p className="text-2xl font-extrabold text-brand-green">{totalAktif}</p>
              </div>
            </div>

            <div className="bg-white border border-gray-200 rounded-3xl overflow-hidden shadow-sm">
              <div className="p-4 sm:p-6 border-b border-gray-100 bg-gray-50/50 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <span className="font-extrabold text-xs text-brand-brown-dark font-mono uppercase">Rekap Pangkalan per Kwaran</span>
                <div className="relative w-full sm:w-72">
                  <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text" value={pangkalanSearch} onChange={(e) => setPangkalanSearch(e.target.value)}
                    placeholder="Cari kwaran / nama pangkalan..."
                    className="w-full bg-white border border-slate-200/80 rounded-xl pl-9 pr-3 py-2 text-xs text-gray-800 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 transition-all duration-200"
                  />
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-mono">
                  <thead>
                    <tr className="bg-gray-50 text-[10px] uppercase text-gray-400 tracking-wider border-b border-gray-100">
                      <th className="px-4 sm:px-6 py-3 w-12">No</th>
                      <th className="px-4 py-3">Kwartir Ranting</th>
                      <th className="px-4 py-3 text-center">Jumlah Pangkalan</th>
                      <th className="px-4 py-3 text-center hidden sm:table-cell">Aktif</th>
                      <th className="px-4 sm:px-6 py-3 w-12"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {kwarranRows.length === 0 && (
                      <tr><td colSpan={5} className="px-6 py-10 text-center text-gray-400">Tidak ada data yang cocok.</td></tr>
                    )}
                    {kwarranRows.map(({ k, all, shown }, idx) => {
                      const isOpen = !!q || expandedKwarranPk.includes(k.id);
                      const aktifCount = all.filter(p => p.status_aktif).length;
                      return (
                        <React.Fragment key={k.id}>
                          <tr
                            onClick={() => toggleKwarranPk(k.id)}
                            className={`border-b border-gray-100 cursor-pointer transition-colors ${isOpen ? 'bg-emerald-50/60' : 'hover:bg-gray-50'}`}
                          >
                            <td className="px-4 sm:px-6 py-3.5 text-gray-400">{idx + 1}</td>
                            <td className="px-4 py-3.5 font-bold text-brand-brown-dark">Kwaran {k.nama_kecamatan}</td>
                            <td className="px-4 py-3.5 text-center">
                              <span className="inline-block min-w-[2rem] px-2 py-0.5 rounded-full bg-brand-green/10 text-brand-green font-extrabold">{all.length}</span>
                            </td>
                            <td className="px-4 py-3.5 text-center text-gray-500 hidden sm:table-cell">{aktifCount}</td>
                            <td className="px-4 sm:px-6 py-3.5 text-gray-400">
                              {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                            </td>
                          </tr>

                          {isOpen && (
                            <tr className="border-b border-gray-100 bg-gray-50/40">
                              <td></td>
                              <td colSpan={4} className="px-4 py-4 sm:pr-6">
                                <div className="space-y-2">
                                  {shown.length === 0 && (
                                    <p className="text-[11px] text-gray-400 py-2">Belum ada pangkalan terdaftar di kwaran ini.</p>
                                  )}
                                  {shown.map((pk, i) => (
                                    editingPangkalan?.id === pk.id ? (
                                      <div key={pk.id} className="p-3 bg-white border-2 border-brand-green/40 rounded-xl grid grid-cols-1 sm:grid-cols-12 gap-2 items-center">
                                        <input
                                          type="text" value={editingPangkalan.nama_pangkalan}
                                          onChange={(e) => setEditingPangkalan({ ...editingPangkalan, nama_pangkalan: e.target.value })}
                                          className="sm:col-span-5 w-full bg-gray-50 border border-slate-200/80 rounded-xl px-3 py-2 text-xs text-gray-800 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                                        />
                                        <select
                                          value={editingPangkalan.jenis}
                                          onChange={(e) => setEditingPangkalan({ ...editingPangkalan, jenis: e.target.value })}
                                          className="sm:col-span-3 w-full bg-gray-50 border border-slate-200/80 rounded-xl px-3 py-2 text-xs text-gray-800 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                                        >
                                          <option value="SMA">SMA</option>
                                          <option value="SMK">SMK</option>
                                          <option value="MA">MA</option>
                                          <option value="Perguruan Tinggi">Perguruan Tinggi</option>
                                          <option value="lainnya">Lainnya / Umum</option>
                                        </select>
                                        <select
                                          value={editingPangkalan.status_aktif ? '1' : '0'}
                                          onChange={(e) => setEditingPangkalan({ ...editingPangkalan, status_aktif: e.target.value === '1' })}
                                          className="sm:col-span-2 w-full bg-gray-50 border border-slate-200/80 rounded-xl px-3 py-2 text-xs text-gray-800 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                                        >
                                          <option value="1">Aktif</option>
                                          <option value="0">Nonaktif</option>
                                        </select>
                                        <div className="sm:col-span-2 flex gap-1.5 justify-end">
                                          <button disabled={pangkalanSaving} onClick={handleSaveEditPangkalan} className="p-2 rounded-lg bg-brand-green text-white hover:bg-brand-green/90 disabled:opacity-50" title="Simpan"><Check className="w-3.5 h-3.5" /></button>
                                          <button onClick={() => setEditingPangkalan(null)} className="p-2 rounded-lg bg-gray-200 text-gray-600 hover:bg-gray-300" title="Batal"><X className="w-3.5 h-3.5" /></button>
                                        </div>
                                      </div>
                                    ) : (
                                      <div key={pk.id} className="p-3 bg-white border border-gray-200 rounded-xl flex items-center justify-between gap-3">
                                        <div className="min-w-0">
                                          <strong className="text-brand-brown-dark text-xs block truncate">{i + 1}. {pk.nama_pangkalan}</strong>
                                          <span className="text-[10px] text-gray-400 uppercase">
                                            {pk.jenis} · <span className={pk.status_aktif ? 'text-brand-green font-bold' : 'text-red-500 font-bold'}>{pk.status_aktif ? 'Aktif' : 'Nonaktif'}</span>
                                          </span>
                                        </div>
                                        <div className="flex gap-1.5 shrink-0">
                                          <button
                                            onClick={() => setEditingPangkalan({ id: pk.id, nama_pangkalan: pk.nama_pangkalan, jenis: pk.jenis, status_aktif: !!pk.status_aktif })}
                                            className="p-2 rounded-lg text-brand-teal hover:bg-brand-teal/10" title="Edit"
                                          ><Edit className="w-3.5 h-3.5" /></button>
                                          <button
                                            onClick={() => handleDeletePangkalanAdmin(pk)}
                                            className="p-2 rounded-lg text-brand-red hover:bg-brand-red/10" title="Hapus"
                                          ><Trash className="w-3.5 h-3.5" /></button>
                                        </div>
                                      </div>
                                    )
                                  ))}

                                  {/* Tambah pangkalan di kwaran ini */}
                                  {addPangkalanKwarran === k.id ? (
                                    <div className="p-3 bg-white border border-dashed border-brand-green/50 rounded-xl grid grid-cols-1 sm:grid-cols-12 gap-2 items-center">
                                      <input
                                        type="text" value={addPangkalanNama} onChange={(e) => setAddPangkalanNama(e.target.value)}
                                        placeholder="Nama pangkalan / gudep"
                                        className="sm:col-span-6 w-full bg-gray-50 border border-slate-200/80 rounded-xl px-3 py-2 text-xs text-gray-800 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                                      />
                                      <select value={addPangkalanJenis} onChange={(e) => setAddPangkalanJenis(e.target.value)} className="sm:col-span-4 w-full bg-gray-50 border border-slate-200/80 rounded-xl px-3 py-2 text-xs text-gray-800 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200">
                                        <option value="SMA">SMA</option>
                                        <option value="SMK">SMK</option>
                                        <option value="MA">MA</option>
                                        <option value="Perguruan Tinggi">Perguruan Tinggi</option>
                                        <option value="lainnya">Lainnya / Umum</option>
                                      </select>
                                      <div className="sm:col-span-2 flex gap-1.5 justify-end">
                                        <button disabled={pangkalanSaving} onClick={() => handleAddPangkalanAdmin(k.id)} className="p-2 rounded-lg bg-brand-green text-white hover:bg-brand-green/90 disabled:opacity-50" title="Simpan"><Check className="w-3.5 h-3.5" /></button>
                                        <button onClick={() => { setAddPangkalanKwarran(null); setAddPangkalanNama(''); }} className="p-2 rounded-lg bg-gray-200 text-gray-600 hover:bg-gray-300" title="Batal"><X className="w-3.5 h-3.5" /></button>
                                      </div>
                                    </div>
                                  ) : (
                                    <button
                                      onClick={() => { setAddPangkalanKwarran(k.id); setAddPangkalanNama(''); }}
                                      className="text-[11px] font-bold text-brand-green hover:underline flex items-center gap-1 pt-1"
                                    ><Plus className="w-3 h-3" /> Tambah pangkalan di Kwaran {k.nama_kecamatan}</button>
                                  )}
                                </div>
                              </td>
                            </tr>
                          )}
                        </React.Fragment>
                      );
                    })}
                  </tbody>
                  <tfoot>
                    <tr className="bg-gray-50 font-extrabold text-brand-brown-dark border-t border-gray-200">
                      <td></td>
                      <td className="px-4 py-3 uppercase text-[10px] tracking-wider">Total</td>
                      <td className="px-4 py-3 text-center">{totalPangkalan}</td>
                      <td className="px-4 py-3 text-center hidden sm:table-cell">{totalAktif}</td>
                      <td></td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>
          </div>
          );
        })()}

        {activeTab === 'potensial_saka' && (
          <div className="space-y-8">
            <div className="border-b border-gray-200 pb-4">
              <h1 className="text-2xl font-display font-extrabold text-brand-brown-dark tracking-tight">Data Potensial Anggota SAKA</h1>
              <p className="text-xs text-gray-500 font-mono mt-1">Rekapitulasi berkas keanggotaan Satuan Karya (SAKA) Tingkat Kabupaten Tasikmalaya.</p>
            </div>

            <div className="bg-white border border-gray-200 rounded-3xl overflow-hidden shadow-sm">
              <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
                <span className="font-extrabold text-xs text-brand-brown-dark font-mono uppercase">Tabel Rekapitulasi SAKA</span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-mono">
                  <thead className="bg-brand-brown-dark text-white uppercase text-[10px] tracking-wider">
                    <tr>
                      <th className="p-4 font-bold">Satuan Karya (SAKA)</th>
                      <th className="p-4 font-bold text-center">Penegak (L)</th>
                      <th className="p-4 font-bold text-center">Penegak (P)</th>
                      <th className="p-4 font-bold text-center">Pandega (L)</th>
                      <th className="p-4 font-bold text-center">Pandega (P)</th>
                      <th className="p-4 font-bold text-center">Total</th>
                      <th className="p-4 font-bold">Terakhir Diperbarui</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 text-gray-700">
                    {sakaList.map((sakaItem) => {
                      const pot = dataPotensial.find(p => p.saka_id === sakaItem.id);
                      const total = pot ? (pot.jumlah_penegak_l + pot.jumlah_penegak_p + pot.jumlah_pandega_l + pot.jumlah_pandega_p) : 0;
                      return (
                        <tr key={sakaItem.id} className="hover:bg-gray-50 transition-colors">
                          <td className="p-4 font-bold text-brand-brown-dark">{sakaItem.nama_saka}</td>
                          <td className="p-4 text-center font-bold">{pot?.jumlah_penegak_l || 0}</td>
                          <td className="p-4 text-center font-bold">{pot?.jumlah_penegak_p || 0}</td>
                          <td className="p-4 text-center font-bold">{pot?.jumlah_pandega_l || 0}</td>
                          <td className="p-4 text-center font-bold">{pot?.jumlah_pandega_p || 0}</td>
                          <td className="p-4 text-center font-black text-brand-orange bg-brand-orange/5">{total}</td>
                          <td className="p-4 text-gray-500 text-[10px]">{pot ? new Date(pot.updated_at).toLocaleString('id-ID') : 'Belum ada data'}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: KELOLA BERITA (Approval & Creator) */}
        {activeTab === 'berita' && (
          <div className="space-y-8">
            <div className="border-b border-gray-200 pb-4">
              <h1 className="text-2xl font-display font-extrabold text-brand-brown-dark tracking-tight">Kanal Berita & Publikasi</h1>
              <p className="text-xs text-gray-500 font-mono mt-1">Approve kontribusi berita DKR, atau tulis berita resmi Dewan Kerja Cabang.</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
              
              {/* News Approval Queue */}
              <div className="space-y-5">
                <h3 className="font-extrabold text-base text-brand-brown-dark tracking-tight border-b-2 border-brand-orange pb-2">
                  Antrean Persetujuan (Kontribusi DKR)
                </h3>
                
                {beritaList.filter(b => b.status === 'pending').length > 0 ? (
                  <div className="space-y-4">
                    {beritaList.filter(b => b.status === 'pending').map((b) => (
                      <div key={b.id} className="bg-white border border-gray-200 rounded-3xl p-5 shadow-sm space-y-4">
                        <div className="flex gap-4 items-start">
                          <div className="w-20 h-20 bg-gray-100 rounded-xl overflow-hidden shrink-0">
                            <img src={b.gambar_url} alt={b.judul} className="w-full h-full object-cover" />
                          </div>
                          <div>
                            <span className="bg-[#2E5C9A]/15 text-[#2E5C9A] border border-[#2E5C9A]/20 text-[9px] font-bold px-2 py-0.5 rounded-full font-mono uppercase block w-max mb-1.5">
                              DKR {b.kecamatan_nama}
                            </span>
                            <h4 className="font-extrabold text-sm text-brand-brown-dark tracking-tight leading-tight">{b.judul}</h4>
                            <p className="text-[10px] text-gray-400 font-mono mt-1">Diajukan oleh: {b.author_name}</p>
                          </div>
                        </div>

                        <div className="flex gap-2 justify-end pt-3 border-t border-gray-50">
                          <button
                            onClick={() => handleApproveNews(b.id, 'rejected')}
                            className="bg-brand-red/10 hover:bg-brand-red/20 text-brand-red border border-brand-red/20 font-bold px-3.5 py-1.5 rounded-xl text-xs font-mono transition-all flex items-center gap-1 cursor-pointer"
                          >
                            <X className="w-3.5 h-3.5" /> Tolak
                          </button>
                          <button
                            onClick={() => handleApproveNews(b.id, 'approved')}
                            className="bg-brand-green/10 hover:bg-brand-green/20 text-brand-green border border-brand-green/20 font-bold px-3.5 py-1.5 rounded-xl text-xs font-mono transition-all flex items-center gap-1 cursor-pointer"
                          >
                            <Check className="w-3.5 h-3.5" /> Setujui & Terbitkan
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="bg-white border border-gray-200 rounded-2xl p-8 text-center text-gray-500 italic text-xs font-mono">
                    Tidak ada kiriman berita pending dari DKR saat ini.
                  </div>
                )}
              </div>

              {/* Tulis Berita DKC */}
              <div className="bg-white border border-gray-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-5">
                <h3 className="font-extrabold text-base text-brand-brown-dark tracking-tight border-b-2 border-brand-green pb-2">
                  {editingNewsId ? 'Edit Berita' : 'Tulis Rilis Resmi DKC'}
                </h3>

                <form onSubmit={handleSaveNews} className="space-y-4 text-xs font-mono">
                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">Judul Berita</label>
                    <input 
                      type="text"
                      required
                      value={newsTitle}
                      onChange={(e) => setNewsTitle(e.target.value)}
                      placeholder="Masukkan judul berita resmi"
                      className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-4 py-3 text-xs text-gray-800 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">Foto Sampul (Unggah File Gambar)</label>
                    <div className="flex items-center gap-3">
                      <input 
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleImageUpload(e, 'news')}
                        className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-4 py-2.5 text-[10px] text-gray-500 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                      />
                    </div>
                    {newsImage && (
                      <div className="mt-2 text-[10px] text-brand-green font-bold">
                        ✓ Berhasil diunggah: <a href={newsImage} target="_blank" className="underline">{newsImage}</a>
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">Konten / Isi Artikel (HTML didukung)</label>
                    <textarea 
                      required
                      rows={5}
                      value={newsContent}
                      onChange={(e) => setNewsContent(e.target.value)}
                      placeholder="Tulis narasi berita pramuka di sini..."
                      className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-4 py-3 text-xs text-gray-800 font-sans focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={newsSaving}
                    className="w-full bg-gradient-to-r from-brand-orange to-brand-green text-white font-extrabold text-xs py-3.5 rounded-xl uppercase tracking-wider shadow cursor-pointer"
                  >
                    {newsSaving ? 'Menerbitkan...' : 'Terbitkan Sekarang'}
                  </button>
                </form>
              </div>

              {/* Daftar Berita Terbit */}
              <div className="bg-white border border-gray-200 rounded-3xl p-6 sm:p-8 shadow-sm">
                <h3 className="font-extrabold text-base text-brand-brown-dark tracking-tight border-b-2 border-brand-green pb-2 mb-4">
                  Daftar Berita & Publikasi
                </h3>
                <div className="space-y-4">
                  {beritaList.length === 0 ? (
                    <p className="text-xs text-gray-500 italic text-center py-4">Belum ada berita yang dipublikasikan.</p>
                  ) : (
                    beritaList.map((berita) => (
                      <div key={berita.id} className="flex flex-col sm:flex-row gap-4 p-4 border border-gray-100 rounded-2xl hover:border-brand-green/30 transition-colors bg-gray-50/50">
                        <img 
                          src={berita.gambar_url} 
                          alt={berita.judul} 
                          className="w-full sm:w-32 h-24 object-cover rounded-xl"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span className={`px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide rounded-md ${berita.status === 'approved' ? 'bg-brand-green/10 text-brand-green' : 'bg-brand-orange/10 text-brand-orange'}`}>
                              {berita.status === 'approved' ? 'TERBIT' : berita.status}
                            </span>
                            <span className="text-[10px] text-gray-400 font-mono">
                              {new Date(berita.published_at || Date.now()).toLocaleDateString('id-ID')}
                            </span>
                          </div>
                          <h4 className="font-bold text-sm text-gray-800 line-clamp-1 mb-1">{berita.judul}</h4>
                          <p className="text-xs text-gray-500 line-clamp-2" dangerouslySetInnerHTML={{__html: berita.konten}}></p>
                          <div className="mt-2 text-[10px] text-brand-teal font-medium">
                            Oleh: {berita.author_name}
                          </div>
                        </div>
                        <div className="flex items-center sm:flex-col justify-end gap-2 shrink-0">
                           <button 
                            onClick={() => handleDeleteBerita(berita.id)}
                            className="p-2 text-gray-400 hover:text-brand-red hover:bg-red-50 rounded-xl transition-colors"
                            title="Hapus Berita"
                           >
                             <Trash className="w-4 h-4" />
                           </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

            </div>
          </div>
        )}

        {/* TAB 4: AGENDA KEGIATAN & FORM CONFIG BUILDER */}
        {activeTab === 'agenda' && (
          <div className="space-y-8">
            <div className="border-b border-gray-200 pb-4 flex justify-between items-center">
              <div>
                <h1 className="text-2xl font-display font-extrabold text-brand-brown-dark tracking-tight">Manajemen Agenda & Pendaftaran</h1>
                <p className="text-xs text-gray-500 font-mono mt-1">Buat kegiatan baru, aktifkan portal pendaftaran online, dan rancang form dinamis.</p>
              </div>
              {selectedDashboardAgenda && (
                <button
                  onClick={() => setSelectedDashboardAgenda(null)}
                  className="bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-2 cursor-pointer"
                >
                  Kembali ke Daftar
                </button>
              )}
            </div>

            {selectedDashboardAgenda ? (
              <div className="bg-white border border-gray-200 rounded-3xl p-6 sm:p-8 shadow-sm">
                {(() => {
                  const genderField = formFields.find(f => /kelamin|gender|jk/i.test(f.label));
                  const dashConf = selectedDashboardAgenda.dashboard_config || {
                    show_stats: true, show_kwarran_chart: true, show_wilayah_chart: true, show_gender_chart: true, show_table: true, gender_field_id: ''
                  };
                  
                  // Compute Data with Global Filters
                  let filteredRegistrants = registrants.filter(reg => {
                    // Status Filter
                    if (filterStatus === 'menunggu') { if (!(reg.data_peserta?._bukti_bayar && !reg.data_peserta?._is_lunas)) return false; }
                    else if (filterStatus === 'lunas') { if (!reg.data_peserta?._is_lunas) return false; }
                    else if (filterStatus === 'checkin') { if (!reg.data_peserta?._is_hadir) return false; }
                    
                    // Kwarran Filter
                    if (filterKwarran !== 'semua' && reg.kecamatan_id !== filterKwarran) return false;
                    
                    // Wilayah Filter
                    if (filterWilayah !== 'semua') {
                      const keca = kecamatanList.find((k) => k.id === reg.kecamatan_id);
                      if ((keca?.wilayah || 'Belum diatur') !== filterWilayah) return false;
                    }
                    
                    // Gender Filter
                    if (filterGender !== 'semua' && dashConf.gender_field_id) {
                      const val = String(reg.data_peserta[dashConf.gender_field_id] || '').toLowerCase();
                      if (filterGender === 'l' && !/^(laki|putra|pa|l)/i.test(val)) return false;
                      if (filterGender === 'p' && !/^(perempuan|putri|pi|p)/i.test(val)) return false;
                    }
                    return true;
                  });

                  // Statistics
                  let maleCount = 0; let femaleCount = 0;
                  if (dashConf.gender_field_id) {
                    filteredRegistrants.forEach(reg => {
                      const val = String(reg.data_peserta[dashConf.gender_field_id] || '').toLowerCase();
                      if (/^(laki|putra|pa|l)/i.test(val)) maleCount++;
                      if (/^(perempuan|putri|pi|p)/i.test(val)) femaleCount++;
                    });
                  }

                  const uniqueKwarran = new Set(filteredRegistrants.map(r => r.kecamatan_id).filter(Boolean));
                  const kwarranPercentage = kecamatanList.length > 0 ? Math.round((uniqueKwarran.size / kecamatanList.length) * 100) : 0;

                  // Data for Recharts
                  const kwarranDataMap = {};
                  const wilayahDataMap = {};
                  filteredRegistrants.forEach(reg => {
                    if (reg.kecamatan_id) {
                      kwarranDataMap[reg.kecamatan_id] = (kwarranDataMap[reg.kecamatan_id] || 0) + 1;
                      const keca = kecamatanList.find((k) => k.id === reg.kecamatan_id);
                      const wilayah = keca?.wilayah || 'Belum diatur';
                      wilayahDataMap[wilayah] = (wilayahDataMap[wilayah] || 0) + 1;
                    }
                  });

                  const kwarranChartData = Object.keys(kwarranDataMap).map(kId => ({
                    name: kecamatanList.find((k) => k.id === kId)?.nama_kecamatan || kId,
                    jumlah: kwarranDataMap[kId]
                  })).sort((a,b) => b.jumlah - a.jumlah);

                  const wilayahChartData = Object.keys(wilayahDataMap).map(w => ({ name: w, value: wilayahDataMap[w] }));
                  const genderChartData = [
                    { name: 'Putra', value: maleCount, color: '#3B82F6' },
                    { name: 'Putri', value: femaleCount, color: '#EC4899' }
                  ].filter(d => d.value > 0);

                  // Unique wilayahs for filter dropdown
                  const uniqueWilayahList = Array.from(new Set(kecamatanList.map((k) => k.wilayah).filter(Boolean)));
                  const COLORS = ['#10B981', '#F59E0B', '#3B82F6', '#6366F1', '#8B5CF6', '#EC4899', '#F43F5E'];
                  return (
                    <div className="space-y-6">
                      {/* MODAL TOLAK TAGIHAN */}
                      {isRejectTagihanModalOpen && (
                        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
                          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl relative my-8">
                            <button onClick={() => setIsRejectTagihanModalOpen(false)} className="absolute top-4 right-4 text-gray-400 hover:text-gray-800 p-1.5 rounded-full hover:bg-gray-100 transition-colors">
                              <X className="w-5 h-5" />
                            </button>
                            <h3 className="font-extrabold text-lg text-brand-red mb-4 border-b pb-2">Tolak Tagihan Kwarran</h3>
                            <div className="space-y-4">
                              <div>
                                <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Alasan Penolakan</label>
                                <textarea
                                  value={rejectTagihanCatatan}
                                  onChange={(e) => setRejectTagihanCatatan(e.target.value)}
                                  placeholder="Berikan alasan agar DKR bisa memperbaiki..."
                                  rows={3}
                                  className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-4 py-2 text-xs text-gray-800 focus:outline-none focus:border-brand-red focus:ring-2 focus:ring-brand-red/10"
                                />
                              </div>
                              <button 
                                onClick={async () => {
                                  try {
                                    const res = await fetch('/api/tagihan_kolektif/status', {
                                      method: 'POST',
                                      headers: { 'Content-Type': 'application/json' },
                                      body: JSON.stringify({ 
                                        tagihan_id: rejectTagihanId, 
                                        status: 'ditolak',
                                        catatan_admin: rejectTagihanCatatan
                                      })
                                    });
                                    if (res.ok) {
                                      const tagihanRes = await fetch(`/api/tagihan_kolektif?agenda_id=${selectedDashboardAgenda.id}`);
                                      setTagihanKwarranList(await tagihanRes.json());
                                      setIsRejectTagihanModalOpen(false);
                                      setRejectTagihanCatatan('');
                                    }
                                  } catch (e) { console.error(e); }
                                }}
                                className="w-full bg-brand-red hover:bg-brand-red/90 text-white font-extrabold text-xs py-3 rounded-xl uppercase shadow"
                              >
                                Konfirmasi Penolakan
                              </button>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* MODAL VIEW DETAIL PESERTA */}
                      {viewRegistrant && (
                        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
                          <div className="bg-white rounded-3xl p-6 max-w-lg w-full shadow-2xl relative my-8">
                            <button onClick={() => setViewRegistrant(null)} className="absolute top-4 right-4 text-gray-400 hover:text-gray-800 p-1.5 rounded-full hover:bg-gray-100 transition-colors">
                              <X className="w-5 h-5" />
                            </button>
                            <h3 className="font-extrabold text-lg text-brand-brown-dark mb-4 border-b pb-2">Detail Pendaftar</h3>
                            
                            <div className="space-y-2 text-xs font-mono mb-4 max-h-[60vh] overflow-y-auto pr-2">
                              {formFields.map(field => (
                                <div key={field.id} className="grid grid-cols-3 border-b border-gray-100 py-1.5">
                                  <span className="text-gray-500 font-bold col-span-1">{field.label}</span>
                                  <span className="text-gray-800 col-span-2">{viewRegistrant.data_peserta[field.id] || '-'}</span>
                                </div>
                              ))}
                              {viewRegistrant.kecamatan_id && (
                                <div className="grid grid-cols-3 border-b border-brand-green/20 bg-brand-green/5 py-1.5 px-2 rounded mt-2">
                                  <span className="text-brand-green font-bold col-span-1">Kwarran</span>
                                  <span className="text-brand-green font-bold col-span-2">{kecamatanList.find((k: any) => k.id === viewRegistrant.kecamatan_id)?.nama_kecamatan || viewRegistrant.kecamatan_id}</span>
                                </div>
                              )}
                              {selectedDashboardAgenda.is_camp_fee_required && (
                                <>
                                  <div className="grid grid-cols-3 border-b border-gray-100 py-1.5 mt-2">
                                    <span className="text-gray-500 font-bold col-span-1">Status Bayar</span>
                                    <span className="col-span-2">
                                      {viewRegistrant.data_peserta?._is_lunas 
                                        ? <span className="text-green-600 font-bold">LUNAS</span> 
                                        : <span className="text-red-500 font-bold">BELUM LUNAS</span>}
                                    </span>
                                  </div>
                                  <div className="grid grid-cols-3 border-b border-gray-100 py-1.5">
                                    <span className="text-gray-500 font-bold col-span-1">Bukti Bayar</span>
                                    <span className="col-span-2">
                                      {viewRegistrant.data_peserta?._bukti_bayar ? (
                                        <a href={viewRegistrant.data_peserta._bukti_bayar} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline">Lihat Bukti</a>
                                      ) : '-'}
                                    </span>
                                  </div>
                                </>
                              )}
                            </div>
                            
                            {selectedDashboardAgenda.is_camp_fee_required && !viewRegistrant.data_peserta?._is_lunas && (
                              <button onClick={() => handleMarkLunas(viewRegistrant.id)} className="w-full bg-brand-orange text-white font-bold text-xs py-3 rounded-xl hover:bg-orange-600">
                                Tandai Lunas
                              </button>
                            )}
                          </div>
                        </div>
                      )}
                      {/* MODAL PENGATURAN DASHBOARD ANALYTICS */}
                      {isDashboardConfigModalOpen && (
                        <div className="fixed inset-0 z-[70] flex items-start justify-center p-4 pt-10 pb-20 bg-black/60 backdrop-blur-sm overflow-y-auto">
                          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl relative my-8">
                            <button onClick={() => setIsDashboardConfigModalOpen(false)} className="absolute top-4 right-4 text-gray-400 hover:text-gray-800 p-1.5 rounded-full hover:bg-gray-100 transition-colors">
                              <X className="w-5 h-5" />
                            </button>
                            <h3 className="font-extrabold text-lg text-brand-brown-dark mb-4 border-b pb-2">Pengaturan Dashboard</h3>
                            <div className="space-y-4 text-xs font-mono">
                              <label className="flex items-center gap-2 cursor-pointer">
                                <input type="checkbox" checked={tempDashboardConfig?.show_stats ?? true} onChange={e => setTempDashboardConfig({...tempDashboardConfig, show_stats: e.target.checked})} className="rounded text-brand-green focus:ring-brand-green/20" />
                                <span>Tampilkan Kartu Statistik Utama</span>
                              </label>
                              <label className="flex items-center gap-2 cursor-pointer">
                                <input type="checkbox" checked={tempDashboardConfig?.show_kwarran_chart ?? true} onChange={e => setTempDashboardConfig({...tempDashboardConfig, show_kwarran_chart: e.target.checked})} className="rounded text-brand-green focus:ring-brand-green/20" />
                                <span>Tampilkan Bar Chart Peserta per Kwarran</span>
                              </label>
                              <label className="flex items-center gap-2 cursor-pointer">
                                <input type="checkbox" checked={tempDashboardConfig?.show_wilayah_chart ?? true} onChange={e => setTempDashboardConfig({...tempDashboardConfig, show_wilayah_chart: e.target.checked})} className="rounded text-brand-green focus:ring-brand-green/20" />
                                <span>Tampilkan Pie Chart Peserta per Wilayah</span>
                              </label>
                              <label className="flex items-center gap-2 cursor-pointer">
                                <input type="checkbox" checked={tempDashboardConfig?.show_gender_chart ?? true} onChange={e => setTempDashboardConfig({...tempDashboardConfig, show_gender_chart: e.target.checked})} className="rounded text-brand-green focus:ring-brand-green/20" />
                                <span>Tampilkan Pie Chart Jenis Kelamin</span>
                              </label>
                              <label className="flex items-center gap-2 cursor-pointer border-b pb-4">
                                <input type="checkbox" checked={tempDashboardConfig?.show_table ?? true} onChange={e => setTempDashboardConfig({...tempDashboardConfig, show_table: e.target.checked})} className="rounded text-brand-green focus:ring-brand-green/20" />
                                <span>Tampilkan Tabel Detail Peserta</span>
                              </label>

                              <div>
                                <label className="block font-bold text-gray-500 mb-1">Field Data Jenis Kelamin</label>
                                <select 
                                  value={tempDashboardConfig?.gender_field_id || ''}
                                  onChange={e => setTempDashboardConfig({...tempDashboardConfig, gender_field_id: e.target.value})}
                                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2"
                                >
                                  <option value="">-- Pilih Field --</option>
                                  {formFields.map(f => (
                                    <option key={f.id} value={f.id}>{f.label}</option>
                                  ))}
                                </select>
                                <p className="text-[10px] text-gray-400 mt-1">Pilih field form yang berisi pilihan (Laki-laki/Perempuan) untuk Pie Chart.</p>
                              </div>

                              <button 
                                onClick={async () => {
                                  try {
                                    const res = await fetch(`/api/agenda/${selectedDashboardAgenda.id}/dashboard_config`, {
                                      method: 'PUT',
                                      headers: { 'Content-Type': 'application/json' },
                                      body: JSON.stringify({ dashboard_config: tempDashboardConfig })
                                    });
                                    if (res.ok) {
                                      setSelectedDashboardAgenda({ ...selectedDashboardAgenda, dashboard_config: tempDashboardConfig });
                                      setIsDashboardConfigModalOpen(false);
                                    }
                                  } catch (e) { console.error(e); }
                                }}
                                className="w-full bg-brand-green hover:bg-brand-green/90 text-white font-extrabold text-xs py-3 rounded-xl uppercase shadow mt-4"
                              >
                                Simpan Konfigurasi
                              </button>
                            </div>
                          </div>
                        </div>
                      )}

                      <div className="flex justify-between items-center mb-4">
                        <div className="flex items-center gap-4">
                          {selectedDashboardAgenda.logo_url && (
                            <img src={selectedDashboardAgenda.logo_url} alt="Logo Kegiatan" className="w-12 h-12 rounded-xl object-cover shadow-sm border border-gray-100" />
                          )}
                          <div>
                            <h3 className="font-display font-extrabold text-xl text-brand-brown-dark tracking-tight">
                              Dashboard: {selectedDashboardAgenda.nama_kegiatan}
                            </h3>
                            <p className="text-xs text-gray-500 mt-1">Analytics & Data Center</p>
                          </div>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          <button
                            onClick={() => {
                              setTempDashboardConfig(dashConf);
                              setIsDashboardConfigModalOpen(true);
                            }}
                            className="bg-gray-100 hover:bg-gray-200 text-gray-700 font-extrabold text-xs px-4 py-2 rounded-xl flex items-center gap-2 cursor-pointer shadow-sm transition-colors border border-gray-200"
                          >
                            <Settings className="w-4 h-4" /> Pengaturan Dashboard
                          </button>
                          <button
                            onClick={() => setShowScanner(true)}
                            className="bg-brand-brown-dark hover:bg-brand-brown-dark/90 text-white font-extrabold text-xs px-4 py-2 rounded-xl flex items-center gap-2 cursor-pointer shadow transition-colors"
                          >
                            <ScanLine className="w-4 h-4" /> Scan Hadir
                          </button>
                          <button
                            onClick={handleExportExcel}
                            className="bg-[#10B981] hover:bg-[#059669] text-white font-extrabold text-xs px-4 py-2 rounded-xl flex items-center gap-2 cursor-pointer shadow transition-colors"
                          >
                            <Download className="w-4 h-4" /> Export Excel
                          </button>
                        </div>
                      </div>
                      {showScanner && (
                        <Suspense fallback={null}><CheckinScanner 
                          onClose={() => setShowScanner(false)} 
                          onScanSuccess={(code) => {
                            setShowScanner(false);
                            handleScanSuccess(code);
                          }} 
                        /></Suspense>
                      )}

                      {/* GLOBAL FILTERS */}
                      <div className="bg-brand-brown-dark/5 border border-brand-brown-dark/10 rounded-2xl p-4 mb-6 mt-6">
                        <div className="flex items-center gap-2 mb-3">
                          <Search className="w-4 h-4 text-brand-brown-dark" />
                          <span className="text-xs font-bold text-brand-brown-dark uppercase tracking-wider">Filter Global</span>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                          <div>
                            <label className="block text-[10px] text-gray-500 font-bold mb-1">Status</label>
                            <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)} className="w-full text-xs border-gray-200 rounded-lg p-2 bg-white">
                              <option value="semua">Semua Status</option>
                              {selectedDashboardAgenda.is_camp_fee_required && (
                                <>
                                  <option value="menunggu">Menunggu Verifikasi</option>
                                  <option value="lunas">Sudah Lunas</option>
                                </>
                              )}
                              <option value="checkin">Sudah Check-in</option>
                            </select>
                          </div>
                          <div>
                            <label className="block text-[10px] text-gray-500 font-bold mb-1">Wilayah</label>
                            <select value={filterWilayah} onChange={e => setFilterWilayah(e.target.value)} className="w-full text-xs border-gray-200 rounded-lg p-2 bg-white">
                              <option value="semua">Semua Wilayah</option>
                              <option value="Belum diatur">Belum diatur</option>
                              {uniqueWilayahList.map(w => (
                                <option key={w as string} value={w as string}>{w as string}</option>
                              ))}
                            </select>
                          </div>
                          <div>
                            <label className="block text-[10px] text-gray-500 font-bold mb-1">Kwarran</label>
                            <select value={filterKwarran} onChange={e => setFilterKwarran(e.target.value)} className="w-full text-xs border-gray-200 rounded-lg p-2 bg-white">
                              <option value="semua">Semua Kwarran</option>
                              {kecamatanList.map((k:any) => (
                                <option key={k.id} value={k.id}>{k.nama_kecamatan}</option>
                              ))}
                            </select>
                          </div>
                          <div>
                            <label className="block text-[10px] text-gray-500 font-bold mb-1">Jenis Kelamin</label>
                            <select value={filterGender} onChange={e => setFilterGender(e.target.value)} className="w-full text-xs border-gray-200 rounded-lg p-2 bg-white" disabled={!dashConf.gender_field_id}>
                              <option value="semua">Semua</option>
                              <option value="l">Putra</option>
                              <option value="p">Putri</option>
                            </select>
                          </div>
                        </div>
                      </div>

                      {dashConf.show_stats && (
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                          <div className="bg-white border border-gray-200 rounded-2xl p-6 flex flex-col justify-center items-center shadow-sm">
                            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Total Pendaftar Tersaring</span>
                            <span className="text-4xl font-display font-extrabold text-brand-orange">{filteredRegistrants.length}</span>
                          </div>
                          <div className="bg-white border border-gray-200 rounded-2xl p-6 flex flex-col justify-center items-center shadow-sm text-center">
                            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Putra / Putri</span>
                            <span className="text-3xl font-display font-extrabold text-brand-green">
                              {dashConf.gender_field_id ? `${maleCount} Pa / ${femaleCount} Pi` : 'N/A'}
                            </span>
                          </div>
                          <div className="bg-white border border-gray-200 rounded-2xl p-6 flex flex-col justify-center items-center shadow-sm">
                            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Keterwakilan Kwarran</span>
                            <span className="text-4xl font-display font-extrabold text-brand-brown-dark">{kwarranPercentage}%</span>
                            <span className="text-xs text-gray-400 mt-1">{uniqueKwarran.size} dari {kecamatanList.length} Kwarran</span>
                          </div>
                        </div>
                      )}

                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                        {dashConf.show_kwarran_chart && (
                          <div className="bg-white border border-gray-200 rounded-2xl p-4 shadow-sm h-72 flex flex-col">
                            <h4 className="text-xs font-bold text-gray-500 uppercase mb-4 text-center">Sebaran Kwarran</h4>
                            <div className="flex-1 min-h-0">
                              <ResponsiveContainer width="100%" height="100%">
                                <BarChart data={kwarranChartData.slice(0, 10)} margin={{ top: 5, right: 5, left: -20, bottom: 25 }}>
                                  <XAxis dataKey="name" tick={{ fontSize: 10 }} angle={-45} textAnchor="end" height={40} />
                                  <YAxis tick={{ fontSize: 10 }} />
                                  <Tooltip contentStyle={{ fontSize: '12px', borderRadius: '8px' }} />
                                  <Bar dataKey="jumlah" fill="#10B981" radius={[4, 4, 0, 0]} name="Peserta" />
                                </BarChart>
                              </ResponsiveContainer>
                            </div>
                          </div>
                        )}
                        
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 h-72">
                          {dashConf.show_wilayah_chart && (
                            <div className="bg-white border border-gray-200 rounded-2xl p-4 shadow-sm flex flex-col items-center">
                              <h4 className="text-xs font-bold text-gray-500 uppercase mb-2 text-center">Sebaran Wilayah</h4>
                              <div className="w-full flex-1 min-h-0">
                                <ResponsiveContainer width="100%" height="100%">
                                  <PieChart>
                                    <Pie data={wilayahChartData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={60} label={({name, percent}) => `${name} (${(percent * 100).toFixed(0)}%)`} labelLine={false}>
                                      {wilayahChartData.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                      ))}
                                    </Pie>
                                    <Tooltip contentStyle={{ fontSize: '12px', borderRadius: '8px' }} />
                                  </PieChart>
                                </ResponsiveContainer>
                              </div>
                            </div>
                          )}
                          
                          {dashConf.show_gender_chart && (
                            <div className="bg-white border border-gray-200 rounded-2xl p-4 shadow-sm flex flex-col items-center">
                              <h4 className="text-xs font-bold text-gray-500 uppercase mb-2 text-center">Komposisi Gender</h4>
                              <div className="w-full flex-1 min-h-0">
                                {genderChartData.length > 0 ? (
                                  <ResponsiveContainer width="100%" height="100%">
                                    <PieChart>
                                      <Pie data={genderChartData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={40} outerRadius={60}>
                                        {genderChartData.map((entry, index) => (
                                          <Cell key={`cell-${index}`} fill={entry.color} />
                                        ))}
                                      </Pie>
                                      <Tooltip contentStyle={{ fontSize: '12px', borderRadius: '8px' }} />
                                      <Legend wrapperStyle={{ fontSize: '10px' }} />
                                    </PieChart>
                                  </ResponsiveContainer>
                                ) : (
                                  <div className="h-full flex items-center justify-center text-xs text-gray-400 text-center">Field Gender<br/>Belum Diatur</div>
                                )}
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                      
                      {dashConf.show_table && (
                      <div className="pt-6 border-t border-gray-100">
                        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-4">
                          <h5 className="font-extrabold text-base text-brand-brown-dark tracking-tight">
                            Data Pendaftar Terkonfirmasi
                          </h5>
                          
                          {/* Tabs */}
                          <div className="flex gap-2 overflow-x-auto pb-1 max-w-full">
                            <button onClick={() => setAgendaDashboardTab('semua')} className={`shrink-0 px-3 py-1.5 rounded-full text-[10px] font-bold uppercase transition-all ${agendaDashboardTab === 'semua' ? 'bg-brand-brown-dark text-white' : 'bg-gray-100 text-gray-500'}`}>Semua</button>
                            {selectedDashboardAgenda.is_camp_fee_required && (
                              <>
                                <button onClick={() => setAgendaDashboardTab('menunggu')} className={`shrink-0 px-3 py-1.5 rounded-full text-[10px] font-bold uppercase transition-all ${agendaDashboardTab === 'menunggu' ? 'bg-amber-500 text-white' : 'bg-gray-100 text-gray-500'}`}>Menunggu Verifikasi</button>
                                <button onClick={() => setAgendaDashboardTab('lunas')} className={`shrink-0 px-3 py-1.5 rounded-full text-[10px] font-bold uppercase transition-all ${agendaDashboardTab === 'lunas' ? 'bg-blue-500 text-white' : 'bg-gray-100 text-gray-500'}`}>Sudah Bayar</button>
                              </>
                            )}
                            <button onClick={() => setAgendaDashboardTab('checkin')} className={`shrink-0 px-3 py-1.5 rounded-full text-[10px] font-bold uppercase transition-all ${agendaDashboardTab === 'checkin' ? 'bg-brand-green text-white' : 'bg-gray-100 text-gray-500'}`}>Sudah Check-in</button>
                            {(selectedDashboardAgenda.tipe_pendaftaran === 'kolektif' || selectedDashboardAgenda.tipe_pendaftaran === 'keduanya') && (
                              <button onClick={() => setAgendaDashboardTab('tagihan_kwarran')} className={`shrink-0 px-3 py-1.5 rounded-full text-[10px] font-bold uppercase transition-all ${agendaDashboardTab === 'tagihan_kwarran' ? 'bg-purple-600 text-white' : 'bg-gray-100 text-gray-500'}`}>Verifikasi Tagihan Kwarran</button>
                            )}
                          </div>
                        </div>
                        
                        {agendaDashboardTab === 'tagihan_kwarran' ? (
                          <div className="space-y-4 font-mono text-xs text-gray-700">
                            {tagihanKwarranList.length > 0 ? tagihanKwarranList.map((tagihan) => {
                              const kwarran = kecamatanList.find(k => k.id === tagihan.kwarran_id)?.nama || tagihan.kwarran_id;
                              return (
                                <div key={tagihan.id} className="p-4 bg-white border border-gray-200 rounded-xl shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                                  <div>
                                    <h5 className="font-extrabold text-sm text-brand-brown-dark">{kwarran}</h5>
                                    <p className="text-gray-500 mt-1">Status: <span className={`font-bold px-2 py-0.5 rounded text-[10px] uppercase ${tagihan.status === 'lunas' ? 'bg-green-100 text-green-700' : tagihan.status === 'ditolak' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'}`}>{tagihan.status}</span></p>
                                    <p className="text-gray-500 mt-1">Total: <span className="font-bold text-gray-800">Rp {tagihan.total_tagihan?.toLocaleString('id-ID')}</span></p>
                                  </div>
                                  <div className="flex gap-2 shrink-0">
                                    {tagihan.bukti_bayar_url ? (
                                      <a href={tagihan.bukti_bayar_url} target="_blank" rel="noreferrer" className="bg-blue-50 text-blue-600 border border-blue-200 hover:bg-blue-100 px-3 py-1.5 rounded-xl font-bold flex items-center gap-2">
                                        <Eye className="w-3.5 h-3.5" /> Lihat Bukti
                                      </a>
                                    ) : (
                                      <span className="text-gray-400 italic">Belum ada bukti</span>
                                    )}
                                    
                                    {tagihan.status === 'menunggu_verifikasi' && (
                                      <>
                                        <button 
                                          onClick={async () => {
                                            if(!await showConfirm('Setujui tagihan ini? (Pendaftar akan otomatis diset lunas)')) return;
                                            try {
                                              const res = await fetch('/api/tagihan_kolektif/status', {
                                                method: 'POST',
                                                headers: { 'Content-Type': 'application/json' },
                                                body: JSON.stringify({ tagihan_id: tagihan.id, status: 'lunas' })
                                              });
                                              if (res.ok) {
                                                const tagihanRes = await fetch(`/api/tagihan_kolektif?agenda_id=${selectedDashboardAgenda.id}`);
                                                setTagihanKwarranList(await tagihanRes.json());
                                                // Reload registrants to get updated lunas status
                                                const regRes = await fetch(`/api/agenda/${selectedDashboardAgenda.id}/registrants`);
                                                setRegistrants(await regRes.json());
                                              }
                                            } catch(e) {}
                                          }}
                                          className="bg-brand-green/10 text-brand-green border border-brand-green/20 hover:bg-brand-green/20 px-3 py-1.5 rounded-xl font-bold flex items-center gap-2"
                                        >
                                          <Check className="w-3.5 h-3.5" /> Setujui
                                        </button>
                                        <button 
                                          onClick={() => {
                                            setRejectTagihanId(tagihan.id);
                                            setIsRejectTagihanModalOpen(true);
                                          }}
                                          className="bg-brand-red/10 text-brand-red border border-brand-red/20 hover:bg-brand-red/20 px-3 py-1.5 rounded-xl font-bold flex items-center gap-2"
                                        >
                                          <X className="w-3.5 h-3.5" /> Tolak
                                        </button>
                                      </>
                                    )}
                                  </div>
                                </div>
                              );
                            }) : (
                              <p className="text-center text-gray-400 italic p-8 bg-gray-50 rounded-2xl border border-dashed">Belum ada tagihan kwarran.</p>
                            )}
                          </div>
                        ) : filteredRegistrants.length > 0 ? (
                          <div className="space-y-3 font-mono text-xs text-gray-700">
                            {filteredRegistrants.map((reg, idx) => (
                              <div key={reg.id} className="p-4 bg-white border rounded-xl border-gray-200 shadow-sm flex flex-col md:flex-row justify-between items-center gap-4 hover:border-brand-green/30 transition-colors">
                                <div className="flex-1 w-full">
                                  <div className="flex flex-wrap items-center gap-2 mb-2">
                                    <span className="font-bold text-sm text-brand-brown-dark uppercase">{reg.data_peserta[formFields[0]?.id] || 'Peserta'}</span>
                                    <span className="text-[9px] bg-gray-100 px-2 py-0.5 rounded text-gray-500 uppercase">{reg.tipe}</span>
                                    {reg.data_peserta?._is_hadir && <span className="bg-brand-green/10 text-brand-green px-2 py-0.5 rounded text-[9px] uppercase font-bold flex items-center gap-1"><CheckCircle className="w-3 h-3" /> Check-in</span>}
                                    {selectedDashboardAgenda.is_camp_fee_required && reg.data_peserta?._is_lunas && <span className="bg-blue-500/10 text-blue-600 px-2 py-0.5 rounded text-[9px] uppercase font-bold">Lunas</span>}
                                  </div>
                                  <div className="text-[10px] text-gray-500 flex flex-wrap gap-x-4 gap-y-1">
                                    {reg.kecamatan_id && <span>📍 {kecamatanList.find((k: any) => k.id === reg.kecamatan_id)?.nama_kecamatan || reg.kecamatan_id}</span>}
                                    <span>🕒 {new Date(reg.created_at).toLocaleString('id-ID')}</span>
                                  </div>
                                </div>
                                <div className="flex gap-2 shrink-0">
                                  <button onClick={() => setViewRegistrant(reg)} className="bg-brand-teal/10 hover:bg-brand-teal/20 text-brand-teal text-[10px] font-bold px-3 py-1.5 rounded-lg flex items-center gap-1">
                                    <Eye className="w-3 h-3" /> Detail
                                  </button>
                                  {selectedDashboardAgenda.is_camp_fee_required && !reg.data_peserta?._is_lunas && (
                                    <button onClick={() => handleMarkLunas(reg.id)} className="bg-amber-100 hover:bg-amber-200 text-amber-600 border border-amber-200 text-[10px] font-bold px-3 py-1.5 rounded-lg flex items-center gap-1">
                                      <Check className="w-3 h-3" /> Lunas
                                    </button>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <p className="text-sm text-gray-500 italic p-8 text-center bg-gray-50 rounded-2xl border border-dashed">Belum ada peserta di kategori ini.</p>
                        )}
                      </div>
                      )}
                    </div>
                  );
                })()}
              </div>
            ) : selectedBuilderAgenda ? (
              <div className="fixed inset-0 z-[60] flex items-start justify-center p-4 pt-10 pb-20 bg-black/60 backdrop-blur-sm overflow-y-auto">
                <div className="bg-white rounded-3xl p-6 max-w-5xl w-full shadow-2xl relative my-8 h-[90vh] flex flex-col">
                  <div className="flex justify-between items-center border-b pb-4 shrink-0">
                  <div>
                    <span className="text-[10px] text-brand-orange font-mono font-bold uppercase tracking-wider block mb-1">Rancang Schema Online Form</span>
                    <h4 className="font-extrabold text-xl text-brand-brown-dark tracking-tight">Formulir: {selectedBuilderAgenda.nama_kegiatan}</h4>
                  </div>
                  <button 
                    onClick={() => setSelectedBuilderAgenda(null)}
                    className="bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-2 cursor-pointer transition-colors"
                  >
                    Kembali ke Daftar
                  </button>
                </div>

                {/* Form Builder configuration */}
                <div className="space-y-6">
                  <div className="flex flex-col gap-4 md:flex-row md:items-center md:gap-8 bg-gray-50 p-4 rounded-2xl border border-gray-200">
                    <div className="flex flex-col gap-2">
                      <label className="text-xs font-bold font-mono text-gray-600">Tipe Pendaftaran:</label>
                      <select 
                        value={pendaftaranTipe} onChange={(e) => setPendaftaranTipe(e.target.value as any)}
                        className="bg-white border border-gray-200 rounded-xl px-4 py-2 text-xs font-mono font-bold text-gray-800 focus:outline-none focus:border-brand-orange focus:ring-1 focus:ring-brand-orange"
                      >
                        <option value="mandiri">Mandiri Sahaja (Perorangan)</option>
                        <option value="kolektif">Kolektif Kontingen (Ranting/Gudep)</option>
                        <option value="keduanya">Keduanya (Bisa memilih)</option>
                      </select>
                    </div>
                    
                    <div className="hidden md:block w-px h-12 bg-gray-300"></div>

                    <div className="flex flex-col gap-3">
                      <label className="flex items-center gap-3 text-xs font-bold text-gray-700 cursor-pointer hover:text-brand-green transition-colors">
                        <input type="checkbox" checked={isQrValidasi} onChange={(e) => setIsQrValidasi(e.target.checked)} className="w-4 h-4 rounded text-brand-green border-gray-300 focus:ring-brand-green" />
                        Tampilkan QR Validasi di Bukti PDF
                      </label>
                      <label className="flex items-center gap-3 text-xs font-bold text-gray-700 cursor-pointer hover:text-brand-green transition-colors">
                        <input type="checkbox" checked={isQrCheckin} onChange={(e) => setIsQrCheckin(e.target.checked)} className="w-4 h-4 rounded text-brand-green border-gray-300 focus:ring-brand-green" />
                        Tampilkan QR Check-in di Bukti PDF
                      </label>
                    </div>
                  </div>

                  {/* Fields Designer list */}
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold font-mono text-gray-500 uppercase tracking-widest block">Struktur Fields Formulir</span>
                      <button
                        type="button"
                        onClick={() => setFormFields([...formFields, { id: `f${Date.now().toString().substr(-4)}`, label: 'Field Baru', type: 'text', required: false }])}
                        className="bg-brand-green/10 hover:bg-brand-green/20 text-brand-green font-extrabold text-[10px] px-4 py-2 rounded-xl uppercase tracking-wider flex items-center gap-1.5 cursor-pointer transition-colors"
                      >
                        <Plus className="w-4 h-4" /> Tambah Field
                      </button>
                    </div>
                    
                    <div className="space-y-3">
                      {formFields.map((field, idx) => (
                        <div key={field.id} className="bg-white p-4 rounded-2xl border border-gray-200 shadow-sm flex flex-col gap-4 text-xs font-mono transition-all hover:border-brand-orange/30">
                          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                            <div className="flex items-center gap-3 flex-1 w-full lg:w-auto">
                              <span className="bg-brand-orange/10 text-brand-orange font-bold px-2 py-1 rounded-lg text-[10px] border border-brand-orange/20">{field.id}</span>
                              <div className="flex-1 w-full">
                              <label className="block text-[9px] text-gray-400 mb-1">Label Field</label>
                              <input 
                                type="text" value={field.label}
                                disabled={!!field.locked}
                                onChange={(e) => {
                                  const list = [...formFields];
                                  list[idx].label = e.target.value;
                                  setFormFields(list);
                                }}
                                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 font-sans text-sm text-brand-brown-dark font-bold focus:bg-white focus:border-brand-orange focus:outline-none transition-colors disabled:opacity-70 disabled:cursor-not-allowed"
                                placeholder="Cth: Nama Lengkap"
                              />
                            </div>
                          </div>

                          <div className="flex flex-wrap items-end lg:items-center gap-4">
                            <div>
                              <label className="block text-[9px] text-gray-400 mb-1">Tipe Input</label>
                              <select 
                                value={field.type}
                                disabled={!!field.locked}
                                onChange={(e) => {
                                  const list = [...formFields];
                                  list[idx].type = e.target.value;
                                  setFormFields(list);
                                }}
                                className="bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-xs focus:bg-white focus:border-brand-orange focus:outline-none transition-colors min-w-[140px] disabled:opacity-70 disabled:cursor-not-allowed"
                              >
                                <option value="text">Text Pendek</option>
                                <option value="number">Angka (Numeric)</option>
                                <option value="select">Dropdown Pilihan</option>
                                <option value="textarea">Teks Panjang</option>
                                <option value="pangkalan">Pilih Pangkalan (dari database)</option>
                                <option value="date">Tanggal</option>
                              </select>
                            </div>

                            <div className="flex items-center h-full pb-2 lg:pb-0">
                              <label className="flex items-center gap-2 font-bold text-xs text-gray-600 cursor-pointer hover:text-brand-orange transition-colors">
                                <input 
                                  type="checkbox" checked={field.required || !!field.locked} disabled={!!field.locked}
                                  onChange={(e) => {
                                    const list = [...formFields];
                                    list[idx].required = e.target.checked;
                                    setFormFields(list);
                                  }}
                                  className="w-4 h-4 rounded text-brand-orange border-gray-300 focus:ring-brand-orange"
                                /> Wajib Diisi
                              </label>
                            </div>

                            {field.locked ? (
                              <span className="flex items-center gap-1.5 text-[10px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-2 rounded-xl mb-0.5 lg:mb-0" title="Field inti: wajib ada di setiap kegiatan">
                                <Lock className="w-3.5 h-3.5" /> Wajib · tidak bisa dihapus
                              </span>
                            ) : (
                            <button
                              onClick={() => { if (field.locked) return; setFormFields(formFields.filter((_, i) => i !== idx)); }}
                              className="text-brand-red bg-brand-red/10 hover:bg-brand-red/20 hover:text-red-700 p-2.5 rounded-xl transition-colors mb-0.5 lg:mb-0"
                              title="Hapus Field"
                            >
                              <Trash className="w-4 h-4" />
                            </button>
                            )}
                          </div>
                          </div> {/* end inner wrapper */}

                          {/* Dropdown Options details */}
                          {field.type === 'select' && (
                            <div className="w-full pt-3 border-t border-dashed border-gray-200">
                              <label className="block text-[10px] font-bold text-gray-400 uppercase mb-2">Opsi Dropdown</label>
                              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                                {(field.options || []).map((opt: string, optIdx: number) => (
                                  <div key={optIdx} className="flex items-center gap-2">
                                    <input
                                      type="text"
                                      value={opt}
                                      onChange={(e) => {
                                        const list = [...formFields];
                                        const newOptions = [...(list[idx].options || [])];
                                        newOptions[optIdx] = e.target.value;
                                        list[idx].options = newOptions;
                                        setFormFields(list);
                                      }}
                                      placeholder={`Opsi ${optIdx + 1}`}
                                      className="flex-1 bg-white border border-gray-200 rounded-lg px-3 py-1.5 text-xs text-gray-800 focus:outline-none focus:border-brand-orange focus:ring-1 focus:ring-brand-orange transition-all"
                                    />
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const list = [...formFields];
                                        const newOptions = [...(list[idx].options || [])];
                                        newOptions.splice(optIdx, 1);
                                        list[idx].options = newOptions;
                                        setFormFields(list);
                                      }}
                                      className="text-gray-400 hover:text-brand-red hover:bg-red-50 p-1.5 rounded-lg transition-colors"
                                    >
                                      <Trash className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                ))}
                                <button
                                  type="button"
                                  onClick={() => {
                                    const list = [...formFields];
                                    list[idx].options = [...(list[idx].options || []), ''];
                                    setFormFields(list);
                                  }}
                                  className="text-[10px] font-bold text-brand-orange bg-brand-orange/5 border border-brand-orange/20 hover:bg-brand-orange/10 px-3 py-1.5 rounded-lg flex items-center justify-center gap-1 transition-colors cursor-pointer"
                                >
                                  <Plus className="w-3 h-3" /> Tambah Opsi
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Action save builder schema */}
                  <div className="pt-6 border-t flex justify-end">
                    <button
                      onClick={handleSaveFormSchema}
                      className="bg-brand-orange hover:bg-orange-600 text-white font-extrabold text-xs px-6 py-3 rounded-xl flex items-center gap-2 cursor-pointer shadow-md transition-colors"
                    >
                      <Save className="w-4 h-4" /> Simpan Struktur Form
                    </button>
                  </div>
                </div>
              </div>
              </div>
            ) : (
              <div className="space-y-6 relative">
              
              {/* Wilayah Config Modal */}
              {isWilayahConfigModalOpen && (
                <div className="fixed inset-0 z-[60] flex items-start justify-center p-4 pt-10 pb-20 bg-black/60 backdrop-blur-sm overflow-y-auto">
                  <div className="bg-white rounded-3xl p-6 shadow-2xl space-y-5 relative max-w-4xl w-full my-8">
                    <button type="button" onClick={() => setIsWilayahConfigModalOpen(false)} className="absolute top-4 right-4 text-gray-400 hover:text-gray-800 p-1.5 rounded-full hover:bg-gray-100 transition-colors z-10">
                      <X className="w-5 h-5" />
                    </button>
                    <h3 className="font-extrabold text-base text-brand-brown-dark tracking-tight border-b-2 border-brand-orange pb-2">
                      Konfigurasi Wilayah Kwarran
                    </h3>
                    <form onSubmit={handleSaveWilayah} className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 max-h-[60vh] overflow-y-auto pr-2">
                        {tempWilayahData.map((w, idx) => (
                          <div key={w.id} className="bg-slate-50 border border-slate-100 p-3 rounded-xl flex justify-between items-center">
                            <span className="text-xs font-bold text-gray-700">{w.nama_kecamatan}</span>
                            <select
                              value={w.wilayah}
                              onChange={(e) => {
                                const newW = [...tempWilayahData];
                                newW[idx].wilayah = e.target.value;
                                setTempWilayahData(newW);
                              }}
                              className="text-[10px] bg-white border border-gray-200 rounded p-1 ml-2 font-mono"
                            >
                              <option value="">- Pilih -</option>
                              <option value="Wilayah 1">Wilayah 1</option>
                              <option value="Wilayah 2">Wilayah 2</option>
                              <option value="Wilayah 3">Wilayah 3</option>
                              <option value="Wilayah 4">Wilayah 4</option>
                              <option value="Wilayah 5">Wilayah 5</option>
                              <option value="Wilayah 6">Wilayah 6</option>
                              <option value="Wilayah 7">Wilayah 7</option>
                            </select>
                          </div>
                        ))}
                      </div>
                      <div className="flex justify-end pt-4 border-t border-slate-100">
                         <button type="submit" disabled={wilayahSaving} className="bg-brand-green hover:bg-brand-green/90 text-white font-extrabold text-xs px-6 py-3 rounded-xl cursor-pointer">
                           {wilayahSaving ? 'Menyimpan...' : 'Simpan Semua'}
                         </button>
                      </div>
                    </form>
                  </div>
                </div>
              )}

              {/* Left Form: Add Agenda */}
              {isAddAgendaModalOpen && (
                <div className="fixed inset-0 z-[60] flex items-start justify-center p-4 pt-10 pb-20 bg-black/60 backdrop-blur-sm overflow-y-auto">
                  <div className="bg-white rounded-3xl p-6 shadow-2xl space-y-5 relative max-w-lg w-full my-8">
                    <button type="button" onClick={() => setIsAddAgendaModalOpen(false)} className="absolute top-4 right-4 text-gray-400 hover:text-gray-800 p-1.5 rounded-full hover:bg-gray-100 transition-colors z-10">
                      <X className="w-5 h-5" />
                    </button>
                <h3 className="font-extrabold text-base text-brand-brown-dark tracking-tight border-b-2 border-brand-orange pb-2">
                  Tambah Agenda Baru
                </h3>

                <form onSubmit={handleSaveAgenda} className="space-y-4 text-xs font-mono">
                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Nama Kegiatan</label>
                    <input 
                      type="text" required value={agendaName} onChange={(e) => setAgendaName(e.target.value)}
                      placeholder="Nama kegiatan" className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-4 py-2.5 text-xs text-gray-800 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Logo Kegiatan (Opsional)</label>
                    <div className="flex items-center gap-3">
                      <input 
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleImageUpload(e, 'agendaLogo')}
                        className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-4 py-2.5 text-[10px] text-gray-500 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                      />
                      {agendaLogoUploading && <span className="text-[10px] text-brand-orange animate-pulse whitespace-nowrap">Uploading...</span>}
                      {agendaLogoUrl && !agendaLogoUploading && <span className="text-[10px] text-brand-green whitespace-nowrap">Tersimpan</span>}
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Juknis (Opsional, PDF/Word)</label>
                    <div className="flex items-center gap-3">
                      <input
                        type="file"
                        accept=".pdf,.doc,.docx,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        disabled={agendaDocUploading !== null}
                        onChange={(e) => handleAgendaDocUpload(e, 'juknis')}
                        className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-4 py-2.5 text-[10px] text-gray-500 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200 disabled:opacity-60"
                      />
                      {agendaDocUploading === 'juknis' && <span className="text-[10px] text-brand-orange animate-pulse whitespace-nowrap">Uploading...</span>}
                    </div>
                    {agendaJuknisUrl && agendaDocUploading !== 'juknis' && (
                      <p className="mt-1.5 flex items-center gap-2 text-[10px] text-brand-green">
                        <span className="truncate">✓ Tersimpan di Uploadcare{agendaJuknisName ? `: ${agendaJuknisName}` : ''}</span>
                        <button type="button" onClick={() => clearAgendaDoc('juknis')} className="text-red-500 hover:underline shrink-0 cursor-pointer">Hapus</button>
                      </p>
                    )}
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Surat Edaran (Opsional, PDF/Word)</label>
                    <div className="flex items-center gap-3">
                      <input
                        type="file"
                        accept=".pdf,.doc,.docx,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        disabled={agendaDocUploading !== null}
                        onChange={(e) => handleAgendaDocUpload(e, 'surat_edaran')}
                        className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-4 py-2.5 text-[10px] text-gray-500 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200 disabled:opacity-60"
                      />
                      {agendaDocUploading === 'surat_edaran' && <span className="text-[10px] text-brand-orange animate-pulse whitespace-nowrap">Uploading...</span>}
                    </div>
                    {agendaSuratEdaranUrl && agendaDocUploading !== 'surat_edaran' && (
                      <p className="mt-1.5 flex items-center gap-2 text-[10px] text-brand-green">
                        <span className="truncate">✓ Tersimpan di Uploadcare{agendaSuratEdaranName ? `: ${agendaSuratEdaranName}` : ''}</span>
                        <button type="button" onClick={() => clearAgendaDoc('surat_edaran')} className="text-red-500 hover:underline shrink-0 cursor-pointer">Hapus</button>
                      </p>
                    )}
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Tempat</label>
                    <input 
                      type="text" required value={agendaPlace} onChange={(e) => setAgendaPlace(e.target.value)}
                      placeholder="Bumi perkemahan, Aula, dsb." className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-4 py-2.5 text-xs text-gray-800 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                    />
                  </div>

                  {/* Tanggal Sudah Diputuskan Toggle */}
                  <div className="flex items-center gap-2 py-1">
                    <input 
                      type="checkbox" 
                      id="agendaIsDateDecided" 
                      checked={agendaIsDateDecided} 
                      onChange={(e) => setAgendaIsDateDecided(e.target.checked)}
                      className="w-4 h-4 text-brand-green border-slate-300 rounded focus:ring-brand-green"
                    />
                    <label htmlFor="agendaIsDateDecided" className="text-[10px] font-bold text-gray-500 uppercase cursor-pointer select-none">
                      Tanggal Sudah Diputuskan?
                    </label>
                  </div>

                  {agendaIsDateDecided ? (
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Mulai</label>
                        <input 
                          type="date" required={agendaIsDateDecided} value={agendaStart} onChange={(e) => setAgendaStart(e.target.value)}
                          className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-4 py-2.5 text-xs text-gray-800 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Selesai</label>
                        <input 
                          type="date" required={agendaIsDateDecided} value={agendaEnd} onChange={(e) => setAgendaEnd(e.target.value)}
                          className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-4 py-2.5 text-xs text-gray-800 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                        />
                      </div>
                    </div>
                  ) : (
                    <div>
                      <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Bulan Rencana</label>
                      <input 
                        type="month" required={!agendaIsDateDecided} value={agendaBulanRencana} onChange={(e) => setAgendaBulanRencana(e.target.value)}
                        className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-4 py-2.5 text-xs text-gray-800 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                      />
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Jenis</label>
                      <select 
                        value={agendaType} onChange={(e) => setAgendaType(e.target.value as any)}
                        className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-3 py-2.5 text-xs font-bold text-gray-800 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                      >
                        <option value="mandiri">Mandiri</option>
                        <option value="partisipasi">Partisipasi</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Tingkat</label>
                      <select 
                        value={agendaLevel} onChange={(e) => setAgendaLevel(e.target.value as any)}
                        className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-3 py-2.5 text-xs font-bold text-gray-800 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                      >
                        <option value="kabupaten">Kabupaten</option>
                        <option value="provinsi">Provinsi</option>
                        <option value="nasional">Nasional</option>
                        <option value="internasional">Internasional</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Estimasi Jumlah Peserta (Jiwa)</label>
                    <input 
                      type="number" required value={agendaEst} onChange={(e) => setAgendaEst(Number(e.target.value))}
                      className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-4 py-2.5 text-xs text-gray-800 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                    />
                  </div>

                  {/* Camp Fee Configuration */}
                  <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 space-y-3">
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        id="agendaIsCampFee"
                        checked={agendaIsCampFee}
                        onChange={(e) => setAgendaIsCampFee(e.target.checked)}
                        className="w-4 h-4 text-brand-orange border-slate-300 rounded focus:ring-brand-orange"
                      />
                      <label htmlFor="agendaIsCampFee" className="text-[10px] font-bold text-amber-700 uppercase cursor-pointer select-none">
                        Ada Camp Fee / Biaya Peserta?
                      </label>
                    </div>
                    {agendaIsCampFee && (
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Nominal Camp Fee (Rp)</label>
                        <input
                          type="number"
                          value={agendaCampFee}
                          onChange={(e) => setAgendaCampFee(Number(e.target.value))}
                          placeholder="Contoh: 150000"
                          className="w-full bg-white border border-slate-200/80 rounded-xl px-4 py-2.5 text-xs text-gray-800 focus:outline-none focus:border-brand-orange focus:ring-2 focus:ring-brand-orange/10 transition-all"
                        />
                        <p className="text-[9px] text-amber-600 mt-1 font-mono">Peserta wajib upload bukti pembayaran saat mendaftar.</p>
                      </div>
                    )}
                  </div>

                  <button
                    type="submit"
                    disabled={agendaSaving}
                    className="w-full bg-brand-brown-dark hover:bg-brand-brown-dark/95 text-white font-extrabold text-xs py-3 rounded-xl uppercase shadow cursor-pointer"
                  >
                    Tambah Agenda
                  </button>
                </form>
                  </div>
                </div>
              )}

              {/* Middle List: Action Center */}
              <div className="space-y-6">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-extrabold text-xl text-brand-brown-dark tracking-tight">Daftar Agenda Kegiatan & Aktivitas</h3>
                  <div className="flex gap-2">
                    <button onClick={() => {
                        setTempWilayahData(kecamatanList.map(k => ({ id: k.id, nama_kecamatan: k.nama_kecamatan, wilayah: k.wilayah || '' })));
                        setIsWilayahConfigModalOpen(true);
                      }} 
                      className="bg-brand-orange hover:bg-brand-orange/90 text-brand-brown-dark font-extrabold text-xs px-5 py-2.5 rounded-xl uppercase flex items-center gap-2 cursor-pointer shadow">
                      <Settings className="w-4 h-4" /> Config Wilayah Kwarran
                    </button>
                  <button onClick={() => setIsAddAgendaModalOpen(true)} className="bg-brand-brown-dark hover:bg-brand-brown-dark/95 text-white font-extrabold text-xs px-5 py-2.5 rounded-xl uppercase flex items-center gap-2 cursor-pointer shadow">
                    <Plus className="w-4 h-4" /> Tambah Kegiatan
                  </button>
                  </div>
                </div>
                <div className="bg-white border border-gray-200 rounded-3xl p-6 shadow-sm">

                  <div className="space-y-4">
                    {agendaList.map((a) => (
                      <div key={a.id} className="p-4 bg-gray-50 border border-gray-150 rounded-2xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 text-xs font-mono">
                        <div>
                          <div className="flex gap-2 mb-1.5 items-center">
                            <span className="bg-brand-orange/15 text-brand-orange font-bold px-2 py-0.5 rounded text-[9px] uppercase border border-brand-orange/10">
                              Tingkat {a.tingkat}
                            </span>
                            <span className="bg-gray-200 text-gray-600 font-bold px-2 py-0.5 rounded text-[9px] uppercase border">
                              {a.jenis}
                            </span>
                          </div>
                          <h4 className="font-extrabold text-sm text-brand-brown-dark tracking-tight leading-snug">{a.nama_kegiatan}</h4>
                          <p className="text-[10px] text-gray-400 mt-1">📍 {a.tempat} | 📅 {a.tanggal_mulai} s.d {a.tanggal_selesai}</p>
                        </div>

                        {/* Control buttons */}
                        <div className="flex flex-wrap gap-2 shrink-0">
                          {/* Toggle active registration */}
                          <div className="flex items-center gap-2.5 pr-1">
                            <span className={`text-[10px] font-black uppercase tracking-wider min-w-[82px] text-right ${
                              a.is_aktif_pendaftaran ? 'text-[#0E9F6E]' : 'text-gray-500'
                            }`}>
                              {togglingAgendaId === a.id ? 'Menyimpan...' : a.is_aktif_pendaftaran ? 'Pendaftaran Buka' : 'Pendaftaran Tutup'}
                            </span>
                            <button
                              type="button"
                              role="switch"
                              aria-checked={!!a.is_aktif_pendaftaran}
                              aria-label={`Pendaftaran ${a.nama_kegiatan}`}
                              title={a.is_aktif_pendaftaran ? 'Klik untuk menutup pendaftaran' : 'Klik untuk membuka pendaftaran'}
                              disabled={togglingAgendaId === a.id}
                              onClick={() => handleTogglePendaftaran(a)}
                              className={`relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors duration-200 cursor-pointer focus:outline-none focus-visible:ring-4 focus-visible:ring-[#0E9F6E]/30 disabled:opacity-60 disabled:cursor-wait ${
                                a.is_aktif_pendaftaran ? 'bg-[#0E9F6E]' : 'bg-gray-300'
                              }`}
                            >
                              <span className={`inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform duration-200 ${
                                a.is_aktif_pendaftaran ? 'translate-x-[22px]' : 'translate-x-0.5'
                              }`} />
                            </button>
                          </div>

                          {/* Open Form Config Builder */}
                          <button
                            onClick={() => handleOpenFormBuilder(a)}
                            className="bg-brand-teal/15 text-brand-teal border border-brand-teal/20 hover:bg-brand-teal/20 font-bold p-2 rounded-xl text-[10px] transition-all flex items-center gap-1 cursor-pointer"
                          >
                            Rancang Form
                          </button>

                          <button
                            onClick={() => handleOpenDashboard(a)}
                            className="bg-brand-orange/15 text-brand-orange border border-brand-orange/20 hover:bg-brand-orange/20 font-bold p-2 rounded-xl text-[10px] transition-all flex items-center gap-1 cursor-pointer"
                          >
                            Dashboard
                          </button>

                          <button
                            onClick={() => openDeleteAgendaModal(a)}
                            className="bg-brand-red/15 text-brand-red border border-brand-red/20 hover:bg-brand-red/25 p-2 rounded-xl cursor-pointer"
                          >
                            <Trash className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

              </div>

            </div>
            )}
          </div>
        )}

        {/* TAB: SURAT MASUK DARI DKR */}
        {activeTab === 'surat' && (
          <SuratAdminPanel list={suratList} reload={reloadSurat} />
        )}

        {/* TAB 4B: PERSONALIA DKC */}
        {activeTab === 'personalia' && (
          <div className="space-y-8">
            <div className="border-b border-gray-200 pb-4">
              <h1 className="text-2xl font-display font-extrabold text-brand-brown-dark tracking-tight">Personalia Dewan Kerja Cabang</h1>
              <p className="text-xs text-gray-500 font-mono mt-1">Kelola daftar pengurus DKC yang ditampilkan pada landingpage publik.</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">

              {/* Add form */}
              <div className="bg-white border border-gray-200 rounded-3xl p-6 shadow-sm space-y-5">
                <h3 className="font-extrabold text-base text-brand-brown-dark tracking-tight border-b-2 border-brand-orange pb-2">
                  Tambah Pengurus DKC
                </h3>

                <form onSubmit={handleAddPersonalia} className="space-y-4 text-xs font-mono">
                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Nama Pengurus</label>
                    <input
                      type="text" required value={newPersonNama} onChange={(e) => setNewPersonNama(e.target.value)}
                      placeholder="Contoh: Kak Fajar Ramadhan" className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-4 py-2.5 text-xs text-gray-800 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Jabatan Struktur</label>
                    <input
                      type="text" required value={newPersonJabatan} onChange={(e) => setNewPersonJabatan(e.target.value)}
                      placeholder="Contoh: Ketua DKC" className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-4 py-2.5 text-xs text-gray-800 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Golongan Kepramukaan</label>
                    <select
                      value={newPersonGolongan} onChange={(e) => setNewPersonGolongan(e.target.value as any)}
                      className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-3 py-2.5 text-xs font-bold text-gray-800 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                    >
                      <option value="penegak">Penegak</option>
                      <option value="pandega">Pandega</option>
                      <option value="pembina">Pembina</option>
                      <option value="lainnya">Lainnya</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Foto Formal (Unggah File)</label>
                    <input
                      type="file" accept="image/*" onChange={(e) => handleImageUpload(e, 'personalia')}
                      className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-4 py-2.5 text-[10px] text-gray-500 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                    />
                    {newPersonFoto && (
                      <img src={newPersonFoto} alt="Preview" className="w-16 h-16 object-cover rounded-xl mt-2 border" />
                    )}
                  </div>

                  <PersonaliaExtraFields value={newPersonExtra} onChange={setNewPersonExtra} />

                  <button
                    type="submit"
                    disabled={personaliaSaving}
                    className="w-full bg-brand-green hover:bg-brand-green/95 text-white font-extrabold text-xs py-3 rounded-xl uppercase shadow disabled:opacity-60 cursor-pointer"
                  >
                    {personaliaSaving ? 'Menyimpan...' : (editingPersonaliaId ? 'Simpan Perubahan' : 'Tambahkan Pengurus')}
                  </button>
                  {editingPersonaliaId && (
                    <button
                      type="button"
                      onClick={resetPersonaliaForm}
                      className="w-full bg-gray-100 hover:bg-gray-200 text-gray-600 font-bold text-xs py-2.5 rounded-xl uppercase cursor-pointer"
                    >
                      Batal Edit
                    </button>
                  )}
                </form>
              </div>

              {/* List Personalia */}
              <div className="lg:col-span-2 bg-white border border-gray-200 rounded-3xl p-6 sm:p-8 shadow-sm">
                <h3 className="font-extrabold text-base text-brand-brown-dark mb-4 tracking-tight border-b pb-2">
                  Personalia DKC Terdaftar ({personaliaList.length})
                </h3>

                <div className="space-y-4">
                  {personaliaList.length === 0 && (
                    <div className="bg-gray-50 border border-gray-150 rounded-2xl p-8 text-center text-gray-500 italic text-xs font-mono">
                      Belum ada pengurus DKC yang terdaftar.
                    </div>
                  )}
                  {personaliaList.sort((a, b) => a.urutan - b.urutan).map((p) => (
                    <div key={p.id} className="p-4 bg-gray-50 border border-gray-150 rounded-2xl flex items-center justify-between font-mono text-xs">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-xl bg-gray-200 overflow-hidden shrink-0">
                          <img src={p.foto_url} alt={p.nama} className="w-full h-full object-cover" />
                        </div>
                        <div>
                          <strong className="text-brand-brown-dark block leading-none">{p.nama}</strong>
                          <span className="text-[10px] text-gray-400 mt-1 block">{p.jabatan} • {p.golongan}</span>
                        </div>
                      </div>
                      <div className="flex flex-col gap-2 ml-4">
                        <button
                          onClick={() => {
                            setNewPersonNama(p.nama);
                            setNewPersonJabatan(p.jabatan);
                            setNewPersonGolongan(p.golongan);
                            setNewPersonFoto(p.foto_url);
                            setNewPersonExtra(extraFromPersonalia(p));
                            setEditingPersonaliaId(p.id);
                            window.scrollTo({ top: 0, behavior: 'smooth' });
                          }}
                          className="text-blue-500 hover:text-blue-600 font-bold text-[10px] cursor-pointer text-right"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => handleDeletePersonalia(p.id)}
                          className="text-brand-red hover:text-red-600 font-bold text-[10px] cursor-pointer text-right"
                        >
                          Hapus
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          </div>
        )}

        {/* TAB 5A: MANAJEMEN USER DKR KECAMATAN */}
        {activeTab === 'users_dkr' && (
          <div className="space-y-8">
            <div className="border-b border-gray-200 pb-4">
              <h1 className="text-2xl font-display font-extrabold text-brand-brown-dark tracking-tight">Manajemen Akun DKR Kecamatan</h1>
              <p className="text-xs text-gray-500 font-mono mt-1">Buat kredensial utusan DKR Kecamatan se-Kabupaten Tasikmalaya serta kelola hak akses portal.</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
              
              {/* Add DKR user form */}
              <div className="bg-white border border-gray-200 rounded-3xl p-6 shadow-sm space-y-5">
                <h3 className="font-extrabold text-base text-brand-brown-dark tracking-tight border-b-2 border-brand-orange pb-2">
                  Daftarkan Akun DKR Baru
                </h3>

                <form onSubmit={(e) => { setNewRole('user'); handleCreateUser(e); }} className="space-y-4 text-xs font-mono">
                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Nama Organisasi DKR</label>
                    <input 
                      type="text" required value={newNama} onChange={(e) => setNewNama(e.target.value)}
                      placeholder="Contoh: DKR Singaparna" 
                      className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-4 py-2.5 text-xs text-gray-800 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Alamat Email Kredensial</label>
                    <input 
                      type="email" required value={newEmail} onChange={(e) => setNewEmail(e.target.value)}
                      placeholder="singaparna@dkctasik.org" 
                      className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-4 py-2.5 text-xs text-gray-800 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Kata Sandi Default</label>
                    <input 
                      type="password" required value={newPassword} onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="••••••••" className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-4 py-2.5 text-xs text-gray-800 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Kecamatan Relasi</label>
                    <select 
                      value={newKecaId} onChange={(e) => setNewKecaId(e.target.value)} required
                      className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-3 py-2.5 text-xs font-bold text-gray-800 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                    >
                      <option value="">-- Pilih Kecamatan --</option>
                      {kecamatanList.map(k => (
                        <option key={k.id} value={k.id}>{k.nama_kecamatan}</option>
                      ))}
                    </select>
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-brand-green hover:bg-brand-green/95 text-white font-extrabold text-xs py-3 rounded-xl uppercase shadow cursor-pointer"
                  >
                    Daftarkan Akun DKR
                  </button>
                </form>
              </div>

              {/* List user list & status */}
              <div className="lg:col-span-2 bg-white border border-gray-200 rounded-3xl p-6 sm:p-8 shadow-sm">
                <h3 className="font-extrabold text-base text-brand-brown-dark mb-4 tracking-tight border-b pb-2">
                  Daftar Kredensial DKR Terdaftar
                </h3>

                <div className="space-y-4">
                  {userList.filter(u => u.role === 'user').map((usr) => {
                    const keca = kecamatanList.find(k => k.id === usr.kecamatan_id);
                    return (
                      <div key={usr.email} className="p-4 bg-gray-50 border border-gray-150 rounded-2xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 text-xs font-mono">
                        <div>
                          <span className="bg-brand-brown-dark text-white font-bold px-2 py-0.5 rounded text-[8px] uppercase font-mono">
                            DKR KECAMATAN
                          </span>
                          <h4 className="font-extrabold text-sm text-brand-brown-dark tracking-tight leading-none mt-2">{usr.nama}</h4>
                          <p className="text-[10px] text-gray-400 mt-1">{usr.email}</p>
                        </div>

                        
                          <button
                            onClick={() => handleResetPassword(usr.user_id, usr.nama)}
                            className="bg-brand-orange/10 hover:bg-brand-orange/20 text-brand-orange border border-brand-orange/20 px-3 py-1 rounded-xl text-[10px] font-extrabold flex items-center gap-1 transition-colors"
                          >
                            <Key className="w-3.5 h-3.5" /> Reset Password
                          </button>

                        {/* Toggle active button for DKR */}
                        {keca && (
                          <div className="flex items-center gap-3">
                            <span className="text-[10px] text-gray-500">Status Landingpage:</span>
                            <button
                              onClick={() => handleToggleKecamatanActive(keca.id)}
                              className="focus:outline-none cursor-pointer"
                            >
                              {keca.is_dkr_aktif ? (
                                <span className="bg-brand-green/10 text-brand-green border border-brand-green/20 px-3 py-1 rounded-xl text-[10px] font-extrabold flex items-center gap-1">
                                  <Check className="w-3.5 h-3.5" /> Tampil Publik
                                </span>
                              ) : (
                                <span className="bg-brand-orange/10 text-brand-orange border border-brand-orange/20 px-3 py-1 rounded-xl text-[10px] font-extrabold flex items-center gap-1">
                                  <X className="w-3.5 h-3.5" /> Sembunyi Publik
                                </span>
                              )}
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                  {userList.filter(u => u.role === 'user').length === 0 && (
                    <p className="text-center text-gray-400 py-6">Belum ada akun DKR terdaftar.</p>
                  )}
                </div>
              </div>

            </div>
          </div>
        )}

        {/* TAB 5B: MANAJEMEN USER SAKA KABUPATEN */}
        {activeTab === 'users_saka' && (
          <div className="space-y-8">
            <div className="border-b border-gray-200 pb-4">
              <h1 className="text-2xl font-display font-extrabold text-brand-brown-dark tracking-tight">Manajemen Akun SAKA Kabupaten</h1>
              <p className="text-xs text-gray-500 font-mono mt-1">Buat kredensial utusan SAKA (Satuan Karya) Tingkat Kabupaten Tasikmalaya serta kelola hak akses portal.</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
              
              {/* Add SAKA user form */}
              <div className="bg-white border border-gray-200 rounded-3xl p-6 shadow-sm space-y-5">
                <h3 className="font-extrabold text-base text-brand-brown-dark tracking-tight border-b-2 border-brand-orange pb-2">
                  Daftarkan Akun SAKA Baru
                </h3>

                <form onSubmit={(e) => { setNewRole('saka'); handleCreateUser(e); }} className="space-y-4 text-xs font-mono">
                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Nama Organisasi SAKA</label>
                    <input 
                      type="text" required value={newNama} onChange={(e) => setNewNama(e.target.value)}
                      placeholder="Contoh: Saka Bhayangkara" 
                      className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-4 py-2.5 text-xs text-gray-800 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Alamat Email Kredensial</label>
                    <input 
                      type="email" required value={newEmail} onChange={(e) => setNewEmail(e.target.value)}
                      placeholder="bhayangkara@dkctasik.org" 
                      className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-4 py-2.5 text-xs text-gray-800 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Kata Sandi Default</label>
                    <input 
                      type="password" required value={newPassword} onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="••••••••" className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-4 py-2.5 text-xs text-gray-800 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">SAKA Relasi</label>
                    <select 
                      value={newSakaId} onChange={(e) => setNewSakaId(e.target.value)} required
                      className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-3 py-2.5 text-xs font-bold text-gray-800 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                    >
                      <option value="">-- Pilih SAKA --</option>
                      {sakaList.map(s => (
                        <option key={s.id} value={s.id}>{s.nama_saka}</option>
                      ))}
                    </select>
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-brand-green hover:bg-brand-green/95 text-white font-extrabold text-xs py-3 rounded-xl uppercase shadow cursor-pointer"
                  >
                    Daftarkan Akun SAKA
                  </button>
                </form>
              </div>

              {/* List user list & status */}
              <div className="lg:col-span-2 bg-white border border-gray-200 rounded-3xl p-6 sm:p-8 shadow-sm">
                <h3 className="font-extrabold text-base text-brand-brown-dark mb-4 tracking-tight border-b pb-2">
                  Daftar Kredensial SAKA Terdaftar
                </h3>

                <div className="space-y-4">
                  {userList.filter(u => u.role === 'saka').map((usr) => {
                    const sakaItem = sakaList.find(s => s.id === usr.saka_id);
                    return (
                      <div key={usr.email} className="p-4 bg-gray-50 border border-gray-150 rounded-2xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 text-xs font-mono">
                        <div>
                          <span className="bg-brand-brown-dark text-white font-bold px-2 py-0.5 rounded text-[8px] uppercase font-mono">
                            SAKA KABUPATEN
                          </span>
                          <h4 className="font-extrabold text-sm text-brand-brown-dark tracking-tight leading-none mt-2">{usr.nama}</h4>
                          <p className="text-[10px] text-gray-400 mt-1">{usr.email}</p>
                        </div>

                          <button
                            onClick={() => handleResetPassword(usr.user_id, usr.nama)}
                            className="bg-brand-orange/10 hover:bg-brand-orange/20 text-brand-orange border border-brand-orange/20 px-3 py-1 rounded-xl text-[10px] font-extrabold flex items-center gap-1 transition-colors shrink-0"
                          >
                            <Key className="w-3.5 h-3.5" /> Reset Password
                          </button>


                        {/* Toggle active button for SAKA */}
                        {sakaItem && (
                          <div className="flex items-center gap-3">
                            <span className="text-[10px] text-gray-500">Status Landingpage:</span>
                            <button
                              onClick={() => handleToggleSakaActive(sakaItem.id)}
                              className="focus:outline-none cursor-pointer"
                            >
                              {sakaItem.is_aktif ? (
                                <span className="bg-brand-green/10 text-brand-green border border-brand-green/20 px-3 py-1 rounded-xl text-[10px] font-extrabold flex items-center gap-1">
                                  <Check className="w-3.5 h-3.5" /> Tampil Publik
                                </span>
                              ) : (
                                <span className="bg-brand-orange/10 text-brand-orange border border-brand-orange/20 px-3 py-1 rounded-xl text-[10px] font-extrabold flex items-center gap-1">
                                  <X className="w-3.5 h-3.5" /> Sembunyi Publik
                                </span>
                              )}
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                  {userList.filter(u => u.role === 'saka').length === 0 && (
                    <p className="text-center text-gray-400 py-6">Belum ada akun SAKA terdaftar.</p>
                  )}
                </div>
              </div>

            </div>
          </div>
        )}

        {/* TAB 6: KELOLA LANDING PAGE CONTENT */}
        {activeTab === 'konten' && (
          <div className="space-y-8">
            <div className="border-b border-gray-200 pb-4">
              <h1 className="text-2xl font-display font-extrabold text-brand-brown-dark tracking-tight">Kustomisasi Konten & Warna Landingpage</h1>
              <p className="text-xs text-gray-500 font-mono mt-1">Sesuaikan informasi hero banner, warna tampilan, kontak footer, serta sejarah DKC dari masa ke masa.</p>
            </div>

            <div className="bg-white border border-gray-200 rounded-3xl p-6 sm:p-8 shadow-sm">
              <form onSubmit={handleSaveSiteContent} className="space-y-6 text-xs font-mono">
                
                {/* PART 1: TEXT CONTENT */}
                <div className="space-y-5">
                  <h3 className="font-extrabold text-sm text-brand-brown-dark tracking-tight border-b pb-2 flex items-center gap-2">
                    <span className="w-5 h-5 bg-brand-orange text-white rounded-full flex items-center justify-center text-[10px]">1</span>
                    Kelola Informasi Hero Banner
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Judul Utama Hero</label>
                      <input 
                        type="text" required value={heroTitle} onChange={(e) => setHeroTitle(e.target.value)}
                        placeholder="Contoh: Dewan Kerja Cabang" className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-4 py-3 text-xs text-gray-800 font-bold focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Subjudul / Wilayah</label>
                      <input 
                        type="text" required value={heroSubtitle} onChange={(e) => setHeroSubtitle(e.target.value)}
                        placeholder="Contoh: Kabupaten Tasikmalaya" className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-4 py-3 text-xs text-gray-800 font-bold focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Teks Slogan / Tagline Banner</label>
                    <input 
                      type="text" required value={heroBadge} onChange={(e) => setHeroBadge(e.target.value)}
                      placeholder="Satyaku Kudarmakan, Darmaku Kubaktikan" className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-4 py-3 text-xs text-gray-800 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Deskripsi Panjang (Lead Intro)</label>
                    <textarea 
                      required rows={3} value={heroLead} onChange={(e) => setHeroLead(e.target.value)}
                      placeholder="Narasi pendek visi dewan kerja di hero" className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-4 py-3 text-xs font-sans text-gray-800 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Label Tombol CTA</label>
                    <input 
                      type="text" required value={heroCta} onChange={(e) => setHeroCta(e.target.value)}
                      placeholder="Jelajahi Kegiatan" className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-4 py-3 text-xs text-gray-800 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                    />
                  </div>

                  {/* MEDSOS LINKS */}
                  <div className="bg-gradient-to-br from-pink-50 to-purple-50 border border-pink-100 rounded-2xl p-5 sm:p-6 space-y-4 shadow-sm">
                    <p className="font-extrabold text-xs text-brand-brown-dark uppercase tracking-wider font-mono flex items-center gap-2">
                      <span>📱</span> Link Media Sosial DKC
                    </p>
                    <p className="text-[10px] text-gray-500 font-mono mb-4">Tautan ini akan ditampilkan pada Footer website publik.</p>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono">
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Instagram URL</label>
                        <input type="url" value={dkcMedsosIg} onChange={(e) => setDkcMedsosIg(e.target.value)} placeholder="https://instagram.com/dkctasikmalaya" className="w-full bg-white border border-pink-200 rounded-xl px-4 py-2.5 text-xs text-gray-800 focus:outline-none focus:border-pink-400 focus:ring-2 focus:ring-pink-400/20" />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">YouTube URL</label>
                        <input type="url" value={dkcMedsosYt} onChange={(e) => setDkcMedsosYt(e.target.value)} placeholder="https://youtube.com/..." className="w-full bg-white border border-pink-200 rounded-xl px-4 py-2.5 text-xs text-gray-800 focus:outline-none focus:border-pink-400 focus:ring-2 focus:ring-pink-400/20" />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">TikTok URL</label>
                        <input type="url" value={dkcMedsosTk} onChange={(e) => setDkcMedsosTk(e.target.value)} placeholder="https://tiktok.com/@dkctasikmalaya" className="w-full bg-white border border-pink-200 rounded-xl px-4 py-2.5 text-xs text-gray-800 focus:outline-none focus:border-pink-400 focus:ring-2 focus:ring-pink-400/20" />
                      </div>
                    </div>
                  </div>

                  {/* HERO BACKGROUND CONFIGURATION */}
                  <div className="bg-gray-50 border border-gray-200 rounded-2xl p-4 sm:p-5 space-y-4">
                    <p className="font-extrabold text-xs text-brand-brown-dark uppercase tracking-wider font-mono flex items-center gap-2">
                      <span>🖼️</span> Foto Background Hero & Opacity
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-5 items-start font-mono">
                      <div className="space-y-3">
                        <div>
                          <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Foto Background</label>
                          {heroBgImageUrl && (
                            <div className="mb-2 w-full h-24 rounded-xl overflow-hidden border border-slate-200/80 bg-gray-100">
                              <img src={heroBgImageUrl} alt="Preview background hero" className="w-full h-full object-cover" />
                            </div>
                          )}
                        </div>
                        
                        <div className="flex items-center gap-3">
                          <input 
                            type="file" accept="image/*" onChange={(e) => handleImageUpload(e, 'hero')}
                            id="hero-bg-upload-input" className="hidden"
                          />
                          <label 
                            htmlFor="hero-bg-upload-input"
                            className="bg-brand-brown-dark hover:bg-brand-orange text-white font-mono font-bold text-[10px] py-2.5 px-4 rounded-xl cursor-pointer transition-all duration-200 uppercase tracking-wider inline-flex items-center gap-1.5 shrink-0"
                          >
                            <Upload className="w-3.5 h-3.5" />
                            <span>Unggah Foto</span>
                          </label>
                          <p className="text-[9px] text-gray-400 leading-none">Otomatis dikompres &amp; diunggah ke Cloudinary</p>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <div>
                          <div className="flex justify-between items-center mb-1">
                            <label className="block text-[10px] font-bold text-gray-400 uppercase">Transparansi / Opacity Foto ({Math.round(heroBgOpacity * 100)}%)</label>
                            <span className="text-[10px] font-mono font-bold text-brand-brown-dark">{heroBgOpacity}</span>
                          </div>
                          <input 
                            type="range" min="0" max="1" step="0.05" value={heroBgOpacity} onChange={(e) => setHeroBgOpacity(parseFloat(e.target.value))}
                            className="w-full accent-brand-orange h-1.5 bg-gray-200 rounded-lg cursor-pointer"
                          />
                          <p className="text-[9px] text-gray-400 font-sans mt-1">
                            *Catatan: Semakin rendah opacity, warna gradien landing page akan semakin dominan.
                          </p>
                        </div>

                        {heroBgImageUrl && (
                          <div className="flex items-center gap-3 pt-1">
                            <span className="text-[10px] text-gray-500">Preview:</span>
                            <div className="relative w-16 h-12 rounded-lg overflow-hidden border border-gray-200 shrink-0 bg-brand-brown-dark">
                              <img 
                                src={heroBgImageUrl} 
                                alt="Preview background" 
                                className="w-full h-full object-cover"
                                style={{ opacity: heroBgOpacity }}
                                referrerPolicy="no-referrer"
                              />
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* PART 2: COLOR THEME CUSTOMIZER */}
                <div className="pt-6 border-t-2 border-dashed border-gray-150 space-y-5">
                  <h3 className="font-extrabold text-sm text-brand-brown-dark tracking-tight pb-2 flex items-center gap-2">
                    <span className="w-5 h-5 bg-brand-green text-white rounded-full flex items-center justify-center text-[10px]">2</span>
                    Skema Warna Landingpage (Theme Customizer)
                  </h3>

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    
                    {/* Left: manual input sliders */}
                    <div className="space-y-4">
                      <p className="text-[10px] text-gray-500 font-sans leading-relaxed">
                        Pilih warna kustom satu-persatu untuk landing page Anda, atau gunakan panel analisis AI di kanan untuk mendeteksi warna otomatis dari foto / logo.
                      </p>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {/* Orange slot */}
                        <div className="bg-gray-50 p-3 rounded-2xl border border-gray-150">
                          <label className="block text-[9px] font-bold text-gray-400 uppercase mb-1.5">Warna Utama (Oranye)</label>
                          <div className="flex gap-2">
                            <input 
                              type="color" value={brandOrange} onChange={(e) => setBrandOrange(e.target.value)}
                              className="w-8 h-8 rounded-lg border border-gray-200 cursor-pointer shrink-0"
                            />
                            <input 
                              type="text" value={brandOrange} onChange={(e) => setBrandOrange(e.target.value)}
                              placeholder="#F5A623" className="w-full bg-white border rounded-lg px-2 text-xs font-mono font-bold"
                            />
                          </div>
                        </div>

                        {/* Green slot */}
                        <div className="bg-gray-50 p-3 rounded-2xl border border-gray-150">
                          <label className="block text-[9px] font-bold text-gray-400 uppercase mb-1.5">Warna Sekunder (Hijau)</label>
                          <div className="flex gap-2">
                            <input 
                              type="color" value={brandGreen} onChange={(e) => setBrandGreen(e.target.value)}
                              className="w-8 h-8 rounded-lg border border-gray-200 cursor-pointer shrink-0"
                            />
                            <input 
                              type="text" value={brandGreen} onChange={(e) => setBrandGreen(e.target.value)}
                              placeholder="#4CAF50" className="w-full bg-white border rounded-lg px-2 text-xs font-mono font-bold"
                            />
                          </div>
                        </div>

                        {/* Brown dark slot */}
                        <div className="bg-gray-50 p-3 rounded-2xl border border-gray-150">
                          <label className="block text-[9px] font-bold text-gray-400 uppercase mb-1.5">Warna Gelap (Cokelat Tua)</label>
                          <div className="flex gap-2">
                            <input 
                              type="color" value={brandBrownDark} onChange={(e) => setBrandBrownDark(e.target.value)}
                              className="w-8 h-8 rounded-lg border border-gray-200 cursor-pointer shrink-0"
                            />
                            <input 
                              type="text" value={brandBrownDark} onChange={(e) => setBrandBrownDark(e.target.value)}
                              placeholder="#5C4033" className="w-full bg-white border rounded-lg px-2 text-xs font-mono font-bold"
                            />
                          </div>
                        </div>

                        {/* Brown mid slot */}
                        <div className="bg-gray-50 p-3 rounded-2xl border border-gray-150">
                          <label className="block text-[9px] font-bold text-gray-400 uppercase mb-1.5">Warna Penengah (Cokelat Sedang)</label>
                          <div className="flex gap-2">
                            <input 
                              type="color" value={brandBrownMid} onChange={(e) => setBrandBrownMid(e.target.value)}
                              className="w-8 h-8 rounded-lg border border-gray-200 cursor-pointer shrink-0"
                            />
                            <input 
                              type="text" value={brandBrownMid} onChange={(e) => setBrandBrownMid(e.target.value)}
                              placeholder="#8B7355" className="w-full bg-white border rounded-lg px-2 text-xs font-mono font-bold"
                            />
                          </div>
                        </div>
                      </div>

                      <div>
                        <button
                          type="button"
                          onClick={handleResetTheme}
                          className="text-[9px] font-extrabold uppercase tracking-wider text-brand-red bg-brand-red/10 border border-brand-red/20 px-3 py-2 rounded-lg flex items-center gap-1 hover:bg-brand-red/15 cursor-pointer"
                        >
                          <RefreshCw className="w-3 h-3" /> Reset ke Default Tasik
                        </button>
                      </div>
                    </div>

                    {/* Right: AI upload area */}
                    <div className="space-y-4 border-l pl-0 lg:pl-6 border-dashed border-gray-200">
                      <div className="flex items-center justify-between border-b pb-1">
                        <span className="text-[10px] font-bold uppercase tracking-widest text-brand-orange flex items-center gap-1">
                          <Palette className="w-3.5 h-3.5" /> Deteksi Warna Dari Gambar
                        </span>
                        <span className="bg-brand-green/10 text-brand-green font-bold text-[8px] px-2 py-0.5 rounded uppercase">
                          Auto-Detector
                        </span>
                      </div>

                      <p className="text-[10px] text-gray-500 font-sans leading-relaxed">
                        Unggah pamflet kegiatan atau logo resmi daerah Anda. Sistem kami akan menganalisis visual gambar untuk mengekstrak dan memetakan warnanya secara instan.
                      </p>

                      <div className="border-2 border-dashed border-gray-300 hover:border-brand-green bg-gray-50/50 rounded-2xl p-4 text-center hover:bg-gray-50/80 transition-all relative">
                        <input 
                          type="file" accept="image/*" onChange={handleImageColorUpload}
                          className="hidden" id="theme-image-file"
                        />
                        <label htmlFor="theme-image-file" className="cursor-pointer flex flex-col items-center justify-center space-y-2 py-3">
                          <Upload className="w-7 h-7 text-brand-green" />
                          <div className="text-xs font-bold text-brand-brown-dark">Pilih / Unggah Gambar Visual</div>
                          <div className="text-[9px] text-gray-400">Analisis instan JPG, PNG, WEBP</div>
                        </label>
                      </div>

                      {isExtracting && (
                        <div className="text-center py-2 text-brand-brown-mid font-bold animate-pulse text-[10px] flex items-center justify-center gap-2">
                          <div className="w-3.5 h-3.5 border-2 border-brand-orange border-t-transparent rounded-full animate-spin" />
                          Menganalisis skema warna gambar...
                        </div>
                      )}

                      {extractedColors.length > 0 && (
                        <div className="space-y-3 bg-gray-50 p-4 border border-gray-150 rounded-2xl">
                          <div className="flex items-center justify-between">
                            <span className="text-[9px] font-bold text-gray-400 uppercase tracking-wider block">Warna Terdeteksi ({extractedColors.length})</span>
                            <button 
                              type="button" onClick={() => autoAssignColors(extractedColors)}
                              className="text-[9px] bg-brand-green hover:bg-brand-green/90 text-white font-extrabold px-2.5 py-1 rounded-lg uppercase tracking-wider"
                            >
                              Auto-Assign
                            </button>
                          </div>
                          
                          <div className="grid grid-cols-4 gap-2">
                            {extractedColors.map((hex) => (
                              <div key={hex} className="flex flex-col items-center p-1.5 border rounded-xl bg-white shadow-sm">
                                <div className="w-7 h-7 rounded-full border shadow-inner mb-1" style={{ backgroundColor: hex }} />
                                <span className="text-[8px] font-bold text-gray-600 mb-1">{hex}</span>
                                <div className="grid grid-cols-2 gap-1 w-full">
                                  <button 
                                    type="button" onClick={() => setBrandOrange(hex)} title="Set Warna Utama"
                                    className="bg-brand-orange/15 hover:bg-brand-orange/30 text-brand-orange font-black text-[8px] py-0.5 rounded text-center cursor-pointer"
                                  >
                                    O
                                  </button>
                                  <button 
                                    type="button" onClick={() => setBrandGreen(hex)} title="Set Warna Sekunder"
                                    className="bg-brand-green/15 hover:bg-brand-green/30 text-brand-green font-black text-[8px] py-0.5 rounded text-center cursor-pointer"
                                  >
                                    H
                                  </button>
                                  <button 
                                    type="button" onClick={() => setBrandBrownDark(hex)} title="Set Warna Gelap"
                                    className="bg-brand-brown-dark/15 hover:bg-brand-brown-dark/30 text-brand-brown-dark font-black text-[8px] py-0.5 rounded text-center cursor-pointer"
                                  >
                                    G
                                  </button>
                                  <button 
                                    type="button" onClick={() => setBrandBrownMid(hex)} title="Set Warna Penengah"
                                    className="bg-brand-brown-mid/15 hover:bg-brand-brown-mid/30 text-brand-brown-mid font-black text-[8px] py-0.5 rounded text-center cursor-pointer"
                                  >
                                    P
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>
                          <p className="text-[8px] text-gray-400 font-sans italic text-center">
                            *Keterangan tombol: O (Oranye/Utama), H (Hijau/Sekunder), G (Gelap/Cokelat), P (Penengah).
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Unified Save Action bar */}
                <div className="pt-6 border-t flex justify-end">
                  <button
                    type="submit"
                    className="bg-brand-brown-dark hover:bg-brand-brown-dark/95 text-white font-extrabold text-xs px-6 py-3.5 rounded-xl uppercase shadow cursor-pointer flex items-center gap-2"
                  >
                    <Save className="w-4 h-4 text-brand-orange" /> Simpan Pembaruan Landingpage
                  </button>
                </div>
              </form>
            </div>

            {/* Kontak footer (alamat, email, telp) */}
            <FooterKontakEditor />

            {/* Sejarah DKC dari masa ke masa (tampil di section profil landingpage) */}
            <SejarahDkcEditor />
          </div>
        )}

        {/* TAB: PENGUMUMAN LANDINGPAGE (section + popup promosi) */}
        {activeTab === 'pengumuman' && <PengumumanEditor />}

        {/* DKC ADMIN TAB: PUSAT UNDUHAN BERKAS (INFORMASI) */}
        {activeTab === 'informasi' && (
          <div className="space-y-8 animate-fade-in">
            <div className="border-b border-gray-200 pb-4">
              <h1 className="text-2xl font-display font-extrabold text-brand-brown-dark tracking-tight">Pusat Unduhan Berkas</h1>
              <p className="text-xs text-gray-500 font-mono mt-1">Kelola dokumen & informasi resmi yang tampil di landing page. Berkas diunggah ke Uploadcare, link-nya otomatis tercatat di Supabase.</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Form Tambah Berkas */}
              <div className="lg:col-span-1 bg-white border border-gray-200 rounded-3xl p-6 shadow-sm space-y-5">
                <h3 className="font-extrabold text-base text-brand-brown-dark tracking-tight border-b-2 border-brand-green pb-2">
                  Tambah Berkas Baru
                </h3>
                <form onSubmit={handleSaveInformasi} className="space-y-4 text-xs font-mono">
                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">Judul Berkas</label>
                    <input
                      type="text" required value={infoJudul} onChange={(e) => setInfoJudul(e.target.value)}
                      placeholder="Contoh: Jukran Adat Ambalan 2026"
                      className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-4 py-3 text-xs text-gray-800 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">Deskripsi Singkat</label>
                    <textarea
                      rows={3} value={infoDeskripsi} onChange={(e) => setInfoDeskripsi(e.target.value)}
                      placeholder="Deskripsi singkat isi berkas ini"
                      className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-4 py-3 text-xs text-gray-800 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">Tipe Berkas</label>
                    <select
                      value={infoTipe} onChange={(e) => setInfoTipe(e.target.value as 'gambar' | 'dokumen')}
                      className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-4 py-3 text-xs text-gray-800 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                    >
                      <option value="dokumen">Dokumen / Jukran (PDF, DOCX)</option>
                      <option value="gambar">Aset Gambar / Media</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">Unggah Berkas (ke Uploadcare)</label>
                    <input
                      type="file"
                      accept={infoTipe === 'gambar' ? 'image/*' : '.pdf,.doc,.docx,image/*'}
                      onChange={handleInformasiFileUpload}
                      disabled={infoUploading}
                      className="w-full bg-gray-50 border border-slate-200/80 rounded-xl px-4 py-2.5 text-[10px] text-gray-500 focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10 focus:bg-white transition-all duration-200"
                    />
                    {infoUploading && (
                      <p className="mt-2 text-[10px] text-brand-orange font-bold">Mengunggah &amp; mengompres berkas...</p>
                    )}
                    {infoFileUrl && !infoUploading && (
                      <div className="mt-2 text-[10px] text-brand-green font-bold">
                        ✓ Berhasil diunggah: <a href={infoFileUrl} target="_blank" rel="noopener noreferrer" className="underline break-all">{infoFileUrl}</a>
                      </div>
                    )}
                  </div>

                  <button
                    type="submit"
                    disabled={infoSaving || infoUploading || !infoFileUrl}
                    className="w-full bg-brand-brown-dark hover:bg-brand-orange disabled:opacity-40 disabled:cursor-not-allowed text-white font-extrabold text-xs px-6 py-3.5 rounded-xl uppercase shadow cursor-pointer flex items-center justify-center gap-2"
                  >
                    <Save className="w-4 h-4" /> {infoSaving ? 'Menyimpan...' : 'Simpan ke Pusat Unduhan'}
                  </button>
                </form>
              </div>

              {/* List Berkas Terdaftar */}
              <div className="lg:col-span-2 bg-white border border-gray-200 rounded-3xl p-6 sm:p-8 shadow-sm">
                <h3 className="font-extrabold text-base text-brand-brown-dark mb-4 tracking-tight border-b pb-2">
                  Daftar Berkas Terdaftar ({informasiList.length})
                </h3>
                <div className="space-y-3">
                  {informasiList.map((info) => (
                    <div key={info.id} className="p-4 bg-gray-50 border border-gray-150 rounded-2xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 text-xs font-mono">
                      <div>
                        <span className={`text-[9px] font-mono font-bold uppercase tracking-widest px-2.5 py-1 rounded-full mb-2 inline-block ${
                          info.tipe === 'gambar' ? 'bg-[#F9A825]/15 text-[#F9A825]' : 'bg-[#00A99D]/15 text-[#00A99D]'
                        }`}>
                          {info.tipe === 'gambar' ? 'Aset Gambar / Media' : 'Dokumen / Jukran'}
                        </span>
                        <h4 className="font-extrabold text-sm text-brand-brown-dark tracking-tight leading-none">{info.judul}</h4>
                        {info.deskripsi && <p className="text-[10px] text-gray-400 mt-1 max-w-md">{info.deskripsi}</p>}
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <a
                          href={info.file_url} target="_blank" rel="noopener noreferrer"
                          className="bg-brand-teal/10 hover:bg-brand-teal/20 text-brand-teal px-3 py-2 rounded-xl font-bold text-[10px] flex items-center gap-1.5 uppercase tracking-wider"
                        >
                          <Eye className="w-3.5 h-3.5" /> Lihat
                        </a>
                        <button
                          onClick={() => handleDeleteInformasi(info.id)}
                          className="bg-brand-red/10 hover:bg-brand-red/20 text-brand-red px-3 py-2 rounded-xl font-bold text-[10px] flex items-center gap-1.5 uppercase tracking-wider cursor-pointer"
                        >
                          <Trash className="w-3.5 h-3.5" /> Hapus
                        </button>
                      </div>
                    </div>
                  ))}
                  {informasiList.length === 0 && (
                    <p className="text-center text-gray-400 py-6">Belum ada berkas yang diunggah.</p>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* DKC ADMIN TAB 9: VERIFIKASI LAPORAN 02GP & 01 DIKLAT */}
        {activeTab === 'laporan' && (
          <div className="space-y-8 animate-fade-in">
            <div className="border-b border-gray-200 pb-4">
              <h1 className="text-2xl font-display font-extrabold text-brand-brown-dark tracking-tight flex items-center gap-2">
                <Award className="w-7 h-7 text-[#0E9F6E]" />
                Verifikasi & Penilaian Laporan Kwarran
              </h1>
              <p className="text-xs text-gray-500 font-mono mt-1">
                Proses laporan kegiatan 02GP dan 01 Diklat yang dikirimkan oleh Dewan Kerja Ranting se-Kabupaten Tasikmalaya. Berikan keterangan status serta poin keaktifan kegiatan.
              </p>
            </div>

            {/* Aksi Klasemen Toggle Card */}
            <VisibilityToggleCard
              icon={<BarChart2 className="w-5 h-5 text-brand-orange" />}
              title="Klasemen Keaktifan Kwarran"
              description="Klasemen dihitung otomatis dari poin laporan kegiatan 02GP & 01 Diklat yang sudah disetujui admin. Nonaktifkan untuk menyembunyikan klasemen dari website publik."
              checked={showKlasemen}
              saving={savingKlasemen}
              onChange={handleToggleKlasemen}
              onLabel="Aktif"
              offLabel="Nonaktif"
              effects={['Section Klasemen di landingpage', 'Menu "Klasemen DKR" di navbar']}
            />

            {/* Aksi Visibilitas Menu Laporan Toggle Card */}
            <div className="bg-slate-50 border border-slate-200 rounded-3xl p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6 mt-6">
              <div className="space-y-1">
                <h3 className="text-sm font-extrabold text-brand-brown-dark flex items-center gap-2">
                  <Eye className="w-5 h-5 text-[#0E9F6E]" />
                  Visibilitas Menu Laporan di Dashboard DKR
                </h3>
                <p className="text-xs text-gray-500 max-w-xl">
                  Atur apakah menu "Laporan 02GP & 01 Diklat" dapat diakses oleh DKR di dashboard mereka. Gunakan ini untuk menonaktifkan fitur pelaporan sementara waktu.
                </p>
              </div>

              <div>
                <button
                  onClick={() => handleToggleLaporanMenu(!showLaporanMenu)}
                  className={`w-full md:w-auto px-5 py-3 rounded-2xl font-black font-mono text-xs uppercase tracking-wider shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer ${
                    showLaporanMenu
                      ? 'bg-brand-orange hover:bg-orange-500 text-white'
                      : 'bg-gray-200 hover:bg-gray-300 text-gray-600'
                  }`}
                >
                  {showLaporanMenu ? (
                    <>
                      <Check className="w-4 h-4" /> Menu Laporan (Aktif)
                    </>
                  ) : (
                    <>
                      <X className="w-4 h-4" /> Menu Disembunyikan
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* List of Laporan Section */}
            <div className="bg-white border border-gray-200 rounded-3xl shadow-xs overflow-hidden">
              
              {/* Header with Sub-tabs */}
              <div className="border-b border-gray-200 bg-slate-50/50 px-6 py-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      setLaporanSubTab('pending');
                      setExpandedLaporanId(null);
                    }}
                    className={`px-4 py-2 rounded-xl text-xs font-bold font-mono transition-all flex items-center gap-2 cursor-pointer ${
                      laporanSubTab === 'pending'
                        ? 'bg-white text-brand-brown-dark shadow-sm border border-slate-200/80'
                        : 'text-gray-500 hover:bg-slate-100/80'
                    }`}
                  >
                    🔵 Belum Terverifikasi
                    <span className="bg-blue-100 text-blue-700 text-[10px] font-bold px-2 py-0.5 rounded-full">
                      {laporanList.filter(l => l.status === 'pending').length}
                    </span>
                  </button>
                  <button
                    onClick={() => {
                      setLaporanSubTab('verified');
                      setExpandedLaporanId(null);
                    }}
                    className={`px-4 py-2 rounded-xl text-xs font-bold font-mono transition-all flex items-center gap-2 cursor-pointer ${
                      laporanSubTab === 'verified'
                        ? 'bg-white text-brand-brown-dark shadow-sm border border-slate-200/80'
                        : 'text-gray-500 hover:bg-slate-100/80'
                    }`}
                  >
                    🟢 Sudah Terverifikasi
                    <span className="bg-emerald-100 text-[#0E9F6E] text-[10px] font-bold px-2 py-0.5 rounded-full">
                      {laporanList.filter(l => l.status !== 'pending').length}
                    </span>
                  </button>
                </div>

                <div className="text-[10px] text-gray-400 font-mono uppercase tracking-wider">
                  Total Laporan: {laporanList.length}
                </div>
              </div>

              {/* Laporan List Container */}
              {laporanLoading ? (
                <div className="py-12 text-center text-xs font-mono text-gray-500 italic">
                  Memuat berkas laporan...
                </div>
              ) : (
                (() => {
                  const filteredList = laporanList.filter(lap => {
                    if (laporanSubTab === 'pending') return lap.status === 'pending';
                    return lap.status !== 'pending';
                  });

                  if (filteredList.length === 0) {
                    return (
                      <div className="text-center py-16 px-4">
                        <Award className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                        <h4 className="text-sm font-extrabold text-slate-700 uppercase font-mono">Tidak ada laporan</h4>
                        <p className="text-xs text-gray-500 font-mono italic mt-1">
                          {laporanSubTab === 'pending'
                            ? 'Seluruh kiriman laporan kegiatan Kwarran telah diverifikasi.'
                            : 'Belum ada laporan kegiatan yang telah diverifikasi.'}
                        </p>
                      </div>
                    );
                  }

                  return (
                    <div className="divide-y divide-gray-100">
                      {filteredList.map((lap, index) => {
                        const isExpanded = expandedLaporanId === lap.id;
                        return (
                          <div 
                            key={lap.id} 
                            className={`transition-colors ${
                              isExpanded ? 'bg-slate-50/50' : 'hover:bg-slate-50/30'
                            }`}
                          >
                            {/* Simple List Row (Compact & Clean) */}
                            <div 
                              onClick={() => setExpandedLaporanId(isExpanded ? null : lap.id)}
                              className="px-6 py-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 cursor-pointer select-none"
                            >
                              <div className="flex items-start sm:items-center gap-3 min-w-0 flex-1">
                                <span className="text-xs font-bold font-mono text-gray-400 w-6 shrink-0">
                                  {(index + 1).toString().padStart(2, '0')}
                                </span>
                                <div className="min-w-0 space-y-1">
                                  <div className="flex flex-wrap items-center gap-2">
                                    <span className="bg-brand-brown-dark text-white text-[9px] font-bold font-mono px-2 py-0.5 rounded uppercase tracking-wider">
                                      DKR {lap.kecamatan_nama}
                                    </span>
                                    <span className={`text-[9px] font-black font-mono uppercase px-2 py-0.5 rounded text-white ${
                                      lap.jenis_dokumen === '02GP' ? 'bg-[#0E9F6E]' : 'bg-[#1e3c72]'
                                    }`}>
                                      {lap.jenis_dokumen}
                                    </span>
                                    <span className="text-[10px] text-gray-400 font-mono">
                                      {new Date(lap.tanggal_pelaksanaan).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' })}
                                    </span>
                                  </div>
                                  <h4 className="text-sm font-bold text-slate-800 tracking-tight leading-snug truncate">
                                    {lap.nama_kegiatan}
                                  </h4>
                                </div>
                              </div>

                              <div className="flex items-center justify-between sm:justify-end gap-4 shrink-0">
                                {/* Status badge */}
                                <div>
                                  {lap.status === 'diterima' && (
                                    <span className="bg-[#0E9F6E]/10 text-[#0E9F6E] text-[10px] font-bold px-2.5 py-1 rounded-full uppercase font-mono">
                                      🟢 Diterima (+{lap.point_bobot || 0} Pts)
                                    </span>
                                  )}
                                  {lap.status === 'ditolak' && (
                                    <span className="bg-red-50 text-red-600 text-[10px] font-bold px-2.5 py-1 rounded-full uppercase font-mono">
                                      🔴 Ditolak
                                    </span>
                                  )}
                                  {lap.status === 'revisi' && (
                                    <span className="bg-orange-50 text-orange-600 text-[10px] font-bold px-2.5 py-1 rounded-full uppercase font-mono">
                                      🟠 Revisi
                                    </span>
                                  )}
                                  {lap.status === 'pending' && (
                                    <span className="bg-blue-50 text-blue-600 text-[10px] font-bold px-2.5 py-1 rounded-full uppercase font-mono animate-pulse">
                                      🔵 Menunggu
                                    </span>
                                  )}
                                </div>

                                {/* Chevron indicator or click to action */}
                                <div className="text-xs font-mono font-bold text-[#0E9F6E] flex items-center gap-1">
                                  {isExpanded ? 'Tutup' : 'Detail'}
                                  <ChevronRight className={`w-4 h-4 text-gray-400 transition-transform ${isExpanded ? 'rotate-90' : ''}`} />
                                </div>
                              </div>
                            </div>

                            {/* Expandable Detail Section */}
                            {isExpanded && (
                              <div className="px-6 pb-6 pt-2 bg-slate-50 border-t border-slate-100 space-y-4 text-xs font-mono animate-fade-in">
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-white p-4 rounded-2xl border border-slate-100">
                                  <div>
                                    <span className="text-[9px] font-black text-gray-400 uppercase tracking-wider">Tanggal Pelaksanaan</span>
                                    <p className="font-bold text-slate-800 text-xs mt-0.5">{new Date(lap.tanggal_pelaksanaan).toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
                                  </div>
                                  <div>
                                    <span className="text-[9px] font-black text-gray-400 uppercase tracking-wider">Tempat Pelaksanaan</span>
                                    <p className="font-bold text-slate-800 text-xs mt-0.5">{lap.tempat_pelaksanaan}</p>
                                  </div>
                                  <div>
                                    <span className="text-[9px] font-black text-gray-400 uppercase tracking-wider">Poin Bobot Keaktifan</span>
                                    <p className="font-bold text-[#0E9F6E] text-xs mt-0.5">
                                      {lap.status === 'diterima' ? `+ ${lap.point_bobot || 0} Poin` : 'Belum/tidak dinilai'}
                                    </p>
                                  </div>
                                </div>

                                <div className="space-y-1">
                                  <span className="text-[9px] font-black text-gray-400 uppercase tracking-wider">Deskripsi Ringkas Kegiatan:</span>
                                  <p className="text-xs text-slate-700 leading-relaxed bg-white p-4 rounded-2xl border border-slate-100 font-sans">
                                    {lap.deskripsi_singkat}
                                  </p>
                                </div>

                                {lap.catatan_admin && (
                                  <div className="p-4 bg-orange-50/50 border border-orange-100 rounded-2xl space-y-1">
                                    <p className="text-[9px] font-black text-orange-600 uppercase tracking-wider">Catatan Keputusan Admin DKC:</p>
                                    <p className="text-xs text-slate-700 italic">"{lap.catatan_admin}"</p>
                                  </div>
                                )}

                                <div className="flex items-center justify-between gap-4 flex-wrap pt-2">
                                  <div className="flex items-center gap-2">
                                    {lap.form_data && (
                                      <button
                                        onClick={() => handleDownloadPdf(lap)}
                                        className="bg-brand-orange hover:bg-brand-orange/90 text-brand-brown-dark font-extrabold text-[10px] px-4 py-2.5 rounded-xl inline-flex items-center gap-1.5 uppercase transition-all cursor-pointer"
                                      >
                                        <FileText className="w-4 h-4" /> Download PDF Laporan
                                      </button>
                                    )}
                                    {lap.file_laporan_url && (
                                      <a
                                        href={lap.file_laporan_url}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="bg-[#0E9F6E]/10 hover:bg-[#0E9F6E]/20 text-[#0E9F6E] font-bold text-[10px] px-4 py-2.5 rounded-xl inline-flex items-center gap-1.5 uppercase transition-all"
                                      >
                                        📂 Lampiran Manual
                                      </a>
                                    )}
                                    {!lap.form_data && !lap.file_laporan_url && (
                                      <span className="text-xs text-gray-400 italic font-mono">Tidak ada laporan / lampiran</span>
                                    )}
                                  </div>

                                  {/* Hidden PDF Template Container */}
                                  <div style={{ display: 'none' }}>
                                    <LaporanPdfTemplate laporan={lap} profileDkr={undefined} />
                                  </div>

                                  <div>
                                    <button
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        setProcessingLaporan(lap);
                                        setProcessStatus(lap.status === 'pending' ? 'diterima' : lap.status as any);
                                        setProcessCatatan(lap.catatan_admin || '');
                                        setProcessPointBobot(lap.point_bobot || 10);
                                        setShowProcessModal(true);
                                      }}
                                      className="bg-brand-brown-dark hover:bg-brand-brown-dark/95 text-white font-extrabold font-mono text-[10px] px-4 py-2.5 rounded-xl cursor-pointer flex items-center gap-1.5 shadow-xs transition-all uppercase tracking-wider"
                                    >
                                      <Edit className="w-3.5 h-3.5 text-brand-orange" /> Proses Verifikasi &amp; Penilaian
                                    </button>
                                  </div>
                                </div>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  );
                })()
              )}
            </div>

            {/* Verification Modal Dialog */}
            {showProcessModal && processingLaporan && (
              <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
                <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 space-y-6 shadow-2xl">
                  <div className="flex items-center justify-between border-b pb-3">
                    <h3 className="font-extrabold text-base text-brand-brown-dark font-mono uppercase">
                      ⚖️ Proses Verifikasi Laporan Kegiatan
                    </h3>
                    <button
                      onClick={() => { setShowProcessModal(false); setProcessingLaporan(null); }}
                      className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 transition-colors cursor-pointer"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  <div className="space-y-3 bg-slate-50 p-4 border border-slate-100 rounded-2xl">
                    <div className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest leading-none">Mengulas Laporan:</div>
                    <h4 className="font-extrabold text-sm text-brand-brown-dark uppercase">{processingLaporan.nama_kegiatan}</h4>
                    <p className="text-[10px] font-mono text-gray-500">
                      Oleh: <strong>DKR {processingLaporan.kecamatan_nama}</strong> | Kode: <strong>{processingLaporan.jenis_dokumen}</strong>
                    </p>
                  </div>

                  <form onSubmit={handleProcessLaporan} className="space-y-4 text-xs font-mono">
                    <div>
                      <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Keputusan Status</label>
                      <div className="grid grid-cols-3 gap-2">
                        <button
                          type="button"
                          onClick={() => setProcessStatus('diterima')}
                          className={`py-2 rounded-xl font-bold font-mono text-[10px] border transition-all cursor-pointer text-center ${
                            processStatus === 'diterima'
                              ? 'bg-[#0E9F6E]/10 border-[#0E9F6E] text-[#0E9F6E]'
                              : 'bg-white border-gray-200 text-gray-500 hover:bg-gray-50'
                          }`}
                        >
                          🟢 Diterima
                        </button>
                        <button
                          type="button"
                          onClick={() => setProcessStatus('revisi')}
                          className={`py-2 rounded-xl font-bold font-mono text-[10px] border transition-all cursor-pointer text-center ${
                            processStatus === 'revisi'
                              ? 'bg-orange-100 border-orange-500 text-orange-600'
                              : 'bg-white border-gray-200 text-gray-500 hover:bg-gray-50'
                          }`}
                        >
                          🟠 Butuh Revisi
                        </button>
                        <button
                          type="button"
                          onClick={() => setProcessStatus('ditolak')}
                          className={`py-2 rounded-xl font-bold font-mono text-[10px] border transition-all cursor-pointer text-center ${
                            processStatus === 'ditolak'
                              ? 'bg-red-100 border-red-500 text-red-600'
                              : 'bg-white border-gray-200 text-gray-500 hover:bg-gray-50'
                          }`}
                        >
                          🔴 Ditolak
                        </button>
                      </div>
                    </div>

                    {processStatus === 'diterima' && (
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Poin Nilai Kegiatan (Sesuai Bobot)</label>
                        <input
                          type="number"
                          required
                          min={1}
                          max={100}
                          value={processPointBobot}
                          onChange={(e) => setProcessPointBobot(Number(e.target.value))}
                          className="w-full bg-gray-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs text-gray-800 font-bold focus:outline-none focus:border-[#0E9F6E] focus:ring-2 focus:ring-[#0E9F6E]/10"
                        />
                        <p className="text-[9px] text-gray-400 italic mt-1">
                          *Poin akan diakumulasikan ke keaktifan prestasi Kwarran {processingLaporan.kecamatan_nama} se-Kabupaten Tasikmalaya.
                        </p>
                      </div>
                    )}

                    {(processStatus === 'revisi' || processStatus === 'ditolak') && (
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">
                          Penjelasan Penolakan / Catatan Revisi (Wajib)
                        </label>
                        <textarea
                          required
                          rows={3}
                          value={processCatatan}
                          onChange={(e) => setProcessCatatan(e.target.value)}
                          placeholder="Sebutkan berkas atau data apa yang kurang, atau alasan penolakan secara logis agar DKR dapat memperbaikinya..."
                          className="w-full bg-gray-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs text-slate-800 focus:outline-none focus:border-red-500"
                        />
                      </div>
                    )}

                    {processStatus === 'diterima' && (
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Catatan Tambahan (Opsional)</label>
                        <input
                          type="text"
                          value={processCatatan}
                          onChange={(e) => setProcessCatatan(e.target.value)}
                          placeholder="Contoh: Selamat, pertahankan kinerja Kwarran Anda!"
                          className="w-full bg-gray-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs text-slate-800"
                        />
                      </div>
                    )}

                    <div className="flex justify-end gap-3 pt-3 border-t">
                      <button
                        type="button"
                        onClick={() => { setShowProcessModal(false); setProcessingLaporan(null); }}
                        className="px-5 py-2.5 border border-slate-200 text-gray-500 font-bold rounded-xl hover:bg-gray-50 cursor-pointer"
                      >
                        Batal
                      </button>
                      <button
                        type="submit"
                        disabled={processSaving}
                        className="px-6 py-2.5 bg-[#0E9F6E] hover:bg-[#10B981] text-white font-extrabold rounded-xl shadow cursor-pointer"
                      >
                        {processSaving ? 'Memproses...' : 'Simpan Verifikasi'}
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}
          </div>
        )}

      </main>

    
      
      {/* Change Password Modal */}
      {isChangePasswordModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setIsChangePasswordModalOpen(false)}></div>
          <div className="relative w-full max-w-sm bg-white rounded-3xl p-6 shadow-2xl">
            <h3 className="text-lg font-black text-brand-brown-dark mb-1">Ganti Password</h3>
            <p className="text-xs text-gray-500 mb-6">Masukkan password baru untuk akun Anda.</p>
            <form onSubmit={handleChangePassword} className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold text-gray-400 uppercase mb-2">Password Baru</label>
                <input 
                  type="password" 
                  required 
                  minLength={6}
                  value={newPassword}
                  onChange={e => setNewPassword(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-brand-green focus:ring-2 focus:ring-brand-green/20"
                  placeholder="Minimal 6 karakter"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setIsChangePasswordModalOpen(false)} className="px-4 py-2 rounded-xl text-xs font-bold text-gray-500 hover:bg-gray-100">Batal</button>
                <button type="submit" className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-brand-green hover:bg-brand-green/90 shadow-md">Simpan</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 3. BOTTOM NAVIGATION (Mobile Only) */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 z-40 px-6 py-2 pb-4 shadow-[0_-10px_40px_rgba(0,0,0,0.08)] rounded-t-3xl">
        <div className="flex justify-between items-center relative mt-2">
          
          <button onClick={() => setActiveTab('dashboard')} className={`flex flex-col items-center gap-1.5 ${activeTab === 'dashboard' ? 'text-brand-green' : 'text-gray-400'}`}>
            <LayoutDashboard className={`${activeTab === 'dashboard' ? 'w-6 h-6' : 'w-5 h-5'}`} />
            <span className="text-[10px] font-bold">Beranda</span>
          </button>
          
          <button onClick={() => setActiveTab('berita')} className={`flex flex-col items-center gap-1.5 ${activeTab === 'berita' ? 'text-brand-green' : 'text-gray-400'}`}>
            <FileText className={`${activeTab === 'berita' ? 'w-6 h-6' : 'w-5 h-5'}`} />
            <span className="text-[10px] font-bold">Warta</span>
          </button>
          
          {/* Floating Center Button */}
          <div className="relative -top-8 flex flex-col items-center">
            <button 
              onClick={() => setIsMobileMenuOpen(true)}
              className="w-14 h-14 bg-brand-green rounded-full flex items-center justify-center text-white shadow-xl border-4 border-white/80 transform hover:scale-105 active:scale-95 transition-all"
            >
              <Menu className="w-6 h-6" />
            </button>
            <span className="text-[10px] font-bold text-brand-green mt-1.5">Menu</span>
          </div>

          <button onClick={() => setActiveTab('agenda')} className={`flex flex-col items-center gap-1.5 ${activeTab === 'agenda' ? 'text-brand-green' : 'text-gray-400'}`}>
            <Calendar className={`${activeTab === 'agenda' ? 'w-6 h-6' : 'w-5 h-5'}`} />
            <span className="text-[10px] font-bold">Kegiatan</span>
          </button>
          
          <button onClick={() => setActiveTab('laporan')} className={`flex flex-col items-center gap-1.5 ${activeTab === 'laporan' ? 'text-brand-green' : 'text-gray-400'}`}>
            <Award className={`${activeTab === 'laporan' ? 'w-6 h-6' : 'w-5 h-5'}`} />
            <span className="text-[10px] font-bold">Laporan</span>
          </button>
          
        </div>
      </div>
      
      {/* Popup konfirmasi hapus kegiatan (wajib ketik frasa persis) */}
      {agendaToDelete && (
        <div
          className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm"
          onClick={closeDeleteAgendaModal}
        >
          <div
            role="alertdialog"
            aria-modal="true"
            className="w-full max-w-md bg-white rounded-3xl shadow-2xl p-6"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mx-auto w-16 h-16 rounded-full border bg-red-50 border-red-100 flex items-center justify-center mb-4">
              <Trash className="w-8 h-8 text-red-500" />
            </div>
            <h3 className="text-center font-extrabold text-lg text-slate-900 tracking-tight">Hapus Kegiatan Permanen</h3>
            <p className="text-sm text-slate-600 mt-2 leading-relaxed text-center">
              Kegiatan <span className="font-bold text-slate-900">"{agendaToDelete.nama_kegiatan}"</span> beserta semua data pendaftaran terkait akan dihapus dan <span className="font-bold text-red-600">tidak bisa dikembalikan</span>.
            </p>
            <label className="block mt-5 text-xs text-slate-600">
              Ketik <span className="font-mono font-bold text-red-600 select-none">{HAPUS_KEGIATAN_PHRASE}</span> untuk mengaktifkan tombol hapus:
              <input
                type="text"
                autoFocus
                autoComplete="off"
                autoCapitalize="none"
                spellCheck={false}
                value={deleteConfirmText}
                onChange={(e) => setDeleteConfirmText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && deleteConfirmText === HAPUS_KEGIATAN_PHRASE) handleDeleteAgenda();
                  if (e.key === 'Escape') closeDeleteAgendaModal();
                }}
                disabled={isDeletingAgenda}
                placeholder={HAPUS_KEGIATAN_PHRASE}
                className={`mt-2 w-full px-4 py-2.5 rounded-xl border font-mono text-sm outline-none transition-colors ${
                  deleteConfirmText === HAPUS_KEGIATAN_PHRASE
                    ? 'border-emerald-400 bg-emerald-50 focus:ring-2 focus:ring-emerald-200'
                    : 'border-slate-200 focus:border-red-400 focus:ring-2 focus:ring-red-100'
                }`}
              />
            </label>
            <div className="grid grid-cols-2 gap-3 mt-6">
              <button
                type="button"
                onClick={closeDeleteAgendaModal}
                disabled={isDeletingAgenda}
                className="py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-sm transition-colors cursor-pointer disabled:opacity-60"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleDeleteAgenda}
                disabled={deleteConfirmText !== HAPUS_KEGIATAN_PHRASE || isDeletingAgenda}
                className="py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-sm shadow-md transition-colors cursor-pointer disabled:bg-slate-300 disabled:text-slate-500 disabled:shadow-none disabled:cursor-not-allowed"
              >
                {isDeletingAgenda ? 'Menghapus...' : 'Hapus Kegiatan'}
              </button>
            </div>
          </div>
        </div>
      )}
      </div>
  );
}
